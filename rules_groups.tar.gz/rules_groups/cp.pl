#!/usr/bin/perl

use strict;
use warnings;

my %opts = (
        vm => {
                type => "=s",
                variable => "vm",
                required => 1,
        },
        cluster => {
                type => "=s",
                variable => "cluster",
                required => 1
        },
        drsgroup => {
                type => "=s",
                variable => "drsgroup",
                required => 1,
        }
);

Opts::add_options(%opts);
Opts::parse();
Opts::validate();

my ($Fichero1, $Fichero2, $Salida, $F1value, $F2value);

$Fichero1 = Opts::get_option("fichero1");
$Fichero2 = Opts::get_option("fichero2");
$Salida = Opts::get_option("salida");

open(FILE1, $Fichero1);
open(FILE2, $Fichero2);
open(OUT, $Salida);

my @file1=<FILE1>;
my @file2=<FILE2>;
my @out=<OUT>;

my ($vm1, $vm2);

 foreach $F1value (@file1) {

   $vm1 = $F1value;

   foreach $F2value (@file2) {

   $vm2 = $F2value;


   if ($vm1 ne $vm2)  {

      print OUT $vm1 . "\n";
 
                      }
					         }

                            }							 

close(FILE1);
close(FILE2);
close (OUT);

