
cd /root/rules_groups

#### Ejecutamos querys en tabla Virtuales_ESX, para obtener ficheros de maquinas por site y actualizamos grupos drs...

#### Cloud

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Cloud_ROZ' and Path_VMX like '%ROZ%' and Template='0'" > VMS_ROZ_Cloud

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Cloud_ROZ' and Path_VMX like '%COR%' and Template='0'" > VMS_COR_Cloud

perl list_groups.pl --clusterName Cloud_ROZ --drsgroup VMS_ROZAS > VMS_ROZ_Cloud_D
perl list_groups.pl --clusterName Cloud_ROZ --drsgroup VMS_COR > VMS_COR_Cloud_D

perl list_groups.pl --clusterName Cloud_ROZ --drsgroup PETICIONESBANKIA_ROZ > roles_especificos
perl list_groups.pl --clusterName Cloud_ROZ --drsgroup PETICIONESBANKIA_COR >> roles_especificos

perl compara_noen1.pl VMS_ROZ_Cloud VMS_ROZ_Cloud_D > VMS_ROZ_Cloud_ADD
perl compara_noen1.pl VMS_COR_Cloud VMS_COR_Cloud_D > VMS_COR_Cloud_ADD

perl compara_noen1.pl VMS_ROZ_Cloud_ADD roles_especificos > VMS_ROZ_Cloud_ADD_norole
perl compara_noen1.pl VMS_COR_Cloud_ADD roles_especificos > VMS_COR_Cloud_ADD_norole

perl compara3.pl VMS_ROZ_Cloud_D VMS_COR_Cloud_D VMS_ROZ_Cloud

if [ -s "Match3" ]
 then

   mail "aalcalap@bankia.com" -s "Maquinas virtuales repetidas en Grupos DRS Cloud"  < "Match3"

 fi


perl ADDVM2GROUP.pl --file VMS_ROZ_Cloud_ADD_norole --cluster Cloud_ROZ --drsgroup VMS_ROZAS > VMS_ROZ_Cloud.log
perl ADDVM2GROUP.pl --file VMS_COR_Cloud_ADD_norole --cluster Cloud_ROZ --drsgroup VMS_COR > VMS_COR_Cloud.log

#### Desarrollo

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Desarrollo' and Path_VMX like '%ROZ%' and Template='0'" > VMS_ROZ_Desarrollo
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Desarrollo' and Path_VMX like '%COR%' and Template='0'" > VMS_COR_Desarrollo

perl list_groups.pl --clusterName Desarrollo --drsgroup DES_ROZ > VMS_ROZ_Desarrollo_D
perl list_groups.pl --clusterName Desarrollo --drsgroup DES_COR > VMS_COR_Desarrollo_D

perl compara_noen1.pl VMS_ROZ_Desarrollo VMS_ROZ_Desarrollo_D > VMS_ROZ_Desarrollo_ADD
perl compara_noen1.pl VMS_COR_Desarrollo VMS_COR_Desarrollo_D > VMS_COR_Desarrollo_ADD

perl compara3.pl VMS_ROZ_Desarrollo_D VMS_COR_Desarrollo_D VMS_ROZ_Desarrollo

 if [ -s "Match3" ]
 then

   mail "aalcalap@bankia.com" -s "Maquinas virtuales repetidas en  Grupos DRS Desarrollo"  < "Match3"
 
 fi

perl ADDVM2GROUP.pl --file VMS_ROZ_Desarrollo_ADD --cluster Desarrollo --drsgroup DES_ROZ > VMS_ROZ_Desarrollo.log
perl ADDVM2GROUP.pl --file VMS_COR_Desarrollo_ADD --cluster Desarrollo --drsgroup DES_COR > VMS_COR_Desarrollo.log


#### Preproduccion

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Preproduccion' and Path_VMX like '%ROZ%' and Template='0'" > VMS_ROZ_Preproduccion
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Preproduccion' and Path_VMX like '%COR%' and Template='0'" > VMS_COR_Preproduccion

perl list_groups.pl --clusterName Preproduccion --drsgroup Maquinas_ROZAS > VMS_ROZ_Preproduccion_D
perl list_groups.pl --clusterName Preproduccion --drsgroup Maquinas_COR > VMS_COR_Preproduccion_D

perl compara_noen1.pl VMS_ROZ_Preproduccion VMS_ROZ_Preproduccion_D > VMS_ROZ_Preproduccion_ADD
perl compara_noen1.pl VMS_COR_Preproduccion VMS_COR_Preproduccion_D > VMS_COR_Preproduccion_ADD

perl compara3.pl VMS_ROZ_Preproduccion_D VMS_COR_Preproduccion_D VMS_ROZ_Preproduccion

if [ -s "Match3" ]
 then

   mail "aalcalap@bankia.com" -s "Maquinas virtuales repetidas en  Grupos DRS Preproduccion"  < "Match3"

 fi

perl ADDVM2GROUP.pl --file VMS_ROZ_Preproduccion_ADD --cluster Preproduccion --drsgroup Maquinas_ROZAS > VMS_ROZ_Preproduccion.log
perl ADDVM2GROUP.pl --file VMS_COR_Preproduccion_ADD --cluster Preproduccion --drsgroup Maquinas_COR > VMS_COR_Preproduccion.log

#### SQL_Previos

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='SQL_Previos' and Path_VMX like '%ROZ%' and Template='0'" > VMS_ROZ_SQL_Previos
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='SQL_Previos' and Path_VMX like '%COR%' and Template='0'" > VMS_COR_SQL_Previos

perl list_groups.pl --clusterName SQL_Previos --drsgroup Maquinas_ROZAS > VMS_ROZ_SQL_Previos_D
perl list_groups.pl --clusterName SQL_Previos --drsgroup Maquinas_COR > VMS_COR_SQL_Previos_D

perl compara_noen1.pl VMS_ROZ_SQL_Previos VMS_ROZ_SQL_Previos_D > VMS_ROZ_SQL_Previos_ADD
perl compara_noen1.pl VMS_COR_SQL_Previos VMS_COR_SQL_Previos_D > VMS_COR_SQL_Previos_ADD

perl compara3.pl VMS_ROZ_SQL_Previos_D VMS_COR_SQL_Previos_D VMS_ROZ_SQL_Previos

if [ -s "Match3" ]
 then

   mail "aalcalap@bankia.com" -s "Maquinas virtuales repetidas en  Grupos DRS SQL_Previos"  < "Match3"

 fi

perl ADDVM2GROUP.pl --file VMS_ROZ_SQL_Previos_ADD --cluster SQL_Previos --drsgroup Maquinas_ROZAS > VMS_ROZ_SQL_Previos.log
perl ADDVM2GROUP.pl --file VMS_COR_SQL_Previos_ADD --cluster SQL_Previos --drsgroup Maquinas_COR > VMS_COR_SQL_Previos.log

#### Produccion1

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Produccion1' and Path_VMX like '%ROZ%' and Template='0'" > VMS_ROZ_Produccion1
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Produccion1' and Path_VMX like '%COR%' and Template='0'" > VMS_COR_Produccion1

perl list_groups.pl --clusterName Produccion1 --drsgroup Maquinas_ROZAS > VMS_ROZ_Produccion1_D
perl list_groups.pl --clusterName Produccion1 --drsgroup Maquinas_COR > VMS_COR_Produccion1_D

perl compara_noen1.pl VMS_ROZ_Produccion1 VMS_ROZ_Produccion1_D > VMS_ROZ_Produccion1_ADD
perl compara_noen1.pl VMS_COR_Produccion1 VMS_COR_Produccion1_D > VMS_COR_Produccion1_ADD

perl compara3.pl VMS_ROZ_Produccion1_D VMS_COR_Produccion1_D VMS_COR_Produccion1

if [ -s "Match3" ]
 then

   mail "aalcalap@bankia.com" -s "Maquinas virtuales repetidas en  Grupos DRS Produccion1"  < "Match3"

 fi

perl ADDVM2GROUP.pl --file VMS_ROZ_Produccion1_ADD --cluster Produccion1 --drsgroup Maquinas_ROZAS > VMS_ROZ_Produccion1.log
perl ADDVM2GROUP.pl --file VMS_COR_Produccion1_ADD --cluster Produccion1 --drsgroup Maquinas_COR > VMS_COR_Produccion1.log

#### Produccion2

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Produccion2' and Path_VMX like '%ROZ%' and Template='0'" > VMS_ROZ_Produccion2
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Produccion2' and Path_VMX like '%COR%' and Template='0'" > VMS_COR_Produccion2

perl list_groups.pl --clusterName Produccion2 --drsgroup Maquinas_ROZ > VMS_ROZ_Produccion2_D
perl list_groups.pl --clusterName Produccion2 --drsgroup Maquinas_COR > VMS_COR_Produccion2_D

perl compara_noen1.pl VMS_ROZ_Produccion2 VMS_ROZ_Produccion2_D > VMS_ROZ_Produccion2_ADD
perl compara_noen1.pl VMS_COR_Produccion2 VMS_COR_Produccion2_D > VMS_COR_Produccion2_ADD

perl compara3.pl VMS_ROZ_Produccion2_D VMS_COR_Produccion2_D VMS_COR_Produccion2

if [ -s "Match3" ]
 then

   mail "aalcalap@bankia.com" -s "Maquinas virtuales repetidas en  Grupos DRS Produccion2"  < "Match3"

 fi

perl ADDVM2GROUP.pl --file VMS_ROZ_Produccion2_ADD --cluster Produccion2 --drsgroup Maquinas_ROZ > VMS_ROZ_Produccion2.log
perl ADDVM2GROUP.pl --file VMS_COR_Produccion2_ADD --cluster Produccion2 --drsgroup Maquinas_COR > VMS_COR_Produccion2.log

#### SQL_Produccion

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='SQL_Produccion' and Path_VMX like '%ROZ%' and Template='0'" > VMS_ROZ_SQL_Produccion
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='SQL_Produccion' and Path_VMX like '%COR%' and Template='0'" > VMS_COR_SQL_Produccion

perl list_groups.pl --clusterName SQL_Produccion --drsgroup Maquinas_ROZAS > VMS_ROZ_SQL_Produccion_D
perl list_groups.pl --clusterName SQL_Produccion --drsgroup Maquinas_COR > VMS_COR_SQL_Produccion_D

perl compara_noen1.pl VMS_ROZ_SQL_Produccion VMS_ROZ_SQL_Produccion_D > VMS_ROZ_SQL_Produccion_ADD
perl compara_noen1.pl VMS_COR_SQL_Produccion VMS_COR_SQL_Produccion_D > VMS_COR_SQL_Produccion_ADD

perl compara3.pl VMS_ROZ_SQL_Produccion_D VMS_COR_SQL_Produccion_D VMS_ROZ_SQL_Produccion

if [ -s "Match3" ]
 then

   mail "aalcalap@bankia.com" -s "Maquinas virtuales repetidas en  Grupos DRS SQL_Produccion"  < "Match3"

 fi

perl ADDVM2GROUP.pl --file VMS_ROZ_SQL_Produccion_ADD --cluster SQL_Produccion --drsgroup Maquinas_ROZAS > VMS_ROZ_SQL_Produccion.log
perl ADDVM2GROUP.pl --file VMS_COR_SQL_Produccion_ADD --cluster SQL_Produccion --drsgroup Maquinas_COR > VMS_COR_SQL_Produccion.log


#### Test


mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Test' and Path_VMX like '%ROZ%' and Template='0'" > VMS_ROZ_Test
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Test' and Path_VMX like '%COR%' and Template='0'" > VMS_COR_Test

perl list_groups.pl --clusterName Test --drsgroup TST_ROZ > VMS_ROZ_Test_D
perl list_groups.pl --clusterName Test --drsgroup TST_COR > VMS_COR_Test_D

perl compara_noen1.pl VMS_ROZ_Test VMS_ROZ_Test_D > VMS_ROZ_Test_ADD
perl compara_noen1.pl VMS_COR_Test VMS_COR_Test_D > VMS_COR_Test_ADD

perl compara3.pl VMS_ROZ_Test_D VMS_COR_Test_D VMS_ROZ_Test

if [ -s "Match3" ]
 then

   mail "aalcalap@bankia.com" -s "Maquinas virtuales repetidas en  Grupos DRS Test"  < "Match3"

 fi


perl ADDVM2GROUP.pl --file VMS_ROZ_Test_ADD --cluster Test --drsgroup TST_ROZ > drs_add_TST_ROZ.log
perl ADDVM2GROUP.pl --file VMS_COR_Test_ADD --cluster Test --drsgroup TST_COR > drs_add_TST_COR.log
