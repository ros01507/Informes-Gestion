foreach my $vmsInCluster (@{$cluster_view->configurationEx->group}) {
                       if (ref($vmsInCluster) eq "ClusterVmGroup") {
                                print "DRS rule name is: ", $vmsInCluster->name, "\n";
                                foreach my $vmNames (@{$vmsInCluster->vm}) {
                                        my $vmMor = Vim::get_view(mo_ref => $vmNames);
                                        print $vmMor->config->name, "\n";
                                }
                         }
}
