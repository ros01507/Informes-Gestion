#!/usr/bin/perl

use strict;
use warnings;

my ($fichero1, $fichero2) = @ARGV;

my ($F1value, $F2value);

if (not defined $fichero1) {
  die "Falta fichero1\n";
                          }
						  
if (not defined $fichero2) {
  die "Falta fichero2\n\n";
                           }
					  

open(FILE1, $fichero1);
open(FILE2, $fichero2);


my @file1=<FILE1>;
my @file2=<FILE2>;
my $imp="0";

 foreach $F1value (@file1) {
    chomp $F1value;
		
   foreach $F2value (@file2) {
    chomp $F2value;
		
   if ($F1value eq $F2value )  {$imp="1";}
						
					         }
		if ( $imp == 0)	{print $F1value . "\n";}

		$imp="0";
                           }							 

close(FILE1);
close(FILE2);


