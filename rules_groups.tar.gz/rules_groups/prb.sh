if [ -s "Match3" ]
 then

   mail "aalcalap@bankia.com" -s "Maquinas virtuales en Grupos DRS Produccion2"  < "Match3"

 fi

