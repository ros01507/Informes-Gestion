#!/usr/bin/perl

use strict;
use warnings;


my %opts = (
	vm => {
		type => "=s",
		variable => "vm",
		required => 1,
	},
	cluster => {
		type => "=s",
		variable => "cluster",
		required => 1
	},
	drsgroup => {
		type => "=s",
		variable => "drsgroup",
		required => 1,
	}
);

Opts::add_options(%opts);
Opts::parse();
Opts::validate();

my ($fichero1, $fichero2, $salida, $F1value, $F2value);

$fichero1 = Opts::get_option("fichero1");
$fichero2 = Opts::get_option("fichero2");
$salida = Opts::get_option("salida");

open(FILE1, $fichero1);
open(FILE2, $fichero2);
open(OUT, $salida);

my @file1=<FILE1>;
my @file2=<FILE2>;
my @out=<OUT>;

my ($vm1, $vm2);

 foreach $F1value (@file1) {

   $vm1 = $F1value;

   foreach $F2value (@file2) {

   $vm2 = $F2value;


   if ($vm1 ne $vm2)  {

      print OUT $vm1 . "\n";
 
                      }
					         }

                            }							 

close(FILE1);
close(FILE2);
close (OUT);

