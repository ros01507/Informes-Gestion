#### Cloud

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Cloud_ROZ' and Path_VMX like '%ROZ%' and Template='0'" > VMS_ROZ_Cloud
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Cloud_ROZ' and Path_VMX like '%COR%' and Template='0'" > VMS_COR_Cloud

#### Desarrollo

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Desarrollo' and Path_VMX like '%ROZ%' and Template='0'" > VMS_ROZ_Desarrollo
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Desarrollo' and Path_VMX like '%COR%' and Template='0'" > VMS_COR_Desarrollo

#### Preproduccion

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Preproduccion' and Path_VMX like '%ROZ%' and Template='0'" > VMS_ROZ_Preproduccion
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Preproduccion' and Path_VMX like '%COR%' and Template='0'" > VMS_COR_Preproduccion

#### SQL_Previos

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='SQL_Previos' and Path_VMX like '%ROZ%' and Template='0'" > VMS_ROZ_SQL_Previos
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='SQL_Previos' and Path_VMX like '%COR%' and Template='0'" > VMS_COR_SQL_Previos

#### Produccion1

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Produccion1' and Path_VMX like '%ROZ%' and Template='0'" > VMS_ROZ_Produccion1
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Produccion1' and Path_VMX like '%COR%' and Template='0'" > VMS_COR_Produccion1

#### Produccion2

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Produccion2' and Path_VMX like '%ROZ%' and Template='0'" > VMS_ROZ_Produccion2
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Produccion2' and Path_VMX like '%COR%' and Template='0'" > VMS_COR_Produccion2

#### SQL_Produccion

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='SQL_Produccion' and Path_VMX like '%ROZ%' and Template='0'" > VMS_ROZ_SQL_Produccion
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='SQL_Produccion' and Path_VMX like '%COR%' and Template='0'" > VMS_COR_SQL_Produccion

#### Test

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Test' and Path_VMX like '%ROZ%' and Template='0'" > VMS_ROZ_Test
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Test' and Path_VMX like '%COR%' and Template='0'" > VMS_COR_Test


