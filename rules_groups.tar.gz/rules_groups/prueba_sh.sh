mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Cloud_ROZ' and Path_VMX like '%ROZ%' and Template='0'" > VMS_ROZ_Cloud

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT Nombre_VM FROM Informes_Gestion.Virtuales_ESX  where Cluster='Cloud_ROZ' and Path_VMX like '%COR%' and Template='0'" > VMS_COR_Cloud

perl list_groups.pl --clusterName Cloud_ROZ --drsgroup VMS_ROZAS > VMS_ROZ_Cloud_D
perl list_groups.pl --clusterName Cloud_ROZ --drsgroup VMS_COR > VMS_COR_Cloud_D

perl list_groups.pl --clusterName Cloud_ROZ --drsgroup PETICIONESBANKIA_ROZ > roles_especificos
perl list_groups.pl --clusterName Cloud_ROZ --drsgroup PETICIONESBANKIA_COR >> roles_especificos

perl compara_noen1.pl VMS_ROZ_Cloud VMS_ROZ_Cloud_D > VMS_ROZ_Cloud_ADD
perl compara_noen1.pl VMS_COR_Cloud VMS_COR_Cloud_D > VMS_COR_Cloud_ADD

perl compara_noen1.pl VMS_ROZ_Cloud_ADD roles_especificos > VMS_ROZ_Cloud_ADD
perl compara_noen1.pl VMS_COR_Cloud_ADD roles_especificos > VMS_COR_Cloud_ADD

perl compara3.pl VMS_ROZ_Cloud_D VMS_COR_Cloud_D VMS_ROZ_Cloud

if [ -s "Match3" ]
 then

   mail "aalcalap@bankia.com" -s "Maquinas virtuales repetidas en Grupos DRS Cloud"  < "Match3"

 fi


perl ADDVM2GROUP.pl --file VMS_ROZ_Cloud_ADD --cluster Cloud_ROZ --drsgroup VMS_ROZAS > VMS_ROZ_Cloud.log
perl ADDVM2GROUP.pl --file VMS_COR_Cloud_ADD --cluster Cloud_ROZ --drsgroup VMS_COR > VMS_COR_Cloud.log
