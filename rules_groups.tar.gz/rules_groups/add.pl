#!/usr/bin/perl

use strict;
use warnings;

my %opts = (
entity => {
type => "=s",
variable => "VI_ENTITY",
help => "ManagedEntity type: HostSystem, etc",
required => 1,
},
);
Opts::add_options(%opts);
Opts::parse();
Opts::validate();



my ($vm_name, $drsgroup_name, $cluster_name, $vm_view, $cluster_view, $drsgroup, $groupvms,
	$groupSpec, $clusterSpec);

$vm_name = Opts::get_option("VI_ENTITY");


