#!/usr/bin/perl -w
use strict;
use warnings;
use FindBin;
use lib "$FindBin::Bin/../";
use VMware::VIRuntime;
use AppUtil::HostUtil;
use AppUtil::VMUtil;
$Util::script_version = "0.1";
my %opts = (
   network => {
   type => "=s",
   help => "Network name",
   required =>0,
   default => "Network adapter 1",
   },
   operation => {
      type => "=s",
      help => "connect or disconnect",
      required => 0,
      default => "connect",
   },
      vmname => {
      type => "=s",
      help => "Name of virtual machine",
      required => 1
   }
);
Opts::add_options(%opts);
Opts::parse();
Opts::validate();
Util::connect();
my $vm_views = VMUtils::get_vms('VirtualMachine', 
Opts::get_option ('vmname'));
my $vm_view = shift (@$vm_views);
if ($vm_view) {
        my $network = Opts::get_option('network');
        my $operation = Opts::get_option ('operation');
        my $chngspec = VMUtils::create_network_spec($vm_view, $network, $operation, undef);

eval {
$vm_view->ReconfigVM( spec => $chngspec);
if ($@) {
print "Reconfiguration failed.\n $@";
}
else {
print "Virtual Network card added.\n";
}



};

}


Util::disconnect();
