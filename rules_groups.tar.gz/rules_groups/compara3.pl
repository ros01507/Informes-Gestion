#!/usr/bin/perl

use strict;
# use warnings

# perl compara3.pl VMS_ROZ_Desarrollo_D VMS_COR_Desarrollo_D VMS_ROZ_Desarrollo

my ($fichero1, $fichero2, $fichero3) = @ARGV;

my ($file1, $file2, $file3);
my $opt3="si";
if (not defined $fichero1) {
  die "Falta fichero1, correspondiente a grupo drs ROZAS\n";
                          }
						  
if (not defined $fichero2) {
  die "Falta fichero2, correspondiente a grupo drs COR\n";
                           }
						   
if (not defined $fichero3) {
  die "Falta fichero3, correspondiente a query Maquinas ROZAS-COR \n\n";
                           }						   


open(FILE1, $fichero1);
open(FILE2, $fichero2);
open(FILE3, $fichero3);
open(DIF, ">Match3");

#my @dif=<DIF>;
my @file1=<FILE1>;
my @file2=<FILE2>;
my @file3=<FILE3>;

 foreach $file1 (@file1) {
  chomp $file1;
  
 foreach $file2 (@file2) {
  chomp $file2;
   
   if ($file1 =~ m/$file2/)  {
   
    foreach $file3 (@file3) {
	chomp $file3;

   
   if (($file2 eq $file3) and ($file3 eq $file1))  {
                    
                     print DIF $file1 . "," . "Comprobar grupos DRS a los que pertenece la máquina virtual" . "\n";

					$opt3="no";
                                                    }
   
		                       
                            }
		if (($file1 eq $file2) and ($opt3 eq "si")) {
   
                    print DIF $file1 . "," . "Comprobar grupos DRS a los que pertenece la máquina virtual" . "\n";

                                            }

                            }

                        }
				
					    }

close(DIF);
close(FILE1);
close(FILE2);
close(FILE3);
