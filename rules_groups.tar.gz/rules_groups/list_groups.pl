
#!/usr/bin/perl -w
#
# Copyright 2006 VMware, Inc.  All rights reserved.

use strict;
use warnings;

use FindBin;
use lib "$FindBin::Bin/../";

use VMware::VIRuntime;
use AppUtil::VMUtil;
use AppUtil::HostUtil;

$SIG{__DIE__} = sub{Util::disconnect()};
$Util::script_version = "1.0";

my %opts = (
            clusterName => {
            type => "=s",
            help => "Cluster name",
            required => 1},

            drsgroup => {
                type => "=s",
                variable => "drsgroup",
                required => 1,
                         }
           );

# read/validate options and connect to the server
Opts::add_options(%opts);

$ENV{VI_SERVER}="v12kvcent.cm.es";
$ENV{VI_URL}="https://v12kvcent.cm.es/sdk/webService";

Opts::parse();
Opts::validate();


# connect from the server
Util::connect();

listRules();

# disconnect from the server
Util::disconnect();

sub listRules {
    # Find the Cluster
    my $clusterName = Opts::get_option('clusterName');
    my $drsgroup_Name = Opts::get_option('drsgroup');
    my $cluster_view = Vim::find_entity_view(view_type => 'ClusterComputeResource',
                                               filter => { name => $clusterName });
    

foreach my $vmsInCluster (@{$cluster_view->configurationEx->group}) {
                       if (ref($vmsInCluster) eq "ClusterVmGroup" and $vmsInCluster->name eq $drsgroup_Name  ) {
#                                print "DRS rule name is: ", $vmsInCluster->name, "\n";
                                foreach my $vmNames (@{$vmsInCluster->vm}) {
                                        my $vmMor = Vim::get_view(mo_ref => $vmNames);
                                        print $vmMor->config->name, "\n";
                                                                   }
                                                                     }
             }
}
