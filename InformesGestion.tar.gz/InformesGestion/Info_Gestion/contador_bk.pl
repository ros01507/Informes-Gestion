
open(COUNT,">>cont");
open(CNT, "contador.txt");
open(CNTDARK, "contador_dark.txt");
open(CNTPF, "contador_PF.txt");

my @count=<COUNT>;
my @cnt=<CNT>;
my @cntdark=<CNTDARK>;
my @cntPF=<CNTPF>;
my $numvms;

 foreach $cnt (@cnt) {

   ($fecha,$numvm) = split(/;/,$cnt );
                           

 foreach $cntdark (@cntdark) {

   ($fechadark,$numvmdark) = split(/;/,$cntdark);
   
     
   if ($fecha =~ m/$fechadark/)  {

      $numvms= $numvm + $numvmdark;
                       }

     }

  foreach $cntPF (@cntPF) {

   ($fechaPF,$numvmPF) = split(/;/,$cntPF);


   if ($fecha =~ m/$fechaPF/)  {

      $numvms= $numvm + $numvmPF;
                      
                      }
}
          
print COUNT $fecha . "," . $numvms . "\n";
    
   
                     }
close(COUNT);
close(CNT);
close (CNTDARK);
