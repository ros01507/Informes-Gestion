#!/usr/bin/perl

# Copyright 2006 VMware, Inc.  All rights reserved.


$ENV{VI_SERVER}="v12kvcent.cm.es";
$ENV{VI_URL}="https://v12kvcent.cm.es/sdk/webService";

use Time::localtime;
use strict;

Opts::parse();
Opts::validate();

use VMware::VIRuntime;

my $datos;
my $total;
my $datosB;
my $tm = localtime;

Util::connect();

# Open file,

open (DATOS,">> contador_PF.txt");

    
my $host_views = Vim::find_entity_views(view_type => 'HostSystem');

foreach my $host (@$host_views) {

# get views of all VM's.
my $vm_views = Vim::find_entity_views(view_type => 'VirtualMachine',
                                      begin_entity => $host);

foreach (@$vm_views) {
	
             
$datos++;

};


};


Util::disconnect();



  print DATOS  $tm->mday .  ";" . $datos . "\n";


close (DATOS);

Util::disconnect();
                                
