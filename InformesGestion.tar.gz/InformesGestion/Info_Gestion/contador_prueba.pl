open(CNT, "contador_anterior.txt");
open(CNTDARK, "contador_dark_anterior.txt");
open(CNTPF, "contador_PF_anterior.txt");
open(COUNT, ">cont_anterior");

my @count=<COUNT>;
my @cnt=<CNT>;
my @cntdark=<CNTDARK>;
my @cntpf=<CNTPF>;

my $numvms;

 foreach $cnt (@cnt) {

   ($fecha,$numvm) = split(/;/,$cnt );


 foreach $cntdark (@cntdark) {

   ($fechadark,$numvmdark) = split(/;/,$cntdark);


   if ($fecha =~ m/$fechadark/)  {

      $numvms= $numvm + $numvmdark;

                       }

                      }

 foreach $cntpf (@cntpf) {

   ($fechapf,$numvmpf) = split(/;/,$cntpf);


   if ($fecha =~ m/$fechapf/)  {

      $numvms= $numvms + $numvmpf;

                       }

                      }

print COUNT $fecha . "," . $numvms . "," . $numvmpf . "\n";


                     }

close(COUNT);
close(CNT);
close (CNTDARK);
close (CNTPF);
