
open(COUNT,">>cont");
open(CNT, "contador.txt");
open(CNTDARK, "contador_dark.txt");


my @count=<COUNT>;
my @cnt=<CNT>;
my @cntdark=<CNTDARK>;
my $numvms;

 foreach $cnt (@cnt) {

   ($fecha,$numvm) = split(/;/,$cnt );
                           

 foreach $cntdark (@cntdark) {

   ($fechadark,$numvmdark) = split(/;/,$cntdark);
   
     
   if ($fecha =~ m/$fechadark/)  {

      $numvms= $numvm + $numvmdark;
                       }
    
                      }
          
print COUNT $fecha . "," . $numvms . "\n";
    
   
                     }

close(COUNT);
close(CNT);
close (CNTDARK);
