cd /root/InformesGestion/Info_Gestion
perl count.pl
perl count_dark.pl 
perl count_PF.pl
