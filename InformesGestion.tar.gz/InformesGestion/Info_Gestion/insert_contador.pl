#/usr/bin/perl
use DBI;
# MYSQL CONFIG VARIABLES
my $host = "vlirompf.cm.es";
my $database = "Informes_Gestion";
my $user;
my $password;
my $table="Numero_Maximo_Elementos_Virtuales";
my $total;
my @cont;
my $cont;

($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);

if($mon == 0 ) {$mon="Enero";}
elsif($mon == 1) {$mon="Febrero";}
elsif($mon == 2) {$mon="Marzo";}
elsif($mon == 3) {$mon="Abril";}
elsif($mon == 4) {$mon="Mayo";}
elsif($mon == 5) {$mon="Junio";}
elsif($mon == 6) {$mon="Julio";}
elsif($mon == 7) {$mon="Agosto";}
elsif($mon == 8) {$mon="Septiembre";}
elsif($mon == 9) {$mon="Octubre";}
elsif($mon == 10) {$mon="Noviembre";}
elsif ($mon == 11) {$mon="Diciembre";}

$year= $year + 1900;


# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table(MES, ANO, Numero_Maximo_Elementos_Virtuales,Numero_Maximo_Elementos_Virtuales_FlexSystem) VALUES (?,?,?,?)");

my $numvmT;
my $numvmpf;
my $numvmPF;

open (INSERT, "cont");
my @insert=<INSERT>;

foreach $ins (@insert) {

($fecha,$numvm,$numvmpf) = split(/,/,$ins);

if ($numvmT < $numvm)  {

      $numvmT= $numvm;
      $numvmPF=$numvmpf;
                       }

                       }
$sth->execute($mon,$year,$numvmT,$numvmPF);

close (INSERT);

$dbh->disconnect;

