#/usr/bin/perl
use DBI;
# MYSQL CONFIG VARIABLES
my $host = "vlirompf.cm.es";
my $database = "Informes_Gestion";
my $user;
my $password;
my $table="Numero_Maximo_Elementos_Virtuales";
my $total;
my $totalPF;
my @cont;
my @contPF;
my $cont;

($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);

if($mon == 0 ) {$mon="Enero";}
elsif($mon == 1) {$mon="Febrero";}
elsif($mon == 2) {$mon="Marzo";}
elsif($mon == 3) {$mon="Abril";}
elsif($mon == 4) {$mon="Mayo";}
elsif($mon == 5) {$mon="Junio";}
elsif($mon == 6) {$mon="Julio";}
elsif($mon == 7) {$mon="Agosto";}
elsif($mon == 8) {$mon="Septiembre";}
elsif($mon == 9) {$mon="Octubre";}
elsif($mon == 10) {$mon="Noviembre";}
elsif ($mon == 11) {$mon="Diciembre";}

$year= $year + 1900;


# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table(MES, ANO, Numero_Maximo_Elementos_Virtuales, Numero_Maximo_Elementos_Virtuales_FlexSystem) VALUES (?,?,?,?)");

open (INSERT, "cont");

while(<INSERT>) {

my ($fecha,$numvms) = split /,/;

push(@cont,$numvms);
                }
$total=$cont[0];
for ($i=1; $i <= $#cont; $i++) {

if ($cont[$i] > $total) {

$total=$cont[$i];
                           }

                            }
chop $total;
print $total . "\n";
open (INSERTPF, "contador_PF.txt");

while(<INSERTPF>) {

my ($fechaPF,$numvmsPF) = split /;/;

push(@contPF,$numvmsPF);
print Dumper \@contPF;

print $numvmsPF . "\n";
                }
$totalPF=$contPF[0];
for ($i=1; $i <= $#cont; $i++) {

if ($contPF[$i] > $totalPF) {

$totalPF=$contPF[$i];
                           }

                            }
chop $totalPF;
print $totalPF . "\n";;
$sth->execute($mon,$year,$total,$totalPF);

close (INSERT);
close (INSERTPF);

$dbh->disconnect;
