open(CNT, "contador.txt");
open(CNTDARK, "contador_dark.txt");
open(CNTPF, "contador_PF.txt");
open(COUNT, ">cont");

my @count=<COUNT>;
my @cnt=<CNT>;
my @cntdark=<CNTDARK>;
my @cntpf=<CNTPF>;

my $numvms;

 foreach $cnt (@cnt) {

   ($fecha,$numvm) = split(/;/,$cnt );


 foreach $cntdark (@cntdark) {

   ($fechadark,$numvmdark) = split(/;/,$cntdark);


   if ($fecha eq $fechadark)  {

      $numvms= $numvm + $numvmdark;

                       }

                      }

 foreach $cntpf (@cntpf) {

   ($fechapf,$numvmpf) = split(/;/,$cntpf);


   if ($fecha eq $fechapf)  {

      $numvms= $numvms + $numvmpf;

                       }

                      }

print COUNT $fecha . "," . $numvms . "," . $numvmpf . "\n";


                     }

close(COUNT);
close(CNT);
close (CNTDARK);
close (CNTPF);
