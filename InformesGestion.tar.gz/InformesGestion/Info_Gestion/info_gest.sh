
echo "############# INICIO ###############"
date
## Borramos registros de BBDD SQL de las tablas ( Elementos_virtuales, Hipervisores, Datastore)

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion < /root/InformesGestion/sql/borra_reg_bbdd.sql

echo "############################# GENERACION TABLA ELEMENTOS VIRTUALES #############################"

echo "#### Ejecucion diaria en script Elem_virtual_day.sh ####


echo "################################ GENERACION TABLA HIPERVISORES ###############################"


echo "## BORRADO DE FICHEROS DE DATOS##"

cd /root/InformesGestion/hypervisores/PF

rm -f hypervisores
rm -f perf_red
rm -f cluster
rm -f perf_cpu
rm -f perf_mem

cd /root/InformesGestion/hypervisores/darkside

rm -f hypervisores
rm -f perf_red
rm -f cluster
rm -f perf_cpu
rm -f perf_mem

 
cd /root/InformesGestion/hypervisores

rm -f hypervisores
rm -f perf_red
rm -f cluster
rm -f perf_cpu
rm -f perf_mem
rm -f hypervisoresF.txt

# read -p "Borrado de Ficheros de datos, tabla Hipervisores, Presiona Enter para continuar..."

echo "## TOMA DE DATOS ##"

cd /root/InformesGestion/hypervisores

perl hostsystem.pl
perl perf.pl --countertype net --freq monthly > perf_red
perl prb_clus.pl
perl perf.pl --countertype cpu --freq monthly > perf_cpu
perl perf.pl --countertype mem --freq monthly > perf_mem
perl comb.pl

cd /root/InformesGestion/hypervisores/darkside

perl hostsystem.pl
perl perf.pl --countertype net --freq monthly >> perf_red
perl perf.pl --countertype cpu --freq monthly > perf_cpu
perl perf.pl --countertype mem --freq monthly > perf_mem
perl clus.pl
perl comb.pl

cd /root/InformesGestion/hypervisores/PF

perl hostsystem.pl
perl perf.pl --countertype net --freq monthly >> perf_red
perl perf.pl --countertype cpu --freq monthly > perf_cpu
perl perf.pl --countertype mem --freq monthly > perf_mem
perl clus.pl
perl comb.pl

cd /root/InformesGestion/hypervisores
perl insert_hypervisores.pl

# read -p "Toma de datos, tabla Hipervisores, Presiona Enter para continuar..."

echo "################################ GENERACION TABLAS DATASTOREs #######################################"

#####   A continuación ejecutamos script para alimentar la BBDD Datastore, previamente eliminamos los ficheros que genera el script cada vez que se ejecuta.
#####   1) Ejecutamos clus.pl, y dts.pl generan el fichero datos.txt, y datosDatacenter.txt
#####   2) Ejecutamos fichero insert_datastore.pl, e insert_datastore_datacenter.pl, estos scripts insertan datos en las tablas Datastores, Datastores por Datacenter.

## BORRADO DE FICHEROS DE DATOS
echo "## BORRADO DE FICHEROS DE DATOS"

cd /root/InformesGestion/Datastore
rm -f datos.txt
rm -f datosDatacenter.txt

# read -p "Borrado ficheros de datos, tabla Datastore, Presiona Enter para continuar..."

## TOMA DE DATOS
echo "## TOMA DE DATOS"

perl clus.pl
perl dts.pl


cd /root/InformesGestion/Datastore/PF

perl clus.pl
perl dts.pl

cd /root/InformesGestion/Datastore

perl insert_datastore.pl
perl insert_datastore_datacenter.pl

# read -p "Toma de datos, tabla Datastore, Presiona Enter para continuar..."


echo "################################ GENERACION TABLA Cluster_Memory ###############################"

cd /root/InformesGestion/ClusterMemory

rm -f perf_mem_overhead
rm -f perf_mem_total
rm -f perf_mem_consumed
rm -f clusmemF.txt

cd /root/InformesGestion/ClusterMemory/PF

rm -f perf_mem_overhead
# rm -f perf_mem_total
rm -f perf_mem_consumed
rm -f clusmemF.txt

cd /root/InformesGestion/ClusterMemory

perl perf_consumed.pl --countertype mem --freq monthly --entity ClusterComputeResource > perf_mem_consumed
perl perf_overhead.pl --countertype mem --freq monthly --entity ClusterComputeResource > perf_mem_overhead
perl perf_total.pl --countertype mem --freq monthly --entity ClusterComputeResource > perf_mem_total
perl comb.pl

cd /root/InformesGestion/ClusterMemory/PF

perl perf_consumed.pl --countertype mem --freq monthly --entity ClusterComputeResource > perf_mem_consumed
perl perf_overhead.pl --countertype mem --freq monthly --entity ClusterComputeResource > perf_mem_overhead
# perl perf_total.pl --countertype mem --freq monthly --entity ClusterComputeResource > perf_mem_total
# read -p "Toma de datos, tabla Cluster Memory, modifica overhead PF y Presiona Enter para continuar..."
perl comb.pl
cd ..
awk '!/------------------------------------------------------------/' clusmemF.txt > temp && mv -f temp clusmemF.txt
perl insert_clus_mem.pl

echo "#########################  CONSULTAS SQL #####################"

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion < /root/InformesGestion/sql/OK/all_query_old.sql

## Pico Maximo de VM's alcanzado durante el ultimo mes.

cd /root/InformesGestion/Info_Gestion
perl contador.pl
perl insert_contador.pl
mv -f cont cont_anterior
mv -f contador.txt contador_anterior.txt
mv -f contador_dark.txt contador_dark_anterior.txt
mv -f contador_PF.txt  contador_PF_anterior.txt

# read -p "FIN creacion de consultas, Presiona Enter para FINALIZAR..."

echo "############# FIN ##############"
date


