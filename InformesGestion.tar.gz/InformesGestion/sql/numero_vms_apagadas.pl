
use DBI;

my $host = "vlirompf.cm.es";
my $database = "Informes_Gestion";
my $user = "root";
my $pw = "LyD:2TmT";
my $qtable="Elementos_virtuales";
my $instable="Num_vms_off";

### Connect to the database
my $dsn = "dbi:mysql:$database:$host:3306";
my $dbh = DBI->connect($dsn, $user, $pw, {
RaiseError => 1
} );


### Use quoted string as a string literal in a SQL statement
my $sth = $dbh->prepare( "

# Set lc_time_names = 'es_ES';

SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
COUNT(*) FROM `Informes_Gestion`.`Elementos_virtuales` where Tipo_elemento_virtual =2;


                        ");
$sth->execute();
my @row = $sth->fetchrow_array();
my $mes= $row[0];
my $ano= $row[1];
my $numvmsoff= $row[2];

$sth = $dbh->prepare("INSERT INTO $instable( Mes, A�o, Num_vms) VALUES (?,?,?)");
$sth->execute( $mes, $ano, $numvmsoff);
print $mes . $ano . $numvmsoff . "\n";
$dbh->disconnect;
# exit;


