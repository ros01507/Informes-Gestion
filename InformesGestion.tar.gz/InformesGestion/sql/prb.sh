result=$(mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select Nombre_VM,Cluster from Virtuales_ESX where  ESX LIKE 'svmro%' and Path_VMX  NOT LIKE  '%ROZ%'  and Vcenter LIKE 's8kvcent%'")
echo $result
