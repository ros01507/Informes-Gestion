DELETE FROM Hipervisores;
DELETE FROM Datastores;
DELETE FROM Datastores_por_Datacenter;
DELETE FROM Media_mem_consumida_por_entorno;
DELETE FROM Clusters_Memory;
DELETE FROM Espacio_Libre_Datastores;
DELETE FROM CPU_Disponible_Ghz;
DELETE FROM CPU_Instalada_Ghz;
