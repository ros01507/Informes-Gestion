
use DBI;

my $host = "vlirompf.cm.es";
my $database = "Informes_Gestion";
my $user = "root";
my $pw = "LyD:2TmT";
my $table="Elementos_virtuales";

### Connect to the database
my $dsn = "dbi:mysql:$database:$host:3306";
my $dbh = DBI->connect($dsn, $user, $pw, {
RaiseError => 1
} );


### Use quoted string as a string literal in a SQL statement
my $sth = $dbh->prepare( "
SELECT COUNT(*)
AS NUMERO_DE_ELEMENTOS_VIRTUALES
FROM Elementos_virtuales
" );
$sth->execute();
@row = $sth->fetchrow_array();
print @row;
exit;