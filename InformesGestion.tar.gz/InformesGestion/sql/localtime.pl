
use POSIX qw/ strftime /;

#  print strftime( "%d/%m/%Y %H:%M:%S", localtime(time)->DateTime->now->set_time_zone("es/ES"));
my $now = DateTime->now->set_time_zone("Europe/London")
print $now->strftime(");


