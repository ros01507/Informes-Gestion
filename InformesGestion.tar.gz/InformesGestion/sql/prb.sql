Set lc_time_names = 'es_ES';
SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
COUNT(*) FROM `Informes_Gestion`.`Elementos_virtuales` where Tipo_elemento_virtual =2;
