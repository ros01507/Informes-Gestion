
echo "El siguiente correo muestra las maquinas virtuales que su almacenamiento no se encuentra en el site al que pertenece, programe VMotion a ESX correspondiente."
echo ""
echo ""
echo "####### MAQUINAS COR #######"
echo ""
 mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select Nombre_VM,Cluster from Virtuales_ESX where  ESX LIKE 'svmro%' and Path_VMX  NOT LIKE  '%_ROZ_%' and Vcenter LIKE 'v12kvcent%' and Template LIKE '0'"

echo "" 
echo "###### MAQUINAS ROZAS #######"
echo ""
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select Nombre_VM,Cluster from Virtuales_ESX where  ESX LIKE 'svmsh%' and Path_VMX  NOT LIKE  '%_COR_%'  and Vcenter LIKE 'v12kvcent%' and Template LIKE '0'"
