

### CPU_Disponible ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.CPU_Disponible_Ghz (Mes,Ano,CPU_Total_Ghz, CPU_Disponible_Centro_Respaldo, CPU_Disponible_Escritorios, CPU_Disponible_Produccion_1,
 CPU_Disponible_Produccion_2, CPU_Disponible_Produccion_3, CPU_Disponible_Produccion_Backup, CPU_Disponible_Test_y_Preproduccion, CPU_Disponible_Integracion,
 CPU_Disponible_Produccion_4, CPU_Disponible_Cerntro_Respaldo_02, CPU_Disponible_Preproduccion, CPU_Disponible_Entorno_Test, CPU_Disponible_PPMM, CPU_Disponible_Test_PF, CPU_Disponible_Produccion1_PF,
 CPU_Disponible_Produccion2_PF, CPU_Disponible_Desarrollo_PF, CPU_Disponible_Escritorios_PF, CPU_Disponible_Preproduccion_PF)
 SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()), (SELECT SUM(CPU_Instalada_Mhz /1024) FROM Hipervisores),
((SELECT SUM(CPU_Instalada_Mhz /1024) FROM Hipervisores WHERE IDCluster=1) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=1)),
 ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=2) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=2)),
 ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=3) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=3)),
 ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=4) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=4)),
 ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=5) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=5)),
 ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=6) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=6)),
 ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=7) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=7)),
 ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=8) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=8)),
 ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=11) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=11)),
 ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=12) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=12)),
((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=13) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=13)),
 ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=14) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=14)),
 ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=9) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=9)),
((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=15) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=15)),
((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=16) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=16)),
((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=17) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=17)),
((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=18) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=18)),
((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=20) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=20)),
((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=21) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=21));

### CPU_Instalada ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.CPU_Instalada_Ghz (Mes,Ano,CPU_Total_Ghz, CPU_Instalada_Centro_Respaldo, CPU_Instalada_Escritorios, CPU_Instalada_Produccion_1,
CPU_Instalada_Produccion_2, CPU_Instalada_Produccion_3, CPU_Instalada_Produccion_Backup, CPU_Instalada_Test_y_Preproduccion, CPU_Instalada_Integracion, CPU_Instalada_Produccion_4,
 CPU_Instalada_Centro_Respaldo_2, CPU_Instalada_Preproduccion, CPU_Instalada_Entorno_Test, CPU_Instalada_PPMM, CPU_Instalada_Test_PF, CPU_Instalada_Produccion1_PF, CPU_Instalada_Produccion2_PF, CPU_Instalada_Desarrollo_PF, CPU_Instalada_Escritorios_PF, CPU_Instalada_Preproduccion_PF)
 SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores),(SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=1),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=2), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=3),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=4), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=5),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=6), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=7),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=8), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=11),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=12), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=13),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=14), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=9),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=15), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=16),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=17), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=18),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=20), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=21);

### Memoria_Asignada ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Memoria_asignada_vms (Mes,Ano,Memoria_media_asignada_vms, Memoria_asignada_vms_Centro_Respaldo,Memoria_asignada_vms_Escritorios,
Memoria_asignada_vms_Produccion_1,Memoria_asignada_vms_Produccion_2, Memoria_asignada_vms_Produccion_3, Memoria_asignada_vms_Produccion_Backup,
 Memoria_asignada_vms_Test_y_Preproduccion, Memoria_asignada_vms_Integracion, Memoria_asignada_vms_PPMM, Memoria_asignada_vms_Test_PF, Memoria_asignada_vms_Produccion1_PF, Memoria_asignada_vms_Produccion2_PF, Memoria_asignada_vms_Desarrollo_PF, Memoria_asignada_vms_Escritorios_PF, Memoria_asignada_vms_Preproduccion_PF) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()), 
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales),(SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=1),
 (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=2), (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=3),
 (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=4), (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=5),
 (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=6), (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=7),
 (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=8), (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=9),
 (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=15), (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=16),
 (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=17), (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=18),
 (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=20), (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=21);

### Memoria_Consumida ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Memoria_Consumida_Percent (Mes,Ano,Memoria_Total_Percent, Memoria_Consumida_Centro_Respaldo,Memoria_Consumida_Escritorios,
Memoria_Consumida_Produccion_1,Memoria_Consumida_Produccion_2, Memoria_Consumida_Produccion_3, Memoria_Consumida_Produccion_Backup, Memoria_Consumida_Test_y_Preproduccion,
 Memoria_Consumida_Integracion,Memoria_Consumida_PPMM, Memoria_Consumida_Produccion_4, Memoria_Consumida_Centro_Respaldo_02, Memoria_Consumida_Preproduccion,
 Memoria_Consumida_Entorno_Test, Memoria_Consumida_Test_PF, Memoria_Consumida_Produccion1_PF, Memoria_Consumida_Produccion2_PF, Memoria_Consumida_Desarrollo_PF, Memoria_Consumida_Escritorios_PF, Memoria_Consumida_Preproduccion_PF)
 SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
((SELECT SUM(Memoria_Consumida_MB) FROM Elementos_virtuales) / (SELECT SUM(Memoria_instalada_MB) FROM Elementos_virtuales)) * 100,
(((SELECT (Memoria_Consumida) FROM Clusters_Memory WHERE ClusterID=1) + (SELECT (Memoria_Overhead) FROM Clusters_Memory WHERE ClusterID=1)) * 100/ (SELECT (Memoria_Total) FROM Clusters_Memory WHERE ClusterID=1)),
(((SELECT (Memoria_Consumida) FROM Clusters_Memory WHERE ClusterID=2) + (SELECT (Memoria_Overhead) FROM Clusters_Memory WHERE ClusterID=2)) * 100/ (SELECT (Memoria_Total) FROM Clusters_Memory WHERE ClusterID=2)),
(((SELECT (Memoria_Consumida) FROM Clusters_Memory WHERE ClusterID=3) + (SELECT (Memoria_Overhead) FROM Clusters_Memory WHERE ClusterID=3)) * 100/ (SELECT (Memoria_Total) FROM Clusters_Memory WHERE ClusterID=3)),
(((SELECT (Memoria_Consumida) FROM Clusters_Memory WHERE ClusterID=4) + (SELECT (Memoria_Overhead) FROM Clusters_Memory WHERE ClusterID=4)) * 100/ (SELECT (Memoria_Total) FROM Clusters_Memory WHERE ClusterID=4)),
(((SELECT (Memoria_Consumida) FROM Clusters_Memory WHERE ClusterID=5) + (SELECT (Memoria_Overhead) FROM Clusters_Memory WHERE ClusterID=5)) * 100/ (SELECT (Memoria_Total) FROM Clusters_Memory WHERE ClusterID=5)),
(((SELECT (Memoria_Consumida) FROM Clusters_Memory WHERE ClusterID=6) + (SELECT (Memoria_Overhead) FROM Clusters_Memory WHERE ClusterID=6)) * 100/ (SELECT (Memoria_Total) FROM Clusters_Memory WHERE ClusterID=6)),
(((SELECT (Memoria_Consumida) FROM Clusters_Memory WHERE ClusterID=7) + (SELECT (Memoria_Overhead) FROM Clusters_Memory WHERE ClusterID=7)) * 100/ (SELECT (Memoria_Total) FROM Clusters_Memory WHERE ClusterID=7)),
(((SELECT (Memoria_Consumida) FROM Clusters_Memory WHERE ClusterID=8) + (SELECT (Memoria_Overhead) FROM Clusters_Memory WHERE ClusterID=8)) * 100/ (SELECT (Memoria_Total) FROM Clusters_Memory WHERE ClusterID=8)),
((SELECT SUM(Memoria_Consumida_MB) FROM Elementos_virtuales WHERE Cluster=9) / (SELECT SUM(Memoria_instalada_MB) FROM Elementos_virtuales WHERE Cluster=9)) * 100,
 (((SELECT (Memoria_Consumida) FROM Clusters_Memory WHERE ClusterID=11) + (SELECT (Memoria_Overhead) FROM Clusters_Memory WHERE ClusterID=11)) * 100/ (SELECT (Memoria_Total) FROM Clusters_Memory WHERE ClusterID=11)),
 (((SELECT (Memoria_Consumida) FROM Clusters_Memory WHERE ClusterID=12) + (SELECT (Memoria_Overhead) FROM Clusters_Memory WHERE ClusterID=12)) * 100/ (SELECT (Memoria_Total) FROM Clusters_Memory WHERE ClusterID=12)),
(((SELECT (Memoria_Consumida) FROM Clusters_Memory WHERE ClusterID=13) + (SELECT (Memoria_Overhead) FROM Clusters_Memory WHERE ClusterID=13)) * 100/ (SELECT (Memoria_Total) FROM Clusters_Memory WHERE ClusterID=13)),
(((SELECT (Memoria_Consumida) FROM Clusters_Memory WHERE ClusterID=14) + (SELECT (Memoria_Overhead) FROM Clusters_Memory WHERE ClusterID=14)) * 100/ (SELECT (Memoria_Total) FROM Clusters_Memory WHERE ClusterID=14)),
(((SELECT (Memoria_Consumida) FROM Clusters_Memory WHERE ClusterID=15) + (SELECT (Memoria_Overhead) FROM Clusters_Memory WHERE ClusterID=15)) * 100/ (SELECT (Memoria_Total) FROM Clusters_Memory WHERE ClusterID=15)),
(((SELECT (Memoria_Consumida) FROM Clusters_Memory WHERE ClusterID=16) + (SELECT (Memoria_Overhead) FROM Clusters_Memory WHERE ClusterID=16)) * 100/ (SELECT (Memoria_Total) FROM Clusters_Memory WHERE ClusterID=16)),
(((SELECT (Memoria_Consumida) FROM Clusters_Memory WHERE ClusterID=17) + (SELECT (Memoria_Overhead) FROM Clusters_Memory WHERE ClusterID=17)) * 100/ (SELECT (Memoria_Total) FROM Clusters_Memory WHERE ClusterID=17)),
(((SELECT (Memoria_Consumida) FROM Clusters_Memory WHERE ClusterID=18) + (SELECT (Memoria_Overhead) FROM Clusters_Memory WHERE ClusterID=18)) * 100/ (SELECT (Memoria_Total) FROM Clusters_Memory WHERE ClusterID=18)),
(((SELECT (Memoria_Consumida) FROM Clusters_Memory WHERE ClusterID=20) + (SELECT (Memoria_Overhead) FROM Clusters_Memory WHERE ClusterID=20)) * 100/ (SELECT (Memoria_Total) FROM Clusters_Memory WHERE ClusterID=20)),
(((SELECT (Memoria_Consumida) FROM Clusters_Memory WHERE ClusterID=21) + (SELECT (Memoria_Overhead) FROM Clusters_Memory WHERE ClusterID=21)) * 100/ (SELECT (Memoria_Total) FROM Clusters_Memory WHERE ClusterID=21));

### Memoria_disponible ###
Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Memoria_Disponible_GB (Mes,Ano,Memoria_Total_GB, Memoria_Disponible_Centro_Respaldo,Memoria_Disponible_Escritorios,Memoria_Disponible_Produccion_1, Memoria_Disponible_Produccion_2, Memoria_Disponible_Produccion_3, Memoria_Disponible_Produccion_Backup, Memoria_Disponible_Test_y_Preproduccion, Memoria_Disponible_Integracion, Memoria_Disponible_Test_PF,Memoria_Disponible_Pro1_PF, Memoria_Disponible_Pro2_PF, Memoria_Disponible_Desarrollo_PF, Memoria_Disponible_Escritorios_PF, Memoria_Disponible_Preproduccion_PF) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()), (SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=1) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=1)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=2) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=2)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=3) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=3)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=4) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=4)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=5) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=5)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=6) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=6)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=7) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=7)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=8) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=8)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=15) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=15)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=16) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=16)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=17) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=17)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=18) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=18)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=20) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=20)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=21) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=21));

###  memoria_instalada ###
Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Memoria_Instalada_GB (Mes,Ano,Memoria_Total_GB, Memoria_Instalada_Centro_Respaldo,Memoria_Instalada_Escritorios,Memoria_Instalada_Produccion_1,Memoria_Instalada_Produccion_2, Memoria_Instalada_Produccion_3, Memoria_Instalada_Produccion_Backup, Memoria_Instalada_Test_y_Preproduccion, Memoria_Instalada_Integracion, Memoria_Instalada_Test_PF, Memoria_Instalada_Pro1_PF, Memoria_Instalada_Pro2_PF, Memoria_Instalada_Desarrollo_PF, Memoria_Instalada_Escritorios_PF, Memoria_Instalada_Preproduccion_PF) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores),(SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=1), 
(SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=2), (SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=3),
 (SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=4), (SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=5),
 (SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=6), (SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=7),
 (SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=8), (SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=15),
(SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=16), (SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=17),
(SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=18), (SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=20), (SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=21);


###  memoria_media_asignada  ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Media_mem_asig_por_vm (Mes,Ano,Memoria_media_asignada_vms, Media_mem_asig_por_vm_Centro_Respaldo, Media_mem_asig_por_vm_Escritorios, Media_mem_asig_por_vm_Produccion_1, Media_mem_asig_por_vm_Produccion_2, Media_mem_asig_por_vm_Produccion_3, Media_mem_asig_por_vm_Produccion_Backup, Media_mem_asig_por_vm_Test_y_Preproduccion, Media_mem_asig_por_vm_Integracion, Media_mem_asig_por_vm_PPMM,  Media_mem_asig_por_vm_Produccion_4, Media_mem_asig_por_vm_Centro_Respaldo_02, Media_mem_asig_por_vm_Preproduccion,  Media_mem_asig_por_vm_Entorno_Test, Media_mem_asig_por_vm_Test_PF, Media_mem_asig_por_vm_Pro1_PF, Media_mem_asig_por_vm_Pro2_PF, Media_mem_asig_por_vm_Desarrollo_PF, Media_mem_asig_por_vm_Escritorios_PF, Media_mem_asig_por_vm_Preproduccion_PF) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=1),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=2),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=3),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=4),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=5),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=6),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=7),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=8),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=9),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=11),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=12),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=13),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=14),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=15),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=16),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=17),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=18),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=20),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=21);

### NUMERO_DE_ELEMENTOS_REGISTRADOS  ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Num_elem_reg (Mes,Ano,Num_elem,Num_elem_PF) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT COUNT(*) AS NUMERO_DE_ELEMENTOS_VIRTUALES FROM Elementos_virtuales),(SELECT COUNT(*) AS NUMERO_DE_ELEMENTOS_VIRTUALES FROM Elementos_virtuales WHERE Cluster=15 OR Cluster=16 OR Cluster=17 OR Cluster=18 OR Cluster=20 OR Cluster=21);

### NUMERO_DE_VMS_APAGADAS ###
Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Num_vms_off (Mes,Ano,Num_vms) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
COUNT(*) FROM `Informes_Gestion`.`Elementos_virtuales` where Tipo_elemento_virtual =2;

### NUMERO_DE_VMS_ENCENDID ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Num_vms_on (Mes,Ano,Num_vms,Num_vms_FlexSystem) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT COUNT(*) FROM `Informes_Gestion`.`Elementos_virtuales` where Tipo_elemento_virtual =1), (SELECT COUNT(*) FROM `Informes_Gestion`.`Elementos_virtuales` where Tipo_elemento_virtual =1 AND Cluster=15 OR Cluster=16 OR Cluster=17 OR Cluster=18 OR Cluster=20 OR Cluster=21);

### porcentaje_ocupadacion_memoria_VM_ESX ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Ratio_mem_vms_mem_ESX (Mes,Ano,mem_total_vms, mem_total_ESX, Ratio_mem_vms_por_mem_ESX) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()), (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales), (SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores), ((SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales) / (SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores)) * 100;

### Ratio_vcpus_por_core.sql  ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Ratio_vcpus_por_core (Mes,Ano,vcpus,cores,Ratio_vcpus_por_core, Ratio_vcpus_por_core_FlexSystem) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales), (SELECT SUM(Num_cores) FROM Hipervisores),
((SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales) / (SELECT SUM(Num_cores) FROM Hipervisores)),(SELECT((SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales where Cluster=15 or Cluster=16 or Cluster=17 or Cluster=18 or Cluster=20 or Cluster=21) / (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=15 or IDCluster=16 or IDCluster=17 or IDCluster=18 or IDCluster=20 or IDCluster=21)));

### Total_vms_por_cluster  ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.vms_total_entorno (Mes,Ano,vms_Total_entorno, vms_total_Centro_Respaldo, vms_total_Escritorios, vms_total_Produccion_1, vms_total_Produccion_2, vms_total_Produccion_3, vms_total_Produccion_Backup, vms_total_Test_y_Preproduccion, vms_total_Integracion, vms_total_PPMM, vms_total_Produccion_4, vms_total_Centro_Respaldo_02, vms_total_Preproduccion, vms_total_Entorno_Test, vms_total_Test_PF, vms_total_Produccion1_PF, vms_total_Produccion2_PF, vms_total_Desarrollo_PF, vms_total_Escritorios_PF, vms_total_Preproduccion_PF) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT COUNT(*) FROM Elementos_virtuales),(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=1), (SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=2),
(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=3), (SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=4), (SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=5),
(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=6), (SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=7), (SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=8),
(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=9), (SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=11),(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=12),
(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=13),(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=14), (SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=15),
(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=16),(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=17),(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=18),
(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=20), (SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=21);

### vcpus_por_vm_total_entorno.sql  ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.vcpus_por_vm_total_entorno (Mes,Ano,vcpus_por_vm_Total_entorno, vcpus_por_vm_total_Centro_Respaldo,vcpus_por_vm_total_Escritorios,vcpus_por_vm_total_Produccion_1,vcpus_por_vm_total_Produccion_2, vcpus_por_vm_total_Produccion_3, vcpus_por_vm_total_Produccion_Backup, vcpus_por_vm_total_Test_y_Preproduccion, vcpus_por_vm_total_Integracion, vcpus_por_vm_total_Test_PF, vcpus_por_vm_total_Pro1_PF, vcpus_por_vm_total_Pro2_PF, vcpus_por_vm_total_Desarrollo_PF, vcpus_por_vm_total_Escritorios_PF, vcpus_por_vm_total_Preproduccion_PF)
SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales),(SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales WHERE Cluster=1), 
(SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales WHERE Cluster=2), (SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales WHERE Cluster=3),
(SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales WHERE Cluster=4),(SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales WHERE Cluster=5),
(SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales WHERE Cluster=6),(SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales WHERE Cluster=7),
(SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales WHERE Cluster=8), (SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales WHERE Cluster=15),
(SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales WHERE Cluster=16), (SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales WHERE Cluster=17),
(SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales WHERE Cluster=18), (SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales WHERE Cluster=20),
(SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales WHERE Cluster=21) ;

### Total_num_Hipervisores ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Total_Numero_Hipervisores (Mes,Ano,Num_Hipervisores,Num_Hipervisores_PF) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()), 
(SELECT COUNT(*) FROM Informes_Gestion.Hipervisores), (SELECT COUNT(*) FROM Informes_Gestion.Hipervisores WHERE IDCluster=15 OR IDCluster=16 OR IDCluster=17 OR IDCluster=18 OR IDCluster=20 OR IDCluster=21);

### AVG Media_memoria_consumida

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Media_mem_consumida_por_entorno (Mes, Ano, Media_mem_consumida_vm_Centro_Respaldo, Media_mem_consumida_por_vm_Escritorios, Media_mem_consumida_por_vm_Produccion_1, Media_mem_consumida_por_vm_Produccion_2, Media_mem_consumida_por_vm_Produccion_3, Media_mem_consumida_por_vm_Produccion_Backup, Media_mem_consumida_por_vm_Test_y_Preproduccion, Media_mem_consumida_por_vm_Integracion, Media_mem_consumida_por_vm_Produccion_4,  Media_mem_consumida_vm_Centro_Respaldo_02, Media_mem_consumida_vm_Preproduccion, Media_mem_consumida_vm_Centro_Entorno_Test, Media_mem_consumida_vm_Test_PF, Media_mem_consumida_vm_Produccion1_PF, Media_mem_consumida_vm_Produccion2_PF, Media_mem_consumida_vm_Desarrollo_PF, Media_mem_consumida_vm_Escritorios_PF, Media_mem_consumida_vm_Preproduccion_PF )
SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=1) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=1)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=2) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=2)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=3) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=3)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=4) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=4)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=5) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=5)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=6) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=6)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=7) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=7)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=8) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=8)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=11) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=11)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=12) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=12)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=13) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=13)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=14) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=14)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=15) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=15)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=16) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=16)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=17) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=17)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=18) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=18)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=20) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=20)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=21) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=21));

### Crecimiento_vm_por_Memoria #####

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Capacidad_crecimiento_Memoria (Mes, Ano, numero_vm_crecimiento_Memoria_Centro_Respaldo, numero_vm_crecimiento_Memoria_Escritorios, numero_vm_crecimiento_Memoria_Produccion_1, numero_vm_crecimiento_Memoria_Produccion_2,numero_vm_crecimiento_Memoria_Produccion_3, numero_vm_crecimiento_Memoria_Produccion_Backup, numero_vm_crecimiento_Memoria_Test_y_Preproduccion, numero_vm_crecimiento_Memoria_Integracion, numero_vm_crecimiento_Memoria_Produccion_4, numero_vm_crecimiento_Memoria_Centro_Respaldo_02, numero_vm_crecimiento_Memoria_Preproduccion, numero_vm_crecimiento_Memoria_Entorno_Test, numero_vm_crecimiento_Memoria_Test_PF, numero_vm_crecimiento_Memoria_Produccion1_PF, numero_vm_crecimiento_Memoria_Produccion2_PF, numero_vm_crecimiento_Memoria_Desarrollo_PF, numero_vm_crecimiento_Memoria_Escritorios_PF, numero_vm_crecimiento_Memoria_Preproduccion_PF )SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=1) / (SELECT (Media_mem_consumida_vm_Centro_Respaldo) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=2) / (SELECT (Media_mem_consumida_por_vm_Escritorios) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=3) / (SELECT (Media_mem_consumida_por_vm_Produccion_1) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=4) / (SELECT (Media_mem_consumida_por_vm_Produccion_2) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=5) / (SELECT (Media_mem_consumida_por_vm_Produccion_3) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=6) / (SELECT (Media_mem_consumida_por_vm_Produccion_Backup) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=7) / (SELECT (Media_mem_consumida_por_vm_Test_y_Preproduccion) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=8) / (SELECT (Media_mem_consumida_por_vm_Integracion) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=11) / (SELECT (Media_mem_consumida_por_vm_Produccion_4) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=12) / (SELECT (Media_mem_consumida_vm_Centro_Respaldo_02) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=13) / (SELECT (Media_mem_consumida_vm_Preproduccion) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=14) / (SELECT (Media_mem_consumida_vm_Centro_Entorno_Test) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=15) / (SELECT (Media_mem_consumida_vm_Test_PF) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=16) / (SELECT (Media_mem_consumida_vm_Produccion1_PF) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=17) / (SELECT (Media_mem_consumida_vm_Produccion2_PF) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=18) / (SELECT (Media_mem_consumida_vm_Desarrollo_PF) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=20) / (SELECT (Media_mem_consumida_vm_Escritorios_PF) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=21) / (SELECT (Media_mem_consumida_vm_Preproduccion_PF) FROM Media_mem_consumida_por_entorno)));



### Crecimiento_vm_por_CPU #####

Set lc_time_names = 'es_ES';
insert into Informes_Gestion. Capacidad_crecimiento_por_CPU (Mes,Ano,numero_vm_crecimiento_CPU_Centro_Respaldo, numero_vm_crecimiento_CPU_Escritorios, numero_vm_crecimiento_CPU_Produccion_1, numero_vm_crecimiento_CPU_Produccion_2, numero_vm_crecimiento_CPU_Produccion_3, numero_vm_crecimiento_CPU_Produccion_Backup, numero_vm_crecimiento_CPU_Test_y_Preproduccion, numero_vm_crecimiento_CPU_Integracion, numero_vm_crecimiento_CPU_Produccion_4,  numero_vm_crecimiento_CPU_Centro_Respaldo_02, numero_vm_crecimiento_CPU_Preproduccion, numero_vm_crecimiento_CPU_Entorno_Test, numero_vm_crecimiento_CPU_Test_PF, numero_vm_crecimiento_CPU_Produccion1_PF, numero_vm_crecimiento_CPU_Produccion2_PF, numero_vm_crecimiento_CPU_Desarrollo_PF, numero_vm_crecimiento_CPU_Escritorios_PF, numero_vm_crecimiento_CPU_Preproduccion_PF)(SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=1)* (4)) - (SELECT count(*) FROM Elementos_virtuales where Cluster=1 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=2)* 4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=2 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=3)* 4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=3 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=4)* 4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=4 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=5)* 4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=5 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=5)* 4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=6 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=7)* 4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=7 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=8)*4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=8 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=11)*4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=11 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=12)*4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=12 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=13)*4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=13 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=14)*4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=14 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=15)*4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=15 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=16)*4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=16 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=17)*4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=17 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=18)*4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=18 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=20)*4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=20 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=21)*4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=21 AND Tipo_elemento_virtual=1));

##### Espacio Libre Datastores #####

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Espacio_Libre_Datastores (Mes,Ano, Libre_Total_Entorno, Libre_Centro_Respaldo, Libre_Escritorios, Libre_Produccion_1, Libre_Produccion_2, Libre_Produccion_3, Libre_Produccion_Backup, Libre_Test_y_Preproduccion, Libre_Integracion, Libre_PPMM, Libre_Produccion_4, Libre_Centro_Respaldo_02, Libre_Preproduccion, Libre_Entorno_Test, Libre_Entorno_Test_PF, Libre_Entorno_Produccion1_PF, Libre_Entorno_Produccion2_PF, Libre_Entorno_Desarrollo_PF, Libre_Entorno_Escritorios_PF, Libre_Entorno_Preproduccion_PF )
SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT SUM(Libre_Datastore) FROM Datastores where Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=1 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=2 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=3 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=4 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=5 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=6 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=7 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=8 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=10 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=11 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=12 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=13 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=14 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=15 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=16 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=17 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=18 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=20 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=21 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24');

##### Asignado Datastores #####

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Espacio_Asignado_Datastore (Mes,Ano,Asignado_Total_Entorno, Asignado_Centro_Respaldo,Asignado_Escritorios, Asignado_Produccion_1, Asignado_Produccion_2,Asignado_Produccion_3, Asignado_Produccion_Backup,Asignado_Test_y_Preproduccion, Asignado_Integracion,Asignado_PPMM, Asignado_Produccion_4, Asignado_Centro_Respaldo_02, Asignado_Preproduccion, Asignado_Entorno_Test, Asignado_Test_PF, Asignado_Produccion1_PF, Asignado_Produccion2_PF, Asignado_Desarrollo_PF, Asignado_Escritorios_PF, Asignado_Preproduccion_PF) SELECT MONTHNAME(CURDATE()),YEAR(CURDATE()),
(SELECT SUM(Capacidad_Datastore) FROM Datastores where Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23'and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=1 and Grupo_Almacenamiento <> '1'and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=2 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=3 and Grupo_Almacenamiento <> '1'and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=4 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=5 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=6 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=7 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=8 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=10 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=11 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=12 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=13 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=14 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=15 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=16 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=17 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=18 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=20 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=21 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24');

### CPU_Consumida ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.CPU_Consumida_Percent (Mes,Ano,CPU_Total_Percent, CPU_Consumida_Centro_Respaldo,CPU_Consumida_Escritorios,CPU_Consumida_Produccion_1,CPU_Consumida_Produccion_2, CPU_Consumida_Produccion_3, CPU_Consumida_Produccion_Backup, CPU_Consumida_Test_y_Preproduccion, CPU_Consumida_Integracion,CPU_Consumida_PPMM, CPU_Consumida_Produccion_4,CPU_Consumida_Centro_Respaldo_02, CPU_Consumida_Preproduccion, CPU_Consumida_Entorno_Test, CPU_Consumida_Test_PF, CPU_Consumida_Produccion1_PF, CPU_Consumida_Produccion2_PF, CPU_Consumida_Desarrollo_PF, CPU_Consumida_Escritorios_PF, CPU_Consumida_Preproduccion_PF ) 
SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
((SELECT SUM(CPU_Consumida_Mhz) FROM Elementos_virtuales) / (SELECT SUM(VCPUs_instaladas * 2400) FROM Elementos_virtuales)) * 100,
(((SELECT (CPU_Instalada_Centro_Respaldo) FROM CPU_Instalada_Ghz) - (SELECT (CPU_Disponible_Centro_Respaldo) FROM CPU_Disponible_Ghz)) / (SELECT (CPU_Instalada_Centro_Respaldo)FROM CPU_Instalada_Ghz)) * 100,
(((SELECT (CPU_Instalada_Escritorios) FROM CPU_Instalada_Ghz) - (SELECT (CPU_Disponible_Escritorios) FROM CPU_Disponible_Ghz)) / (SELECT (CPU_Instalada_Escritorios) FROM CPU_Instalada_Ghz)) * 100,
(((SELECT (CPU_Instalada_Produccion_1) FROM CPU_Instalada_Ghz) - (SELECT (CPU_Disponible_Produccion_1) FROM CPU_Disponible_Ghz)) / (SELECT (CPU_Instalada_Produccion_1) FROM CPU_Instalada_Ghz)) * 100,
(((SELECT (CPU_Instalada_Produccion_2) FROM CPU_Instalada_Ghz) - (SELECT (CPU_Disponible_Produccion_2) FROM CPU_Disponible_Ghz)) / (SELECT (CPU_Instalada_Produccion_2)FROM CPU_Instalada_Ghz)) * 100,
(((SELECT (CPU_Instalada_Produccion_3) FROM CPU_Instalada_Ghz) - (SELECT (CPU_Disponible_Produccion_3) FROM CPU_Disponible_Ghz)) / (SELECT (CPU_Instalada_Produccion_3) FROM CPU_Instalada_Ghz)) * 100,
(((SELECT (CPU_Instalada_Produccion_Backup) FROM CPU_Instalada_Ghz) - (SELECT (CPU_Disponible_Produccion_Backup) FROM CPU_Disponible_Ghz)) / (SELECT (CPU_Instalada_Produccion_Backup) FROM CPU_Instalada_Ghz)) * 100,
(((SELECT (CPU_Instalada_Test_y_Preproduccion) FROM CPU_Instalada_Ghz) - (SELECT (CPU_Disponible_Test_y_Preproduccion) FROM CPU_Disponible_Ghz)) / (SELECT (CPU_Instalada_Test_y_Preproduccion)FROM CPU_Instalada_Ghz)) * 100,
(((SELECT (CPU_Instalada_Integracion) FROM CPU_Instalada_Ghz) - (SELECT (CPU_Disponible_Integracion) FROM CPU_Disponible_Ghz)) / (SELECT (CPU_Instalada_Integracion) FROM CPU_Instalada_Ghz)) * 100,
(((SELECT (CPU_Instalada_PPMM) FROM CPU_Instalada_Ghz) -(SELECT (CPU_Disponible_PPMM) FROM CPU_Disponible_Ghz)) / (SELECT (CPU_Instalada_PPMM)FROM CPU_Instalada_Ghz)) * 100,
(((SELECT (CPU_Instalada_Produccion_4) FROM CPU_Instalada_Ghz) - (SELECT (CPU_Disponible_Produccion_4) FROM CPU_Disponible_Ghz)) / (SELECT (CPU_Instalada_Produccion_4) FROM CPU_Instalada_Ghz)) * 100, 
(((SELECT (CPU_Instalada_Centro_Respaldo_2) FROM CPU_Instalada_Ghz) - (SELECT (CPU_Disponible_Cerntro_Respaldo_02) FROM CPU_Disponible_Ghz)) / (SELECT (CPU_Instalada_Centro_Respaldo_2) FROM CPU_Instalada_Ghz)) * 100,
(((SELECT (CPU_Instalada_Preproduccion) FROM CPU_Instalada_Ghz) - (SELECT (CPU_Disponible_Preproduccion) FROM CPU_Disponible_Ghz)) / (SELECT (CPU_Instalada_Preproduccion) FROM CPU_Instalada_Ghz)) * 100,
(((SELECT (CPU_Instalada_Entorno_Test) FROM CPU_Instalada_Ghz) - (SELECT (CPU_Disponible_Entorno_Test) FROM CPU_Disponible_Ghz)) / (SELECT (CPU_Instalada_Entorno_Test) FROM CPU_Instalada_Ghz)) * 100,
(((SELECT (CPU_Instalada_Test_PF) FROM CPU_Instalada_Ghz) - (SELECT (CPU_Disponible_Test_PF) FROM CPU_Disponible_Ghz)) / (SELECT (CPU_Instalada_Test_PF) FROM CPU_Instalada_Ghz)) * 100,
(((SELECT (CPU_Instalada_Produccion1_PF) FROM CPU_Instalada_Ghz) - (SELECT (CPU_Disponible_Produccion1_PF) FROM CPU_Disponible_Ghz)) / (SELECT (CPU_Instalada_Produccion1_PF) FROM CPU_Instalada_Ghz)) * 100,
(((SELECT (CPU_Instalada_Produccion2_PF) FROM CPU_Instalada_Ghz) - (SELECT (CPU_Disponible_Produccion2_PF) FROM CPU_Disponible_Ghz)) / (SELECT (CPU_Instalada_Produccion2_PF) FROM CPU_Instalada_Ghz)) * 100,
(((SELECT (CPU_Instalada_Desarrollo_PF) FROM CPU_Instalada_Ghz) - (SELECT (CPU_Disponible_Desarrollo_PF) FROM CPU_Disponible_Ghz)) / (SELECT (CPU_Instalada_Desarrollo_PF) FROM CPU_Instalada_Ghz)) * 100,
(((SELECT (CPU_Instalada_Escritorios_PF) FROM CPU_Instalada_Ghz) - (SELECT (CPU_Disponible_Escritorios_PF) FROM CPU_Disponible_Ghz)) / (SELECT (CPU_Instalada_Escritorios_PF) FROM CPU_Instalada_Ghz)) * 100,
(((SELECT (CPU_Instalada_Preproduccion_PF) FROM CPU_Instalada_Ghz) - (SELECT (CPU_Disponible_Preproduccion_PF) FROM CPU_Disponible_Ghz)) / (SELECT (CPU_Instalada_Preproduccion_PF) FROM CPU_Instalada_Ghz)) * 100;

