
#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="VDI_sessions";
my $clus;
my $cpu_consum;
my $mem_consum;;


# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table(  id_VDIsessions, Poolname, VirtualMachineName, VirtualMachineIPAddress, CurrentUser, LastTimeLoggedIn, CurrentClientDevice, CurrentClientIPAddress) VALUES (?,?,?,?,?,?,?,?)");


open (INSERT, "vdi_datos.csv");

my $datos=0;

while(<INSERT>) {

$datos++;

chomp;

my ($poolname,$vmname,$vmip, $cu, $lastimelog, $cuclientdevice, $cuclientdevice, $cuclientipaddress) = split /,/;



$sth->execute($datos,$poolname,$vmname,$vmip,$cu, $lastimelog, $cuclientdevice, $cuclientipaddress);
               };

close (INSERT);

$dbh->disconnect;

