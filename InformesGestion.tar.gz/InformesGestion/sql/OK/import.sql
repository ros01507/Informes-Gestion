LOAD DATA local INFILE '/root/alfredo/scrt/sql/OK/salida.csv' INTO TABLE Address;
