Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Total_Numero_Hipervisores (Mes,Ano,Num_Hipervisores) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
COUNT(*) FROM `Informes_Gestion`.`Hipervisores`;
