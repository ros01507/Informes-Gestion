Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Num_vms_off (Mes,A�o,Num_vms) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
COUNT(*) FROM `Informes_Gestion`.`Elementos_virtuales` where Tipo_elemento_virtual =2;
