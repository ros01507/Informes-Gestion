DELETE FROM Nodos_Cluster;
