

pause


### CPU_Instalada ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.CPU_Instalada_Ghz (Mes,Ano,CPU_Total_Ghz, CPU_Instalada_Centro_Respaldo, CPU_Instalada_Escritorios, CPU_Instalada_Produccion_1,
CPU_Instalada_Produccion_2, CPU_Instalada_Produccion_3, CPU_Instalada_Produccion_Backup, CPU_Instalada_Test_y_Preproduccion, CPU_Instalada_Integracion, CPU_Instalada_Produccion_4,
 CPU_Instalada_Centro_Respaldo_2, CPU_Instalada_Preproduccion, CPU_Instalada_Entorno_Test, CPU_Instalada_PPMM, CPU_Instalada_Test_PF, CPU_Instalada_Produccion1_PF, CPU_Instalada_Produccion2_PF, CPU_Instalada_Desarrollo_PF, CPU_Instalada_Escritorios_PF, CPU_Instalada_Preproduccion_PF)
 SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores),(SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=1),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=2), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=3),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=4), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=5),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=6), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=7),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=8), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=11),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=12), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=13),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=14), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=9),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=15), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=16),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=17), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=18),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=20), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=21);

