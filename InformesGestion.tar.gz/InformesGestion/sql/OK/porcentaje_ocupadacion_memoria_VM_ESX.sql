Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Ratio_mem_vms_mem_ESX (Mes,A�o,mem_total_vms, mem_total_ESX, Ratio_mem_vms_por_mem_ESX) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()), (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales), (SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores), ((SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales) / (SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores)) * 100;

