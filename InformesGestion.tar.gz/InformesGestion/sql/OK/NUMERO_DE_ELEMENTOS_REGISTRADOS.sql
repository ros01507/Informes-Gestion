Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Num_elem_reg (Mes,Ano,Num_elem) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
COUNT(*) AS NUMERO_DE_ELEMENTOS_VIRTUALES FROM Elementos_virtuales;
