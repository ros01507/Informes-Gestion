Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Ratio_vcpus_por_core (Mes,Ano,vcpus,cores,Ratio_vcpus_por_core) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()), (SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales), (SELECT SUM(Num_cores) FROM Hipervisores), ((SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales) / (SELECT SUM(Num_cores) FROM Hipervisores));
