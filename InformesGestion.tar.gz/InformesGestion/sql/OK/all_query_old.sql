

# CPU_Disponible ###
Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.CPU_Disponible_Ghz (Mes,Ano,CPU_Total_Ghz,CPU_Disponible_Produccion1,CPU_Disponible_Cerntro_Respaldo_02,CPU_Disponible_PPMM,CPU_Disponible_Test_PF,CPU_Disponible_Produccion1_PF,CPU_Disponible_Produccion2_PF,CPU_Disponible_Desarrollo_PF,CPU_Disponible_Preproduccion_PF,CPU_Disponible_PreDimensionamiento_PF,CPU_Disponible_SQL_Produccion_PF,CPU_Disponible_SQL_Previos_PF,CPU_Disponible_Cerntro_Respaldo_03,CPU_Disponible_Escritorios_1,CPU_Disponible_Escritorios_2)
 SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()), (SELECT SUM(CPU_Instalada_Mhz /1024) FROM Hipervisores),
  ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=3) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=3)),
 ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=12) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=12)),
 ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=9) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=9)),
 ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=15) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=15)),
 ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=16) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=16)),
 ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=17) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=17)),
 ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=18) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=18)),
 ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=21) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=21)),
 ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=23) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=23)),
 ((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=22) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=22)),
((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=24) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=24)),
((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=26) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=26)),
((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=27) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=27)),
((SELECT SUM(CPU_Instalada_Mhz/1024) FROM Hipervisores WHERE IDCluster=24) - (SELECT SUM(CPU_Consumida_Mhz/1024) FROM Hipervisores WHERE IDCluster=28));

### CPU_Instalada ###


Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.CPU_Instalada_Ghz (Mes,Ano,CPU_Total_Ghz,CPU_Instalada_Produccion_1,CPU_Instalada_Centro_Respaldo_2,CPU_Instalada_PPMM,CPU_Instalada_Test_PF,CPU_Instalada_Produccion1_PF,CPU_Instalada_Produccion2_PF,CPU_Instalada_Desarrollo_PF,CPU_Instalada_Preproduccion_PF,CPU_Instalada_SQL_Produccion_PF,CPU_Instalada_Predimensionamiento_PF,CPU_Instalada_SQL_Previos_PF,CPU_Instalada_Centro_Respaldo_3,CPU_Instalada_Escritorios_1,CPU_Instalada_Escritorios_2)
 SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=3), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=12),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=9), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=15),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=16), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=17),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=18), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=21),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=22), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=23),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=24), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=26),
 (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=27), (SELECT SUM(CPU_Instalada_Mhz/1000) FROM Hipervisores WHERE IDCluster=28);
     
### Memoria_Asignada ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Memoria_asignada_vms (Mes,Ano,Memoria_media_asignada_vms,Memoria_asignada_vms_Produccion_1,Memoria_asignada_vms_PPMM,Memoria_asignada_vms_Test_PF,Memoria_asignada_vms_Produccion1_PF,Memoria_asignada_vms_Desarrollo_PF,Memoria_asignada_vms_Preproduccion_PF,Memoria_asignada_vms_SQL_Produccion_PF,Memoria_asignada_vms_PreDimensionamiento_PF,Memoria_asignada_vms_SQL_Previos_PF,Memoria_asignada_vms_Centro_Respaldo_02,Memoria_asignada_vms_Centro_Respaldo_03,Memoria_asignada_vms_Escritorios_1,Memoria_asignada_vms_Escritorios_2) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales),(SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=3),
 (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=9), (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=15),
 (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=16), (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=18),
 (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=21), (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=22),
 (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=23), (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=24),
 (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=12), (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=26),
 (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=27), (SELECT AVG(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=28);
  
 
### Memoria_Consumida ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Memoria_Consumida_Percent (Mes,Ano,
Memoria_Total_Percent,Memoria_Consumida_Produccion_1,Memoria_Consumida_PPMM,Memoria_Consumida_Centro_Respaldo_02,
Memoria_Consumida_Test_PF, Memoria_Consumida_Produccion1_PF, Memoria_Consumida_Produccion2_PF,
Memoria_Consumida_Desarrollo_PF,Memoria_Consumida_Preproduccion_PF,Memoria_Consumida_SQL_Produccion_PF,
Memoria_Consumida_PreDimensionamiento_PF,Memoria_Consumida_SQL_Previos_PF,Memoria_Consumida_Centro_Respaldo_03,
Memoria_Consumida_Escritorios_1,Memoria_Consumida_Escritorios_2)
SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT SUM(Memory_usage_percent) FROM RVT_ESXInfo ) / (SELECT count(*) FROM RVT_ESXInfo),
(SELECT SUM(Memory_usage_percent) FROM RVT_ESXInfo where Cluster='Produccion_01') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='Produccion_01'),
(SELECT SUM(Memory_usage_percent) FROM RVT_ESXInfo where Datacenter='Bankia-PPMM') / (SELECT count(*) FROM RVT_ESXInfo where Datacenter='Bankia-PPMM'),
(SELECT SUM(Memory_usage_percent) FROM RVT_ESXInfo where Cluster='CentroRespaldo_02') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='CentroRespaldo_02'),
(SELECT SUM(Memory_usage_percent) FROM RVT_ESXInfo where Cluster='Test') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='Test'),
(SELECT SUM(Memory_usage_percent) FROM RVT_ESXInfo where Cluster='Produccion1') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='Produccion1'),
(SELECT SUM(Memory_usage_percent) FROM RVT_ESXInfo where Cluster='Produccion2') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='Produccion2'),
(SELECT SUM(Memory_usage_percent) FROM RVT_ESXInfo where Cluster='Desarrollo') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='Desarrollo'),
(SELECT SUM(Memory_usage_percent) FROM RVT_ESXInfo where Cluster='Pre-Produccion') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='Pre-Produccion'),
(SELECT SUM(Memory_usage_percent) FROM RVT_ESXInfo where Cluster='SQL_Produccion') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='SQL_Produccion'),
(SELECT SUM(Memory_usage_percent) FROM RVT_ESXInfo where Cluster='Desarrollo') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='Desarrollo'),
(SELECT SUM(Memory_usage_percent) FROM RVT_ESXInfo where Cluster='SQL_Previos') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='SQL_Previos'),
(SELECT SUM(Memory_usage_percent) FROM RVT_ESXInfo where Cluster='CentroRespaldo_03') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='CentroRespaldo_03'),
(SELECT SUM(Memory_usage_percent) FROM RVT_ESXInfo where Cluster='Escritorios_1') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='Escritorios_1'),
(SELECT SUM(Memory_usage_percent) FROM RVT_ESXInfo where Cluster='Escritorios_2') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='Escritorios_2');


### Memoria_disponible ###

Insert into Informes_Gestion.Memoria_Disponible_GB (Mes,Ano,Memoria_Total_GB, Memoria_Disponible_Produccion_1,Memoria_Disponible_Test_PF,Memoria_Disponible_Pro1_PF, Memoria_Disponible_Pro2_PF, Memoria_Disponible_Desarrollo_PF,Memoria_Disponible_Preproduccion_PF,Memoria_Disponible_SQL_Produccion_PF,Memoria_Disponible_PreDimenssionamiento_PF,Memoria_Disponible_SQL_Previos_PF,Memoria_Disponible_Centro_Respaldo_02,Memoria_Disponible_Escritorios_1,Memoria_Disponible_Escritorios_2,Memoria_Disponible_Centro_Respaldo_03)
 SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()), (SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=3) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=3)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=15) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=15)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=16) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=16)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=17) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=17)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=18) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=18)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=21) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=21)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=22) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=22)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=23) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=23)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=24) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=24)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=12) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=12)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=27) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=27)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=28) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=28)),
((SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=26) - (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales WHERE Cluster=26));

###  memoria_instalada ###

 Insert into Informes_Gestion.Memoria_Instalada_GB 
 (Mes,Ano,Memoria_Total_GB, Memoria_Instalada_Produccion_1, Memoria_Instalada_Test_PF, Memoria_Instalada_Pro1_PF,Memoria_Instalada_Pro2_PF,  Memoria_Instalada_Desarrollo_PF, Memoria_Instalada_Preproduccion_PF, Memoria_Instalada_SQL_Produccion_PF, Memoria_Instalada_PreDimensionamiento_PF, Memoria_Instalada_SQL_Previos_PF, Memoria_Instalada_Centro_Respaldo_02,Memoria_Instalada_Centro_Respaldo_03,Memoria_Instalada_Escritorios_1, Memoria_Instalada_Escritorios_2)
 SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),(SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores),
(SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=3),(SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=15), 
(SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=16),(SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=17),
(SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=18),(SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=21), 
(SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=22),(SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=23),
(SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=24),(SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=12), 
(SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=26),(SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=27),
(SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores WHERE IDCluster=28);

###  memoria_media_asignada  ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Media_mem_asig_por_vm (Mes,Ano,Memoria_media_asignada_vms, Media_mem_asig_por_vm_Produccion_1,Media_mem_asig_por_vm_PPMM,Media_mem_asig_por_vm_Centro_Respaldo_02, Media_mem_asig_por_vm_Test_PF, Media_mem_asig_por_vm_Pro1_PF,Media_mem_asig_por_vm_Pro2_PF, Media_mem_asig_por_vm_Desarrollo_PF,Media_mem_asig_por_vm_Preproduccion_PF, Media_mem_asig_por_vm_SQL_Produccion_PF, Media_mem_asig_por_vm_PreDimensionamiento_PF, Media_mem_asig_por_vm_SQL_Previos_PF,Media_mem_asig_por_vm_Centro_Respaldo_03,Media_mem_asig_por_vm_Escritorios_1,Media_mem_asig_por_vm_Escritorios_2) 
SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=3),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=9),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=12),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=15),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=16),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=17),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=18),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=21),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=22),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=23),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=24),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=26),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=27),
(SELECT AVG (Memoria_instalada_MB) AS Memoria_instalada_MB FROM Elementos_virtuales WHERE Cluster=28);

### NUMERO_DE_ELEMENTOS_REGISTRADOS  ###


Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Num_elem_reg (Mes,Ano,Num_elem,Num_elem_PF) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT COUNT(*) AS NUMERO_DE_ELEMENTOS_VIRTUALES FROM Elementos_virtuales),(SELECT count(*) FROM Informes_Gestion.Virtuales_ESX  WHERE Vcenter LIKE '%s8kvcent%'  and Cluster NOT LIKE '%standalone%');

### NUMERO_DE_ELEMENTOS_REGISTRADOS_CLOUD  ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Num_elem_reg_CLOUD(Mes,Ano,Num_elem,Num_elem_Produccion,Num_elem_Desarrollo) SELECT MONTHNAME(CURDATE()),YEAR(CURDATE()),(SELECT COUNT(*)  FROM RVTvInfo where Cluster like 'Cloud_ROZ' ),(select count(*) from RVTvInfo where Cluster like 'Cloud_ROZ' and Network_1 not like 'LAN_V0628_64_28'), (select count(*) from RVTvInfo where Cluster like 'Cloud_ROZ' and Network_1 like 'LAN_V0628_64_28');

### NUMERO_DE_VMS_APAGADAS ###


Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Num_vms_off (Mes,Ano,Num_vms) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
COUNT(*) FROM `Informes_Gestion`.`Elementos_virtuales` where Tipo_elemento_virtual =2;

### NUMERO_DE_VMS_ENCENDID ###


Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Num_vms_on (Mes,Ano,Num_vms,Num_vms_FlexSystem) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT COUNT(*) FROM `Informes_Gestion`.`Elementos_virtuales` where Tipo_elemento_virtual =1), (SELECT COUNT(*) FROM `Informes_Gestion`.`Elementos_virtuales` where Tipo_elemento_virtual =1 AND Cluster=15 OR Cluster=16 OR Cluster=17 OR Cluster=18 OR Cluster=20 OR Cluster=21 OR Cluster=22 OR Cluster=23 OR Cluster=24);

### porcentaje_ocupadacion_memoria_VM_ESX ###


Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Ratio_mem_vms_mem_ESX (Mes,Ano,mem_total_vms, mem_total_ESX, Ratio_mem_vms_por_mem_ESX) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()), (SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales), (SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores), ((SELECT SUM(Memoria_instalada_MB/1024) FROM Elementos_virtuales) / (SELECT SUM(Memoria_Instalada_MB/1024) FROM Hipervisores)) * 100;

### Ratio_vcpus_por_core.sql  ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Ratio_vcpus_por_core (Mes,Ano,vcpus,cores,Ratio_vcpus_por_core, Ratio_vcpus_por_core_FlexSystem) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales), (SELECT SUM(Num_cores) FROM Hipervisores),
((SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales) / (SELECT SUM(Num_cores) FROM Hipervisores)),(SELECT((SELECT SUM(VCPUs_instaladas) FROM Elementos_virtuales where Cluster <> 12 and Cluster <> 27 and Cluster <> 28 and Cluster <> 3) / (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster <> 12 and IDCluster <> 27 and IDCluster <> 28 and IDCluster <> 3)));


### Total_vms_por_cluster  ###

use Informes_Gestion;
Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.vms_total_entorno (Mes,Ano,vms_Total_entorno, vms_total_Produccion_1, vms_total_PPMM, 
vms_total_Centro_Respaldo_02,vms_total_Test_PF, vms_total_Produccion1_PF, vms_total_Produccion2_PF, vms_total_Desarrollo_PF,
vms_total_Preproduccion_PF,vms_total_SQL_Produccion_PF, vms_total_PreDimensionamiento_PF, vms_total_SQL_Previos_PF,vms_total_Centro_Respaldo_03,
vms_total_Escritorios_1,vms_total_Escritorios_2) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT COUNT(*) FROM Elementos_virtuales),
(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=3),
(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=9),
(SELECT COUNT(*) FROM RVTvInfo WHERE Vcenter = 'v12kvppmm'), 
(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=15),
(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=16),
(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=17), 
(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=18),
(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=21), 
(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=21), 
(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=23),
(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=24),
(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=26), 
(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=27),
(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=28);


### Total_num_Hipervisores ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Total_Numero_Hipervisores (Mes,Ano,Num_Hipervisores,Num_Hipervisores_PF) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT COUNT(*) FROM Informes_Gestion.Hipervisores), 
(SELECT COUNT(*) FROM Informes_Gestion.Hipervisores WHERE IDCluster <> 12 AND IDCluster <> 27 AND IDCluster <> 28 AND IDCluster <> 3);

### Total_num_Hipervisores_CLOUD ###

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Total_Numero_Hipervisores_Cloud (Mes,Ano,Num_Hipervisores) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT COUNT(*)  FROM Informes_Gestion.RVT_ESXInfo where Cluster='Cloud_ROZ');

### AVG Media_memoria_consumida

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Media_mem_consumida_por_entorno (Mes, Ano,Media_mem_consumida_por_vm_Produccion_1,Media_mem_consumida_vm_Centro_Respaldo_02, Media_mem_consumida_vm_Test_PF, Media_mem_consumida_vm_Produccion1_PF, Media_mem_consumida_vm_Produccion2_PF, Media_mem_consumida_vm_Desarrollo_PF, Media_mem_consumida_vm_Preproduccion_PF ,Media_mem_consumida_vm_PreDimensionamiento_PF,Media_mem_consumida_vm_SQL_Produccion_PF,Media_mem_consumida_vm_SQL_Previos_PF, Media_mem_consumida_vm_Centro_Respaldo_03, Media_mem_consumida_vm_Escritorios_1, Media_mem_consumida_vm_Escritorios_2)
SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=3) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=3)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=12) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=12)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=15) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=15)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=16) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=16)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=17) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=17)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=18) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=18)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=21) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=21)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=23) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=23)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=22) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=22)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=24) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=24)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=26) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=26)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=27) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=27)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales WHERE Cluster=28) + (SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales WHERE Cluster=28));

#### Capacidad de crecimiento memoria #####

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Capacidad_crecimiento_Memoria (Mes, Ano, numero_vm_crecimiento_Memoria_Produccion_1, 
numero_vm_crecimiento_Memoria_Centro_Respaldo_02,numero_vm_crecimiento_Memoria_Test_PF, numero_vm_crecimiento_Memoria_Produccion1_PF, numero_vm_crecimiento_Memoria_Produccion2_PF, numero_vm_crecimiento_Memoria_Desarrollo_PF, numero_vm_crecimiento_Memoria_Preproduccion_PF ,numero_vm_crecimiento_Memoria_PreDimensionamiento_PF,numero_vm_crecimiento_SQL_Produccion_PF,numero_vm_crecimiento_SQL_Previos_PF,numero_vm_crecimiento_Memoria_Centro_Respaldo_03,numero_vm_crecimiento_Memoria_Escritorios_1,numero_vm_crecimiento_Memoria_Escritorios_2)
SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=3) / (SELECT (Media_mem_consumida_por_vm_Produccion_1) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=12) / (SELECT (Media_mem_consumida_vm_Centro_Respaldo_02) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=15) / (SELECT (Media_mem_consumida_vm_Test_PF) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=16) / (SELECT (Media_mem_consumida_vm_Produccion1_PF ) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=17) / (SELECT (Media_mem_consumida_vm_Produccion2_PF ) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=18) / (SELECT (Media_mem_consumida_vm_Desarrollo_PF ) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=21) / (SELECT (Media_mem_consumida_vm_Preproduccion_PF ) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=23) / (SELECT (Media_mem_consumida_vm_PreDimensionamiento_PF) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=22) / (SELECT (Media_mem_consumida_vm_SQL_Produccion_PF) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=24) / (SELECT (Media_mem_consumida_vm_SQL_Previos_PF) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=26) / (SELECT (Media_mem_consumida_vm_Centro_Respaldo_03 ) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=27) / (SELECT (Media_mem_consumida_vm_Escritorios_1) FROM Media_mem_consumida_por_entorno))),
(SELECT((SELECT (Memoria_Disponible_20Free) FROM Clusters_Memory WHERE ClusterID=28) / (SELECT (Media_mem_consumida_vm_Escritorios_2) FROM Media_mem_consumida_por_entorno)));


### Crecimiento_vm_por_CPU #####

Set lc_time_names = 'es_ES';
insert into Informes_Gestion. Capacidad_crecimiento_por_CPU (Mes,Ano,numero_vm_crecimiento_CPU_Produccion_1,numero_vm_crecimiento_CPU_Centro_Respaldo_02,numero_vm_crecimiento_CPU_Test_PF,numero_vm_crecimiento_CPU_Produccion1_PF,numero_vm_crecimiento_CPU_Produccion2_PF,numero_vm_crecimiento_CPU_Desarrollo_PF,numero_vm_crecimiento_CPU_Preproduccion_PF,numero_vm_crecimiento_CPU_PreDimensionamiento_PF,numero_vm_crecimiento_CPU_SQL_Produccion_PF,numero_vm_crecimiento_CPU_SQL_Previos_PF,numero_vm_crecimiento_CPU_Centro_Respaldo_03,numero_vm_crecimiento_CPU_Escritorios_1,numero_vm_crecimiento_CPU_Escritorios_2)
SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=3)* (4)) - (SELECT count(*) FROM Elementos_virtuales where Cluster=3 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=12)* 4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=12 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=15)* 4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=15 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=16)* 4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=16 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=17)* 4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=17 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=18)* 4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=18 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=21)*4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=21 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=23)*4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=23 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=22)*4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=22 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=24)*4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=24 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=26)*4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=26 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=27)*4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=27 AND Tipo_elemento_virtual=1),
(SELECT (SELECT SUM(Num_cores) FROM Hipervisores where IDCluster=28)*4) - (SELECT count(*) FROM Elementos_virtuales where Cluster=28 AND Tipo_elemento_virtual=1);


##### Espacio Libre Datastores #####

Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Espacio_Libre_Datastores (Mes,Ano, Libre_Total_Entorno,Libre_Produccion_1,Libre_PPMM,Libre_Centro_Respaldo_02,Libre_Entorno_Test_PF,Libre_Entorno_Produccion1_PF,Libre_Entorno_Produccion2_PF,Libre_Entorno_Desarrollo_PF,Libre_Entorno_Preproduccion_PF,Libre_Entorno_PreDimensionamiento_PF,Libre_Entorno_SQL_Produccion_PF,Libre_Entorno_SQL_Previos_PF,Libre_Centro_Respaldo_03,Libre_Escritorios_1,Libre_Escritorios_2)
SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT SUM(Libre_Datastore) FROM Datastores where  Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=3  and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=9  and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=12  and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=15  and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=16  and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=17  and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=18  and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=21  and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=23  and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=22  and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=24  and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=26  and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=27  and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=28  and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24');

##### Asignado Datastores #####


Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Espacio_Asignado_Datastore (Mes,Ano,Asignado_Total_Entorno,Asignado_Produccion_1,Asignado_PPMM,Asignado_Centro_Respaldo_02,Asignado_Test_PF,Asignado_Produccion1_PF,Asignado_Produccion2_PF,Asignado_Desarrollo_PF,Asignado_Preproduccion_PF,Asignado_PreDimensionamiento_PF,Asignado_SQL_Produccion_PF,Asignado_SQL_Previos_PF,Asignado_Centro_Respaldo_03,Asignado_Escritorios_1,Asignado_Escritorios_2) SELECT MONTHNAME(CURDATE()),YEAR(CURDATE()),
(SELECT SUM(Capacidad_Datastore) FROM Datastores where Grupo_Almacenamiento <> '23'and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=3 and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=9 and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=12 and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=15 and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=16 and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=17 and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=18 and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=21 and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=23 and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=22 and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=24 and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=26 and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=27 and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Capacidad_Datastore) FROM Datastores WHERE Cluster=28 and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24');



### CPU_Consumida ###


Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.CPU_Consumida_Percent (Mes,Ano,CPU_Total_Percent, CPU_Consumida_Produccion_1,
CPU_Consumida_PPMM,CPU_Consumida_Centro_Respaldo_02,CPU_Consumida_Test_PF,CPU_Consumida_Produccion1_PF,
CPU_Consumida_Produccion2_PF,CPU_Consumida_Desarrollo_PF,CPU_Consumida_Preproduccion_PF,
CPU_Consumida_PreDimensionamiento_PF,CPU_Consumida_SQL_Produccion_PF,CPU_Consumida_SQL_Previos_PF,
CPU_Consumida_Escritorios_1,CPU_Consumida_Escritorios_2,CPU_Consumida_Centro_Respaldo_03)
SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT SUM(CPU_usage_percent)FROM RVT_ESXInfo) / (SELECT count(*) FROM RVT_ESXInfo),
(SELECT SUM(CPU_usage_percent) FROM RVT_ESXInfo  where Cluster='Produccion_01') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='Produccion_01'),
(SELECT SUM(CPU_usage_percent) FROM RVT_ESXInfo  where Datacenter='Bankia-PPMM') / (SELECT count(*) FROM RVT_ESXInfo where Datacenter='Bankia-PPMM'),
(SELECT SUM(CPU_usage_percent) FROM RVT_ESXInfo  where Cluster='CentroRespaldo_02') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='CentroRespaldo_02'),
(SELECT SUM(CPU_usage_percent) FROM RVT_ESXInfo  where Cluster='Test') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='Test'),
(SELECT SUM(CPU_usage_percent) FROM RVT_ESXInfo  where Cluster='Produccion1') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='Produccion1'),
(SELECT SUM(CPU_usage_percent) FROM RVT_ESXInfo  where Cluster='Produccion2') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='Produccion2'),
(SELECT SUM(CPU_usage_percent) FROM RVT_ESXInfo  where Cluster='Desarrollo') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='Desarrollo'),
(SELECT SUM(CPU_usage_percent) FROM RVT_ESXInfo  where Cluster='Pre-Produccion') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='Pre-Produccion'),
(SELECT SUM(CPU_usage_percent) FROM RVT_ESXInfo  where Cluster='Desarrollo') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='Desarrollo'),
(SELECT SUM(CPU_usage_percent) FROM RVT_ESXInfo  where Cluster='SQL_Produccion') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='SQL_Produccion'),
(SELECT SUM(CPU_usage_percent) FROM RVT_ESXInfo  where Cluster='SQL_Previos') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='SQL_Previos'),
(SELECT SUM(CPU_usage_percent) FROM RVT_ESXInfo  where Cluster='Escritorios_1') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='Escritorios_1'),
(SELECT SUM(CPU_usage_percent) FROM RVT_ESXInfo  where Cluster='Escritorios_2') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='Escritorios_2'),
(SELECT SUM(CPU_usage_percent) FROM RVT_ESXInfo  where Cluster='CentroRespaldo_03') / (SELECT count(*) FROM RVT_ESXInfo where Cluster='CentroRespaldo_03');

