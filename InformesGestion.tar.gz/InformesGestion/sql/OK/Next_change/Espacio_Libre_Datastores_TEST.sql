Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Espacio_Libre_Datastores_TEST
(Mes,Ano, Libre_Total_Entorno, Libre_Centro_Respaldo,
Libre_Escritorios, Libre_Produccion_1, Libre_Produccion_2, Libre_Produccion_3,
Libre_Produccion_Backup, Libre_Test_y_Preproduccion, Libre_Integracion,
Libre_PPMM, Libre_Produccion_4, Libre_Preproduccion, Libre_Centro_Respaldo_02) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT SUM(Libre_Datastore) FROM Datastores where Grupo_Almacenamiento <> '1'
and Grupo_Almacenamiento <> '23' and Grupo_Almacenamiento <> '24'),
(SELECT SUM(Libre_Datastore) FROM Datastores WHERE Cluster=1 and
Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23' and
Grupo_Almacenamiento <> '24'), (SELECT SUM(Libre_Datastore) FROM Datastores
WHERE Cluster=2 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23'
and Grupo_Almacenamiento <> '24'), (SELECT SUM(Libre_Datastore) FROM Datastores
WHERE Cluster=3 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23'
and Grupo_Almacenamiento <> '24'), (SELECT SUM(Libre_Datastore) FROM Datastores
WHERE Cluster=4 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23'
and Grupo_Almacenamiento <> '24'),(SELECT SUM(Libre_Datastore) FROM Datastores
WHERE Cluster=5 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23'
and Grupo_Almacenamiento <> '24'),(SELECT SUM(Libre_Datastore) FROM Datastores
WHERE Cluster=6 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23'
and Grupo_Almacenamiento <> '24'), (SELECT SUM(Libre_Datastore) FROM Datastores
WHERE Cluster=7 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23'
and Grupo_Almacenamiento <> '24'),(SELECT SUM(Libre_Datastore) FROM Datastores
WHERE Cluster=8 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23'
and Grupo_Almacenamiento <> '24'),(SELECT SUM(Libre_Datastore) FROM Datastores
WHERE Cluster=10 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23'
and Grupo_Almacenamiento <> '24'),(SELECT SUM(Libre_Datastore) FROM Datastores
WHERE Cluster=11 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23'
and Grupo_Almacenamiento <> '24'), (SELECT SUM(Libre_Datastore) FROM Datastores
WHERE Cluster=13 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23'
and Grupo_Almacenamiento <> '24'), (SELECT SUM(Libre_Datastore) FROM Datastores
WHERE Cluster=12 and Grupo_Almacenamiento <> '1' and Grupo_Almacenamiento <> '23'
and Grupo_Almacenamiento <> '24');
