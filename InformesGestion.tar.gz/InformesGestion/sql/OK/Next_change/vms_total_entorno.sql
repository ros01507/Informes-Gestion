Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.vms_total_entorno_TEST (Mes,Ano,vms_Total_entorno,
vms_total_Centro_Respaldo, vms_total_Escritorios, vms_total_Produccion_1,
vms_total_Produccion_2, vms_total_Produccion_3, vms_total_Produccion_Backup,
vms_total_Test_y_Preproduccion, vms_total_Integracion, vms_total_PPMM,
vms_total_Produccion_4, vms_total_Preproduccion, vms_total_Centro_Respaldo_02 )
SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT COUNT(*) FROM Elementos_virtuales),(SELECT COUNT(*) FROM 
Elementos_virtuales WHERE Cluster=1), (SELECT COUNT(*) FROM Elementos_virtuales 
WHERE Cluster=2), (SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=3),
(SELECT COUNT(*) FROM Elementos_virtuales WHERE Cluster=4), (SELECT COUNT(*) 
FROM Elementos_virtuales WHERE Cluster=5), (SELECT COUNT(*) 
FROM Elementos_virtuales WHERE Cluster=6), (SELECT COUNT(*) 
FROM Elementos_virtuales WHERE Cluster=7), (SELECT COUNT(*)
FROM Elementos_virtuales WHERE Cluster=8), (SELECT COUNT(*) 
FROM Elementos_virtuales WHERE Cluster=9), (SELECT COUNT(*)
FROM Elementos_virtuales WHERE Cluster=11), (SELECT COUNT(*)
FROM Elementos_virtuales WHERE Cluster=12), (SELECT COUNT(*)
FROM Elementos_virtuales WHERE Cluster=13), (SELECT COUNT(*)
FROM Elementos_virtuales WHERE Cluster=14;

