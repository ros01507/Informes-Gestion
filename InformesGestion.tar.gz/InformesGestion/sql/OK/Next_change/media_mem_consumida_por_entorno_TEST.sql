Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Media_mem_consumida_por_entorno_TEST
(Mes, Ano, Media_mem_consumida_vm_Centro_Respaldo,
Media_mem_consumida_por_vm_Escritorios,
Media_mem_consumida_por_vm_Produccion_1,
Media_mem_consumida_por_vm_Produccion_2,
Media_mem_consumida_por_vm_Produccion_3,
Media_mem_consumida_por_vm_Produccion_Backup,
Media_mem_consumida_por_vm_Test_y_Preproduccion,
Media_mem_consumida_por_vm_Integracion,
Media_mem_consumida_por_vm_Produccion_4,
Media_mem_consumida_por_vm_Preproduccion,
Media_mem_consumida_por_vm_Centro_Respaldo_02
)
SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()), 
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM
Elementos_virtuales WHERE Cluster=1) +
(SELECT AVG (Memoria_consumida_overhead)
FROM Elementos_virtuales WHERE Cluster=1)),
(SELECT(SELECT AVG (Memoria_consumida_MB)
FROM Elementos_virtuales WHERE Cluster=2)
+ (SELECT AVG (Memoria_consumida_overhead) 
FROM Elementos_virtuales WHERE Cluster=2)),
(SELECT(SELECT AVG (Memoria_consumida_MB)
FROM Elementos_virtuales WHERE Cluster=3)
+ (SELECT AVG (Memoria_consumida_overhead)
FROM Elementos_virtuales WHERE Cluster=3)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales
WHERE Cluster=4) + (SELECT AVG (Memoria_consumida_overhead) FROM
Elementos_virtuales WHERE Cluster=4)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales
WHERE Cluster=5) + (SELECT AVG (Memoria_consumida_overhead)
FROM Elementos_virtuales WHERE Cluster=5)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales
WHERE Cluster=6) + (SELECT AVG (Memoria_consumida_overhead)
FROM Elementos_virtuales WHERE Cluster=6)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales
WHERE Cluster=7) + (SELECT AVG (Memoria_consumida_overhead)
FROM Elementos_virtuales WHERE Cluster=7)),
(SELECT(SELECT AVG (Memoria_consumida_MB) FROM Elementos_virtuales
WHERE Cluster=8) + (SELECT AVG (Memoria_consumida_overhead)
FROM Elementos_virtuales WHERE Cluster=8)),
(SELECT(SELECT AVG (Memoria_consumida_MB) 
FROM Elementos_virtuales WHERE Cluster=11) +
(SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales
WHERE Cluster=11)), (SELECT(SELECT AVG (Memoria_consumida_MB) 
FROM Elementos_virtuales WHERE Cluster=13) +
(SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales
WHERE Cluster=13)),(SELECT(SELECT AVG (Memoria_consumida_MB) 
FROM Elementos_virtuales WHERE Cluster=12) +
(SELECT AVG (Memoria_consumida_overhead) FROM Elementos_virtuales
WHERE Cluster=12));

