#/bin/bash
LIST="ls *.sql"
for i in $LIST;
do iconv -f WINDOWS-1252 -t UTF8 $i -o $i..utf8.;
mv $i..utf8. $i;
done


