Set lc_time_names = 'es_ES';
Insert into Informes_Gestion.Total_Numero_Hipervisores_Cloud_Semanal (Mes,Ano,Num_Hipervisores) SELECT MONTHNAME(CURDATE()), YEAR(CURDATE()),
(SELECT COUNT(*)  FROM Informes_Gestion.RVT_ESXInfo where Cluster='Cloud_ROZ');

Insert into Informes_Gestion.Num_elem_reg_CLOUD_semanal(Mes,Ano,Num_elem,Num_elem_Produccion,Num_elem_Desarrollo) SELECT MONTHNAME(CURDATE()),YEAR(CURDATE()),(SELECT COUNT(*)  FROM RVTvInfo where Cluster like 'Cloud_ROZ' ),(select count(*) from RVTvInfo where Cluster like 'Cloud_ROZ' and Network_1 not like 'LAN_V0628_64_28'), (select count(*) from RVTvInfo where Cluster like 'Cloud_ROZ' and Network_1 like 'LAN_V0628_64_28');
