#!/usr/bin/perl
use DBI;
# MYSQL CONFIG VARIABLES
my $host = "vlirompf.cm.es";
my $database = "Informes_Gestion";
my $user = "root";
my $pw = "LyD:2TmT";
my $table="Elementos_virtuales";

# PERL MYSQL CONNECT()

my $dsn = "dbi:mysql:$database:$host:3306";
my $dbh = DBI->connect($dsn, $user, $pw);

$sth = $dbh->prepare("INSERT INTO $table(idVMs, Hostname, VCPUs_instaladas, Memoria_instalada_MB, Almacenamiento_instalado_GB) VALUES (?,?,?,?,?)");
$sth->execute( 1, 2, 3, 4, 5 );

$dbh->disconnect;
