
result1=$(mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select Nombre_VM,Cluster from Virtuales_ESX where  ESX LIKE 'svmro%' and Path_VMX  NOT LIKE  '%ROZ_%'  and Vcenter LIKE 'v12kvcent%'")

result2=$(mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select Nombre_VM,Cluster from Virtuales_ESX where  ESX LIKE 'svmsh%' and Path_VMX NOT LIKE  '%COR_%' and Vcenter LIKE 'v12kvcent%'")

RESULT=$result1" "$result2
echo "##"$RESULT"##"
if [[ -z $RESULT ]]
then 

echo "NULL"
else
sh "/root/InformesGestion/sql/rozas_cor.sh" > "/root/InformesGestion/sql/vms_rozas_cor.txt"
mail "aalcalap@bankia.com,ivillanova@externos.bankia.com,raguilera@externos.bankia.com,rarellano@externos.bankia.com,jmatamoros@externos.bankia.com,jduran@externos.bankia.com,jlopezt@externos.bankia.com" -s "Maquinas Cruzadas"  < "/root/InformesGestion/sql/vms_rozas_cor.txt"
 
fi
