FILENAME=vms
count=0
IFS='
'
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select * from Clusters"
cat $FILENAME | while read LINE
do
       let count++
  mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select Hostname,Almacenamiento_instalado_GB,Cluster from Elementos_virtuales where Hostname LIKE '$LINE%' and Hostname NOT LIKE '%_replica'"     
done
