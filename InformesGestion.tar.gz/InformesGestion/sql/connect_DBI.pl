#!/usr/bin/perl
use DBI;
# MYSQL CONFIG VARIABLES
my $host = "vlirompf.cm.es";
my $database = "Informes_Gestion";
my $table = "Tipo_elemento";
my $user = "root";
my $pw = "LyD:2TmT";

# PERL MYSQL CONNECT()

my $dsn = "dbi:mysql:$database:$host:3306";
my $connect = DBI->connect($dsn, $user, $pw);

$qry = "select * from $table";
my $sqlexe = $connect->prepare($qry);
$sqlexe->execute or die "SQL Error: $DBI::errstrr\n";
while (@row = $sqlexe->fetchrow_array){
print "@row\n";
}

# PERL DBI DISCONNECT



$DBIconnect = DBI->connect($dsn, $user, $pw);

