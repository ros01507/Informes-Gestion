FILENAME='vms'
count=0
IFS='
'
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select * from Clusters"
cat $FILENAME | while read LINE
do

#mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select Hostname,Almacenamiento_instalado_GB,Cluster from Elementos_virtuales where Hostname LIKE '$LINE%' and VMname NOT LIKE '%_replica'" 
    
#mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select Almacenamiento_instalado_GB from Elementos_virtuales where Hostname LIKE '$LINE%' and VMname NOT LIKE '%_replica'"

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select VMname,Almacenamiento_instalado_GB from Elementos_virtuales where Hostname LIKE '$LINE%' OR VMname LIKE '$LINE%' and VMname NOT LIKE '%_replica'"


done
