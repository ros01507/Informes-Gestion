FILENAME=PowerOff_out
count=0
IFS='
'
cat $FILENAME | while read LINE
do
       let count++
  mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select * from Locales_PendientesMigrar  where Nombre_VM LIKE '%LINE$%'"     
done
