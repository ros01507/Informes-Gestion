FILENAME=vms1
count=0
IFS='
'
cat $FILENAME | while read LINE
do
       let count++
  mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select Hostname,Memoria_Consumida_MB from Elementos_virtuales where Hostname LIKE '$LINE%'"
done
