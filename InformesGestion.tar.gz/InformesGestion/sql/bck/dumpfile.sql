-- MySQL dump 10.11
--
-- Host: VLIROMPF.cm.es    Database: 
-- ------------------------------------------------------
-- Server version	5.0.77

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `Informes_Gestion`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `Informes_Gestion` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `Informes_Gestion`;

--
-- Table structure for table `CPU_Consumida_Percent`
--

DROP TABLE IF EXISTS `CPU_Consumida_Percent`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `CPU_Consumida_Percent` (
  `idCPU_Consumida_Percent` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Mes` varchar(45) character set latin1 default NULL,
  `Ano` int(11) default NULL,
  `CPU_Total_Percent` int(11) default NULL,
  `CPU_Consumida_Centro_Respaldo` int(11) default NULL,
  `CPU_Consumida_Escritorios` int(11) default NULL,
  `CPU_Consumida_Produccion_1` int(11) default NULL,
  `CPU_Consumida_Produccion_2` int(11) default NULL,
  `CPU_Consumida_Produccion_3` int(11) default NULL,
  `CPU_Consumida_Produccion_Backup` int(11) default NULL,
  `CPU_Consumida_Test_y_Preproduccion` int(11) default NULL,
  `CPU_Consumida_Integracion` int(11) default NULL,
  PRIMARY KEY  (`idCPU_Consumida_Percent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `CPU_Consumida_Percent`
--

LOCK TABLES `CPU_Consumida_Percent` WRITE;
/*!40000 ALTER TABLE `CPU_Consumida_Percent` DISABLE KEYS */;
INSERT INTO `CPU_Consumida_Percent` VALUES ('2012-02-29 17:00:26','febrero',2012,11,6,15,10,9,11,8,10,3),('2012-03-28 12:09:01','marzo',2012,9,6,13,9,10,10,8,5,0),('2012-04-27 00:26:00','abril',2012,7,6,8,8,10,7,7,5,0);
/*!40000 ALTER TABLE `CPU_Consumida_Percent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CPU_Disponible_Ghz`
--

DROP TABLE IF EXISTS `CPU_Disponible_Ghz`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `CPU_Disponible_Ghz` (
  `idCPU_Disponible_Ghz` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Mes` varchar(45) default NULL,
  `Ano` int(11) default NULL,
  `CPU_Total_Ghz` float default NULL,
  `CPU_Disponible_Centro_Respaldo` float default NULL,
  `CPU_Disponible_Escritorios` float default NULL,
  `CPU_Disponible_Produccion_1` float default NULL,
  `CPU_Disponible_Produccion_2` float default NULL,
  `CPU_Disponible_Produccion_3` float default NULL,
  `CPU_Disponible_Produccion_Backup` float default NULL,
  `CPU_Disponible_Test_y_Preproduccion` float default NULL,
  `CPU_Disponible_Integracion` float default NULL,
  PRIMARY KEY  (`idCPU_Disponible_Ghz`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `CPU_Disponible_Ghz`
--

LOCK TABLES `CPU_Disponible_Ghz` WRITE;
/*!40000 ALTER TABLE `CPU_Disponible_Ghz` DISABLE KEYS */;
INSERT INTO `CPU_Disponible_Ghz` VALUES ('2012-02-29 12:09:32','febrero',2012,1453.17,99.1711,228.458,250.302,128.089,80.8094,111.047,69.914,97.7258),('2012-03-28 12:09:01','marzo',2012,1453.17,96.9748,238.645,255.864,115.351,91.7865,111.456,92.0218,98.7899),('2012-04-27 00:26:00','abril',2012,1867.89,97.2593,231.861,270.014,114.949,105.438,111.388,104.403,118.402);
/*!40000 ALTER TABLE `CPU_Disponible_Ghz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CPU_Instalada_Ghz`
--

DROP TABLE IF EXISTS `CPU_Instalada_Ghz`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `CPU_Instalada_Ghz` (
  `idCPU_Instalada_Ghz` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Mes` varchar(45) character set latin1 default NULL,
  `Ano` int(11) default NULL,
  `CPU_Total_Ghz` float default NULL,
  `CPU_Instalada_Centro_Respaldo` float default NULL,
  `CPU_Instalada_Escritorios` float default NULL,
  `CPU_Instalada_Produccion_1` float default NULL,
  `CPU_Instalada_Produccion_2` float default NULL,
  `CPU_Instalada_Produccion_3` float default NULL,
  `CPU_Instalada_Produccion_Backup` float default NULL,
  `CPU_Instalada_Test_y_Preproduccion` float default NULL,
  `CPU_Instalada_Integracion` float default NULL,
  PRIMARY KEY  (`idCPU_Instalada_Ghz`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `CPU_Instalada_Ghz`
--

LOCK TABLES `CPU_Instalada_Ghz` WRITE;
/*!40000 ALTER TABLE `CPU_Instalada_Ghz` DISABLE KEYS */;
INSERT INTO `CPU_Instalada_Ghz` VALUES ('2012-02-29 15:53:11','febrero',2012,1488.04,115.204,307.211,345.612,172.806,153.603,115.204,177.068,101.337),('2012-03-28 12:09:01','marzo',2012,1488.04,115.204,307.211,345.612,172.806,153.603,115.204,177.068,101.337),('2012-04-27 00:26:00','abril',2012,1912.72,115.204,307.211,345.612,172.806,153.603,115.204,177.068,121.604);
/*!40000 ALTER TABLE `CPU_Instalada_Ghz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Clusters`
--

DROP TABLE IF EXISTS `Clusters`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Clusters` (
  `idCluster` int(11) NOT NULL,
  `Nombre_Cluster` varchar(45) character set latin1 default NULL,
  PRIMARY KEY  (`idCluster`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Clusters`
--

LOCK TABLES `Clusters` WRITE;
/*!40000 ALTER TABLE `Clusters` DISABLE KEYS */;
INSERT INTO `Clusters` VALUES (1,'CentroRespaldo_01'),(2,'Escritorios'),(3,'Produccion_01'),(4,'Produccion_02'),(5,'Produccion_03'),(6,'Produccion_Backup'),(7,'Test_y_Preprod_01'),(8,'Aranea_01'),(9,'Otros'),(10,'Standalone');
/*!40000 ALTER TABLE `Clusters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Datastores`
--

DROP TABLE IF EXISTS `Datastores`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Datastores` (
  `idDatastore` int(11) NOT NULL,
  `Nombre_datastore` varchar(45) character set latin1 default NULL,
  `Ocupacion_Percent` float default NULL,
  `Cluster` int(11) default NULL,
  `Grupo_Almacenamiento` int(11) default NULL,
  `Capacidad_Datastore` int(11) default NULL,
  `Ocupado_Datastore` int(11) default NULL,
  `Libre_Datastore` int(11) default NULL,
  PRIMARY KEY  (`idDatastore`),
  KEY `Grupo almacenamiento` (`idDatastore`),
  KEY `Clusterid` (`idDatastore`),
  KEY `Grupo_Almacenamiento` (`Grupo_Almacenamiento`),
  KEY `Cluster` (`Cluster`),
  CONSTRAINT `Grupo_Almacenamiento` FOREIGN KEY (`Grupo_Almacenamiento`) REFERENCES `Grupos_almacenamiento` (`idGrupos_almacenamiento`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Cluster` FOREIGN KEY (`Cluster`) REFERENCES `Clusters` (`idCluster`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Datastores`
--

LOCK TABLES `Datastores` WRITE;
/*!40000 ALTER TABLE `Datastores` DISABLE KEYS */;
INSERT INTO `Datastores` VALUES (1,'cor015-clcr01',56.73,1,4,267,151,115),(2,'cor016-clcr01',94.49,1,4,267,252,15),(3,'cor017-clcr01',64.36,1,4,267,172,95),(4,'cor018-clcr01',87.55,1,4,267,234,33),(5,'cor019-clcr01',84.25,1,4,267,225,42),(6,'cor020-clcr01',86.11,1,4,267,230,37),(7,'cor022-clcr01',93.54,1,4,267,250,17),(8,'cor023-clcr01',75.53,1,4,534,403,131),(9,'cor024-clcr01',69.2,1,4,534,369,164),(10,'cor025-clcr01',91.31,1,4,534,487,46),(11,'cor026-clcr01',89.67,1,4,534,479,55),(12,'cor027-clcr01',80.84,1,4,267,216,51),(13,'cor021-clcr01',0.21,1,4,262,1,261),(14,'cor005-clcr01',28.25,1,4,267,75,191),(15,'cor013-clcr01',73.94,1,4,534,395,139),(16,'cor001-clcr01',40.97,1,4,267,109,157),(17,'cor014-clcr01',11.79,1,4,534,63,471),(18,'cor002-clcr01',12.94,1,4,801,104,697),(19,'cor003-clcr01',25.59,1,4,534,137,397),(20,'cor004-clcr01',9.85,1,4,534,53,481),(21,'cor006-clcr01',12.34,1,4,534,66,468),(22,'cor007-clcr01',21.44,1,4,534,114,419),(23,'cor008-clcr01',9.85,1,4,534,53,481),(24,'prosa008-naro01',27.98,2,6,600,168,432),(25,'pro124-clro02',88.01,2,2,534,470,64),(26,'pro126-clro02',85.08,2,2,534,454,80),(27,'pro127-clro02',92.43,2,2,534,493,40),(28,'pro128-clro02',94.22,2,2,534,503,31),(29,'pro130-clro02',92.87,2,2,535,497,38),(30,'prosa001-naro01',85.76,2,6,600,515,85),(31,'prosa002-naro01',90.09,2,6,600,541,59),(32,'prosa003-naro01',87,2,6,600,522,78),(33,'prosa004-naro01',82.8,2,6,600,497,103),(34,'prosa005-naro01',89.6,2,6,600,538,62),(35,'prosa006-naro01',86.44,2,6,600,519,81),(36,'prosa007-naro01',85.17,2,6,600,511,89),(37,'prosa009-naro01',64.26,2,6,600,386,214),(38,'prosa010-naro01',88.45,2,6,600,531,69),(39,'isos',75.66,2,13,226,171,55),(40,'prosa011-naro01',73.39,2,6,600,440,160),(41,'prosa012-naro01',85.47,2,6,600,513,87),(42,'prosa013-naro01',54.95,2,6,600,330,270),(43,'prosa014-naro01-lab',59.87,2,7,600,359,241),(44,'prosa015-naro01-lab',40.72,2,7,600,244,356),(45,'prosa016-naro01-lab',47.94,2,7,600,288,312),(46,'NFS_SATA',0.54,2,12,3705,20,3685),(47,'prosa017-naro01',87.64,2,6,600,526,74),(48,'prosa018-naro01',89.14,2,6,600,535,65),(49,'prosa019-naro01',88.6,2,6,600,532,68),(50,'pro137-clro02',73.62,2,2,535,394,141),(51,'pro138-clro02',87.53,2,2,535,468,67),(52,'prosa020-naro01',5.93,2,6,600,36,564),(53,'prosa021-naro01',46.6,2,6,600,280,320),(54,'prosa022-naro01-linked',6.45,2,13,600,39,561),(55,'pro125-clro02',88.22,2,2,534,471,63),(56,'pro131-clro02',89.67,2,2,534,479,55),(57,'pro132-clro02',92.44,2,2,534,493,40),(58,'pro133-clro02',90.1,2,2,534,481,53),(59,'pro134-clro02',93.77,2,2,534,501,33),(60,'pro135-clro02',90.56,2,2,534,483,50),(61,'pro136-clro02',87.24,2,2,534,466,68),(62,'prosa024-naro01',0.09,2,6,600,1,599),(63,'prosa025-naro01',0.09,2,6,600,1,599),(64,'prosa026-naro01',5.93,2,6,600,36,564),(65,'prosa027-naro01',5.93,2,6,600,36,564),(66,'prosa028-naro01',22.61,2,6,600,136,464),(67,'prosa029-naro01',29.26,2,6,600,176,424),(68,'pro024-clro01',84.94,3,1,311,264,47),(69,'pro039-clro01',86.89,3,1,267,232,35),(70,'pro015-clro01',70.09,3,1,535,375,160),(71,'pro017-clro01',91.45,3,1,535,489,46),(72,'pro066-clro03',87.55,3,3,266,233,33),(73,'pro070-clro03',92.12,3,3,266,245,21),(74,'pro072-clro03',79.29,3,3,266,211,55),(75,'pro073-clro03',67.67,3,3,266,180,86),(76,'pro074-clro03',92.08,3,3,266,245,21),(77,'pro095-clro03',67.45,3,3,268,181,87),(78,'pro097-clro03',85.77,3,3,268,230,38),(79,'pro106-clro03',90.62,3,3,268,243,25),(80,'pro107-clro03',82.81,3,3,268,222,46),(81,'pro108-clro03',83.9,3,3,268,225,43),(82,'pro109-clro03',89.5,3,3,268,240,28),(83,'pro111-clro03',87.66,3,3,268,235,33),(84,'pro115-clro03',83.85,3,3,268,225,43),(85,'pro118-clro03',82.38,3,3,268,221,47),(86,'pro124-clro02',88.01,3,2,534,470,64),(87,'pro126-clro02',85.08,3,2,534,454,80),(88,'pro127-clro02',92.43,3,2,534,493,40),(89,'pro128-clro02',94.22,3,2,534,503,31),(90,'pro130-clro02',92.87,3,2,535,497,38),(91,'templates',55.37,3,13,100,55,45),(92,'pro032-clro01',89.08,3,1,267,238,29),(93,'pro031-clro01',84.49,3,1,267,225,41),(94,'pro030-clro01',90.99,3,1,267,243,24),(95,'pro029-clro01',87.82,3,1,267,234,32),(96,'pro028-clro01',82.72,3,1,267,221,46),(97,'pro027-clro01',89.67,3,1,267,239,28),(98,'pro026-clro01',81.24,3,1,311,252,58),(99,'pro025-clro01',94.29,3,1,311,293,18),(100,'pro033-clro01',84.98,3,1,267,227,40),(101,'pro035-clro01',88.16,3,1,267,235,32),(102,'pro037-clro01',88.74,3,1,267,237,30),(103,'pro041-clro01',91.39,3,1,534,488,46),(104,'pro034-clro01',90.78,3,1,267,242,25),(105,'pro036-clro01',87.25,3,1,267,233,34),(106,'pro038-clro01',72.34,3,1,267,193,74),(107,'pro040-clro01',80.61,3,1,267,215,52),(108,'pro042-clro01',93.82,3,1,534,501,33),(109,'pro000-clro01',55.8,3,1,100,56,44),(110,'pro010-clro01',75.86,3,1,100,76,24),(111,'pro006-clro01',65.32,3,1,100,65,35),(112,'pro002-clro01',83.93,3,1,200,168,32),(113,'pro013-clro01',59.04,3,1,60,35,24),(114,'pro008-clro01',63.44,3,1,100,63,36),(115,'pro011-clro01',83.83,3,1,300,251,48),(116,'pro014-clro01',92.8,3,1,340,315,24),(117,'pro018-clro01',95.2,3,1,200,190,10),(118,'pro012-clro01',81.88,3,1,250,204,45),(119,'pro020-clro01',79.82,3,1,200,159,40),(120,'pro137-clro02',73.62,3,2,535,394,141),(121,'pro138-clro02',87.53,3,2,535,468,67),(122,'pro003-clro01',75.83,3,1,100,76,24),(123,'pro005-clro01',64.22,3,1,200,128,71),(124,'pro007-clro01',66.64,3,1,100,66,33),(125,'pro009-clro01',75.96,3,1,100,76,24),(126,'pro019-clro01',85.16,3,1,200,170,30),(127,'pro001-clro01',76.8,3,1,100,77,23),(128,'pro016-clro01',27.06,3,1,65,18,47),(129,'pro023-clro01',87.91,3,1,267,235,32),(130,'pro043-clro01',90.8,3,1,267,242,25),(131,'pro044-clro01',87.17,3,1,267,233,34),(132,'pro045-clro01',88.98,3,1,267,237,29),(133,'pro046-clro01',87.83,3,1,267,234,32),(134,'pro047-clro01',88.51,3,1,267,236,31),(135,'pro048-clro01',94.65,3,1,267,252,14),(136,'pro049-clro01',89.74,3,1,267,239,27),(137,'pro050-clro01',69.12,3,1,267,184,82),(138,'pro051-clro01',91.63,3,1,267,244,22),(139,'pro052-clro01',87.64,3,1,267,234,33),(140,'pro053-clro01',90.98,3,1,267,243,24),(141,'pro054-clro01',93.98,3,1,267,251,16),(142,'pro055-clro01',89.45,3,1,267,239,28),(143,'pro056-clro01',79.29,3,1,267,212,55),(144,'pro057-clro01',93.99,3,1,267,251,16),(145,'pro058-clro01',83.41,3,1,267,223,44),(146,'pro059-clro01',85.81,3,1,267,229,38),(147,'pro021-clro01',91.67,3,1,532,487,44),(148,'pro022-clro01',94.19,3,1,532,501,31),(149,'pro060-clro03',93.95,3,3,266,250,16),(150,'pro061-clro03',91.3,3,3,266,243,23),(151,'pro062-clro03',93.82,3,3,266,249,16),(152,'pro063-clro03',89.06,3,3,266,237,29),(153,'pro064-clro03',90.18,3,3,266,240,26),(154,'pro065-clro03',85.97,3,3,266,228,37),(155,'pro067-clro03',92.82,3,3,266,247,19),(156,'pro068-clro03',75.51,3,3,266,201,65),(157,'pro069-clro03',85.04,3,3,266,226,40),(158,'pro071-clro03',84.37,3,3,266,224,42),(159,'pro075-clro03',89.71,3,3,266,238,27),(160,'pro076-clro03',86.72,3,3,266,230,35),(161,'pro077-clro03',88.22,3,3,266,234,31),(162,'pro078-clro03',91.06,3,3,402,366,36),(163,'pro079-clro03',94.47,3,3,402,380,22),(164,'pro080-clro03',61.53,3,3,402,247,155),(165,'pro081-clro03',77.59,3,3,402,312,90),(166,'pro082-clro03',94,3,3,402,378,24),(167,'pro083-clro03',92.68,3,3,402,372,29),(168,'pro084-clro03',88.5,3,3,402,356,46),(169,'pro085-clro03',90.2,3,3,402,362,39),(170,'pro086-clro03',92.62,3,3,402,372,30),(171,'pro087-clro03',94.48,3,3,402,380,22),(172,'pro088-clro03',89.84,3,3,402,361,41),(173,'pro089-clro03',88.07,3,3,402,354,48),(174,'pro090-clro03',93,3,3,402,374,28),(175,'pro091-clro03',90.8,3,3,402,365,37),(176,'pro092-clro03',87.66,3,3,402,352,50),(177,'pro093-clro03',91.42,3,3,402,367,34),(178,'pro094-clro03',84.65,3,3,268,227,41),(179,'pro096-clro03',93.62,3,3,268,251,17),(180,'pro098-clro03',79.61,3,3,268,213,55),(181,'pro099-clro03',83.19,3,3,268,223,45),(182,'pro100-clro03',89.37,3,3,268,239,28),(183,'pro101-clro03',89.45,3,3,268,240,28),(184,'pro102-clro03',93.66,3,3,268,251,17),(185,'pro103-clro03',73.23,3,3,268,196,72),(186,'pro104-clro03',91.03,3,3,268,244,24),(187,'pro105-clro03',76.44,3,3,268,205,63),(188,'pro110-clro03',74.49,3,3,268,199,68),(189,'pro112-clro03',78.86,3,3,268,211,57),(190,'pro113-clro03',88.77,3,3,268,238,30),(191,'pro114-clro03',76.81,3,3,268,206,62),(192,'pro116-clro03',92.88,3,3,268,249,19),(193,'pro117-clro03',93.63,3,3,268,251,17),(194,'pro119-clro03',87.29,3,3,268,234,34),(195,'pro120-clro03',85.03,3,3,268,228,40),(196,'pro121-clro03',88.79,3,3,268,238,30),(197,'pro122-clro03',87.4,3,3,268,234,34),(198,'pro123-clro03',85.22,3,3,268,228,40),(199,'pro125-clro02',88.22,3,2,534,471,63),(200,'pro129-clro01',83.46,3,1,274,228,45),(201,'pro131-clro02',89.67,3,2,534,479,55),(202,'pro132-clro02',92.44,3,2,534,493,40),(203,'pro133-clro02',90.1,3,2,534,481,53),(204,'pro134-clro02',93.77,3,2,534,501,33),(205,'pro135-clro02',90.56,3,2,534,483,50),(206,'pro136-clro02',87.24,3,2,534,466,68),(207,'pro024-clro01',84.94,4,1,311,264,47),(208,'pro039-clro01',86.89,4,1,267,232,35),(209,'pro015-clro01',70.09,4,1,535,375,160),(210,'pro017-clro01',91.45,4,1,535,489,46),(211,'pro066-clro03',87.55,4,3,266,233,33),(212,'pro070-clro03',92.12,4,3,266,245,21),(213,'pro072-clro03',79.29,4,3,266,211,55),(214,'pro073-clro03',67.67,4,3,266,180,86),(215,'pro074-clro03',92.08,4,3,266,245,21),(216,'pro095-clro03',67.45,4,3,268,181,87),(217,'pro097-clro03',85.77,4,3,268,230,38),(218,'pro106-clro03',90.62,4,3,268,243,25),(219,'pro107-clro03',82.81,4,3,268,222,46),(220,'pro108-clro03',83.9,4,3,268,225,43),(221,'pro109-clro03',89.5,4,3,268,240,28),(222,'pro111-clro03',87.66,4,3,268,235,33),(223,'pro115-clro03',83.85,4,3,268,225,43),(224,'pro118-clro03',82.38,4,3,268,221,47),(225,'pro124-clro02',88.01,4,2,534,470,64),(226,'pro126-clro02',85.08,4,2,534,454,80),(227,'pro127-clro02',92.43,4,2,534,493,40),(228,'pro128-clro02',94.22,4,2,534,503,31),(229,'pro130-clro02',92.87,4,2,535,497,38),(230,'templates',55.37,4,13,100,55,45),(231,'pro032-clro01',89.08,4,1,267,238,29),(232,'pro031-clro01',84.49,4,1,267,225,41),(233,'pro030-clro01',90.99,4,1,267,243,24),(234,'pro029-clro01',87.82,4,1,267,234,32),(235,'pro028-clro01',82.72,4,1,267,221,46),(236,'pro027-clro01',89.67,4,1,267,239,28),(237,'pro026-clro01',81.24,4,1,311,252,58),(238,'pro025-clro01',94.29,4,1,311,293,18),(239,'pro033-clro01',84.98,4,1,267,227,40),(240,'pro035-clro01',88.16,4,1,267,235,32),(241,'pro037-clro01',88.74,4,1,267,237,30),(242,'pro041-clro01',91.39,4,1,534,488,46),(243,'pro034-clro01',90.78,4,1,267,242,25),(244,'pro036-clro01',87.25,4,1,267,233,34),(245,'pro038-clro01',72.34,4,1,267,193,74),(246,'pro040-clro01',80.61,4,1,267,215,52),(247,'pro042-clro01',93.82,4,1,534,501,33),(248,'pro000-clro01',55.8,4,1,100,56,44),(249,'pro010-clro01',75.86,4,1,100,76,24),(250,'pro006-clro01',65.32,4,1,100,65,35),(251,'pro002-clro01',83.93,4,1,200,168,32),(252,'pro013-clro01',59.04,4,1,60,35,24),(253,'pro008-clro01',63.44,4,1,100,63,36),(254,'pro011-clro01',83.83,4,1,300,251,48),(255,'pro014-clro01',92.8,4,1,340,315,24),(256,'pro018-clro01',95.2,4,1,200,190,10),(257,'pro012-clro01',81.88,4,1,250,204,45),(258,'pro020-clro01',79.82,4,1,200,159,40),(259,'pro137-clro02',73.62,4,2,535,394,141),(260,'pro138-clro02',87.53,4,2,535,468,67),(261,'pro003-clro01',75.83,4,1,100,76,24),(262,'pro005-clro01',64.22,4,1,200,128,71),(263,'pro007-clro01',66.64,4,1,100,66,33),(264,'pro009-clro01',75.96,4,1,100,76,24),(265,'pro019-clro01',85.16,4,1,200,170,30),(266,'pro001-clro01',76.8,4,1,100,77,23),(267,'pro016-clro01',27.06,4,1,65,18,47),(268,'pro023-clro01',87.91,4,1,267,235,32),(269,'pro043-clro01',90.8,4,1,267,242,25),(270,'pro044-clro01',87.17,4,1,267,233,34),(271,'pro045-clro01',88.98,4,1,267,237,29),(272,'pro046-clro01',87.83,4,1,267,234,32),(273,'pro047-clro01',88.51,4,1,267,236,31),(274,'pro048-clro01',94.65,4,1,267,252,14),(275,'pro049-clro01',89.74,4,1,267,239,27),(276,'pro050-clro01',69.12,4,1,267,184,82),(277,'pro051-clro01',91.63,4,1,267,244,22),(278,'pro052-clro01',87.64,4,1,267,234,33),(279,'pro053-clro01',90.98,4,1,267,243,24),(280,'pro054-clro01',93.98,4,1,267,251,16),(281,'pro055-clro01',89.45,4,1,267,239,28),(282,'pro056-clro01',79.29,4,1,267,212,55),(283,'pro057-clro01',93.99,4,1,267,251,16),(284,'pro058-clro01',83.41,4,1,267,223,44),(285,'pro059-clro01',85.81,4,1,267,229,38),(286,'pro021-clro01',91.67,4,1,532,487,44),(287,'pro022-clro01',94.19,4,1,532,501,31),(288,'pro060-clro03',93.95,4,3,266,250,16),(289,'pro061-clro03',91.3,4,3,266,243,23),(290,'pro062-clro03',93.82,4,3,266,249,16),(291,'pro063-clro03',89.06,4,3,266,237,29),(292,'pro064-clro03',90.18,4,3,266,240,26),(293,'pro065-clro03',85.97,4,3,266,228,37),(294,'pro067-clro03',92.82,4,3,266,247,19),(295,'pro068-clro03',75.51,4,3,266,201,65),(296,'pro069-clro03',85.04,4,3,266,226,40),(297,'pro071-clro03',84.37,4,3,266,224,42),(298,'pro075-clro03',89.71,4,3,266,238,27),(299,'pro076-clro03',86.72,4,3,266,230,35),(300,'pro077-clro03',88.22,4,3,266,234,31),(301,'pro078-clro03',91.06,4,3,402,366,36),(302,'pro079-clro03',94.47,4,3,402,380,22),(303,'pro080-clro03',61.53,4,3,402,247,155),(304,'pro081-clro03',77.59,4,3,402,312,90),(305,'pro082-clro03',94,4,3,402,378,24),(306,'pro083-clro03',92.68,4,3,402,372,29),(307,'pro084-clro03',88.5,4,3,402,356,46),(308,'pro085-clro03',90.2,4,3,402,362,39),(309,'pro086-clro03',92.62,4,3,402,372,30),(310,'pro087-clro03',94.48,4,3,402,380,22),(311,'pro088-clro03',89.84,4,3,402,361,41),(312,'pro089-clro03',88.07,4,3,402,354,48),(313,'pro090-clro03',93,4,3,402,374,28),(314,'pro091-clro03',90.8,4,3,402,365,37),(315,'pro092-clro03',87.66,4,3,402,352,50),(316,'pro093-clro03',91.42,4,3,402,367,34),(317,'pro094-clro03',84.65,4,3,268,227,41),(318,'pro096-clro03',93.62,4,3,268,251,17),(319,'pro098-clro03',79.61,4,3,268,213,55),(320,'pro099-clro03',83.19,4,3,268,223,45),(321,'pro100-clro03',89.37,4,3,268,239,28),(322,'pro101-clro03',89.45,4,3,268,240,28),(323,'pro102-clro03',93.66,4,3,268,251,17),(324,'pro103-clro03',73.23,4,3,268,196,72),(325,'pro104-clro03',91.03,4,3,268,244,24),(326,'pro105-clro03',76.44,4,3,268,205,63),(327,'pro110-clro03',74.49,4,3,268,199,68),(328,'pro112-clro03',78.86,4,3,268,211,57),(329,'pro113-clro03',88.77,4,3,268,238,30),(330,'pro114-clro03',76.81,4,3,268,206,62),(331,'pro116-clro03',92.88,4,3,268,249,19),(332,'pro117-clro03',93.63,4,3,268,251,17),(333,'pro119-clro03',87.29,4,3,268,234,34),(334,'pro120-clro03',85.03,4,3,268,228,40),(335,'pro121-clro03',88.79,4,3,268,238,30),(336,'pro122-clro03',87.4,4,3,268,234,34),(337,'pro123-clro03',85.22,4,3,268,228,40),(338,'pro125-clro02',88.22,4,2,534,471,63),(339,'pro129-clro01',83.46,4,1,274,228,45),(340,'pro131-clro02',89.67,4,2,534,479,55),(341,'pro132-clro02',92.44,4,2,534,493,40),(342,'pro133-clro02',90.1,4,2,534,481,53),(343,'pro134-clro02',93.77,4,2,534,501,33),(344,'pro135-clro02',90.56,4,2,534,483,50),(345,'pro136-clro02',87.24,4,2,534,466,68),(346,'pro024-clro01',84.94,5,1,311,264,47),(347,'pro039-clro01',86.89,5,1,267,232,35),(348,'pro015-clro01',70.09,5,1,535,375,160),(349,'pro017-clro01',91.45,5,1,535,489,46),(350,'pro066-clro03',87.55,5,3,266,233,33),(351,'pro070-clro03',92.12,5,3,266,245,21),(352,'pro072-clro03',79.29,5,3,266,211,55),(353,'pro073-clro03',67.67,5,3,266,180,86),(354,'pro074-clro03',92.08,5,3,266,245,21),(355,'pro095-clro03',67.45,5,3,268,181,87),(356,'pro097-clro03',85.77,5,3,268,230,38),(357,'pro106-clro03',90.62,5,3,268,243,25),(358,'pro107-clro03',82.81,5,3,268,222,46),(359,'pro108-clro03',83.9,5,3,268,225,43),(360,'pro109-clro03',89.5,5,3,268,240,28),(361,'pro111-clro03',87.66,5,3,268,235,33),(362,'pro115-clro03',83.85,5,3,268,225,43),(363,'pro118-clro03',82.38,5,3,268,221,47),(364,'pro124-clro02',88.01,5,2,534,470,64),(365,'pro126-clro02',85.08,5,2,534,454,80),(366,'pro127-clro02',92.43,5,2,534,493,40),(367,'pro128-clro02',94.22,5,2,534,503,31),(368,'pro130-clro02',92.87,5,2,535,497,38),(369,'templates',55.37,5,13,100,55,45),(370,'pro032-clro01',89.08,5,1,267,238,29),(371,'pro031-clro01',84.49,5,1,267,225,41),(372,'pro030-clro01',90.99,5,1,267,243,24),(373,'pro029-clro01',87.82,5,1,267,234,32),(374,'pro028-clro01',82.72,5,1,267,221,46),(375,'pro027-clro01',89.67,5,1,267,239,28),(376,'pro026-clro01',81.24,5,1,311,252,58),(377,'pro025-clro01',94.29,5,1,311,293,18),(378,'pro033-clro01',84.98,5,1,267,227,40),(379,'pro035-clro01',88.16,5,1,267,235,32),(380,'pro037-clro01',88.74,5,1,267,237,30),(381,'pro041-clro01',91.39,5,1,534,488,46),(382,'pro034-clro01',90.78,5,1,267,242,25),(383,'pro036-clro01',87.25,5,1,267,233,34),(384,'pro038-clro01',72.34,5,1,267,193,74),(385,'pro040-clro01',80.61,5,1,267,215,52),(386,'pro042-clro01',93.82,5,1,534,501,33),(387,'pro000-clro01',55.8,5,1,100,56,44),(388,'pro010-clro01',75.86,5,1,100,76,24),(389,'pro006-clro01',65.32,5,1,100,65,35),(390,'pro002-clro01',83.93,5,1,200,168,32),(391,'pro013-clro01',59.04,5,1,60,35,24),(392,'pro008-clro01',63.44,5,1,100,63,36),(393,'pro011-clro01',83.83,5,1,300,251,48),(394,'pro014-clro01',92.8,5,1,340,315,24),(395,'pro018-clro01',95.2,5,1,200,190,10),(396,'pro012-clro01',81.88,5,1,250,204,45),(397,'pro020-clro01',79.82,5,1,200,159,40),(398,'pro137-clro02',73.62,5,2,535,394,141),(399,'pro138-clro02',87.53,5,2,535,468,67),(400,'pro003-clro01',75.83,5,1,100,76,24),(401,'pro005-clro01',64.22,5,1,200,128,71),(402,'pro007-clro01',66.64,5,1,100,66,33),(403,'pro009-clro01',75.96,5,1,100,76,24),(404,'pro019-clro01',85.16,5,1,200,170,30),(405,'pro001-clro01',76.8,5,1,100,77,23),(406,'pro016-clro01',27.06,5,1,65,18,47),(407,'pro023-clro01',87.91,5,1,267,235,32),(408,'pro043-clro01',90.8,5,1,267,242,25),(409,'pro044-clro01',87.17,5,1,267,233,34),(410,'pro045-clro01',88.98,5,1,267,237,29),(411,'pro046-clro01',87.83,5,1,267,234,32),(412,'pro047-clro01',88.51,5,1,267,236,31),(413,'pro048-clro01',94.65,5,1,267,252,14),(414,'pro049-clro01',89.74,5,1,267,239,27),(415,'pro050-clro01',69.12,5,1,267,184,82),(416,'pro051-clro01',91.63,5,1,267,244,22),(417,'pro052-clro01',87.64,5,1,267,234,33),(418,'pro053-clro01',90.98,5,1,267,243,24),(419,'pro054-clro01',93.98,5,1,267,251,16),(420,'pro055-clro01',89.45,5,1,267,239,28),(421,'pro056-clro01',79.29,5,1,267,212,55),(422,'pro057-clro01',93.99,5,1,267,251,16),(423,'pro058-clro01',83.41,5,1,267,223,44),(424,'pro059-clro01',85.81,5,1,267,229,38),(425,'pro021-clro01',91.67,5,1,532,487,44),(426,'pro022-clro01',94.19,5,1,532,501,31),(427,'pro060-clro03',93.95,5,3,266,250,16),(428,'pro061-clro03',91.3,5,3,266,243,23),(429,'pro062-clro03',93.82,5,3,266,249,16),(430,'pro063-clro03',89.06,5,3,266,237,29),(431,'pro064-clro03',90.18,5,3,266,240,26),(432,'pro065-clro03',85.97,5,3,266,228,37),(433,'pro067-clro03',92.82,5,3,266,247,19),(434,'pro068-clro03',75.51,5,3,266,201,65),(435,'pro069-clro03',85.04,5,3,266,226,40),(436,'pro071-clro03',84.37,5,3,266,224,42),(437,'pro075-clro03',89.71,5,3,266,238,27),(438,'pro076-clro03',86.72,5,3,266,230,35),(439,'pro077-clro03',88.22,5,3,266,234,31),(440,'pro078-clro03',91.06,5,3,402,366,36),(441,'pro079-clro03',94.47,5,3,402,380,22),(442,'pro080-clro03',61.53,5,3,402,247,155),(443,'pro081-clro03',77.59,5,3,402,312,90),(444,'pro082-clro03',94,5,3,402,378,24),(445,'pro083-clro03',92.68,5,3,402,372,29),(446,'pro084-clro03',88.5,5,3,402,356,46),(447,'pro085-clro03',90.2,5,3,402,362,39),(448,'pro086-clro03',92.62,5,3,402,372,30),(449,'pro087-clro03',94.48,5,3,402,380,22),(450,'pro088-clro03',89.84,5,3,402,361,41),(451,'pro089-clro03',88.07,5,3,402,354,48),(452,'pro090-clro03',93,5,3,402,374,28),(453,'pro091-clro03',90.8,5,3,402,365,37),(454,'pro092-clro03',87.66,5,3,402,352,50),(455,'pro093-clro03',91.42,5,3,402,367,34),(456,'pro094-clro03',84.65,5,3,268,227,41),(457,'pro096-clro03',93.62,5,3,268,251,17),(458,'pro098-clro03',79.61,5,3,268,213,55),(459,'pro099-clro03',83.19,5,3,268,223,45),(460,'pro100-clro03',89.37,5,3,268,239,28),(461,'pro101-clro03',89.45,5,3,268,240,28),(462,'pro102-clro03',93.66,5,3,268,251,17),(463,'pro103-clro03',73.23,5,3,268,196,72),(464,'pro104-clro03',91.03,5,3,268,244,24),(465,'pro105-clro03',76.44,5,3,268,205,63),(466,'pro110-clro03',74.49,5,3,268,199,68),(467,'pro112-clro03',78.86,5,3,268,211,57),(468,'pro113-clro03',88.77,5,3,268,238,30),(469,'pro114-clro03',76.81,5,3,268,206,62),(470,'pro116-clro03',92.88,5,3,268,249,19),(471,'pro117-clro03',93.63,5,3,268,251,17),(472,'pro119-clro03',87.29,5,3,268,234,34),(473,'pro120-clro03',85.03,5,3,268,228,40),(474,'pro121-clro03',88.79,5,3,268,238,30),(475,'pro122-clro03',87.4,5,3,268,234,34),(476,'pro123-clro03',85.22,5,3,268,228,40),(477,'pro125-clro02',88.22,5,2,534,471,63),(478,'pro129-clro01',83.46,5,1,274,228,45),(479,'pro131-clro02',89.67,5,2,534,479,55),(480,'pro132-clro02',92.44,5,2,534,493,40),(481,'pro133-clro02',90.1,5,2,534,481,53),(482,'pro134-clro02',93.77,5,2,534,501,33),(483,'pro135-clro02',90.56,5,2,534,483,50),(484,'pro136-clro02',87.24,5,2,534,466,68),(485,'NFS',35.73,6,11,3277,1171,2106),(486,'isos',75.66,6,13,226,171,55),(487,'extfc001-naro01',94.35,8,5,450,425,25),(488,'extfc002-naro01',26.57,8,5,450,120,330),(489,'extfc006-naro01',78.79,8,5,450,355,95),(490,'extfc008-naro01',1.01,8,5,450,5,445),(491,'isos',75.66,8,13,226,171,55),(492,'extfc003-naro01',0.12,8,5,450,1,449),(493,'extfc004-naro01',9.46,8,5,450,43,407),(494,'extfc005-naro01',0.12,8,5,450,1,449),(495,'extfc007-naro01',0.12,8,5,450,1,449),(496,'tst037-clro02',70.47,7,9,534,376,158),(497,'tst038-clro02',58.3,7,9,534,311,223),(498,'tst039-clro02',91.81,7,9,534,490,44),(499,'tst040-clro02',90.64,7,9,1068,968,100),(500,'tst042-clro02',83.16,7,9,534,444,90),(501,'tst043-clro02 TP',52.04,7,13,535,278,256),(502,'tst044-clro02',39.57,7,9,535,212,323),(503,'tst045-clro02',49.46,7,9,535,264,270),(504,'tstsa001-naro01',42.78,7,8,600,257,343),(505,'tstsa002-naro01',64.34,7,8,600,386,214),(506,'tstsa003-naro01',38.71,7,8,600,232,368),(507,'tstsa004-naro01',45.11,7,8,600,271,329),(508,'tstsa005-naro01',36.46,7,8,600,219,381),(509,'tstsa006-naro01',49.34,7,8,600,296,304),(510,'tstsa007-naro01',68.55,7,8,600,411,189),(511,'tstsa008-naro01',70.46,7,8,600,423,177),(512,'tstsa009-naro01',75.47,7,8,600,453,147),(513,'tstsa010-naro01',64.07,7,8,600,384,216),(514,'tstsa011-naro01',73.43,7,8,600,441,159),(515,'tstsa012-naro01',33.49,7,8,600,201,399),(516,'tstsa013-naro01',42.81,7,8,600,257,343),(517,'isos',75.66,7,13,226,171,55),(518,'tstsa014-naro01_dedicada',17.94,7,13,600,108,492),(519,'tstsa015-naro01',59.9,7,8,600,359,241),(520,'tstsa016-naro01',41.32,7,8,600,248,352),(521,'tst000-clro03',80.7,7,10,235,189,45),(522,'tst001-clro03',77.09,7,10,536,413,123),(523,'tst002-clro03',81.69,7,10,268,219,49),(524,'tst003-clro03',68.88,7,10,536,369,167),(525,'tst004-clro03',81.67,7,10,235,192,43),(526,'tst005-clro03',62.31,7,10,268,167,101),(527,'tst006-clro03',90.64,7,10,268,243,25),(528,'tst007-clro03',82.65,7,10,268,221,46),(529,'tst008-clro03',90.53,7,10,268,242,25),(530,'tst009-clro03',49.42,7,10,268,132,135),(531,'tst010-clro03',69.66,7,10,268,187,81),(532,'tst011-clro03',92.82,7,10,268,249,19),(533,'tst012-clro03',89.98,7,10,201,181,20),(534,'tst013-clro03',83.57,7,10,201,168,33),(535,'tst014-clro03',40.73,7,10,235,96,139),(536,'tst015-clro03',82.95,7,10,235,195,40),(537,'tst016-clro03',54.83,7,10,536,294,242),(538,'tst017-clro03',67.64,7,10,536,362,173),(539,'tst018-clro03',84.76,7,10,268,227,41),(540,'tst019-clro03',92.76,7,10,268,248,19),(541,'tst020-clro03',85.72,7,10,268,230,38),(542,'tst021-clro03',83.89,7,10,268,225,43),(543,'tst022-clro03',33.12,7,10,268,89,179),(544,'tst023-clro03',84.29,7,10,268,226,42),(545,'tst024-clro03',78.31,7,10,268,210,58),(546,'tst025-clro03',92.44,7,10,268,248,20),(547,'tst026-clro03',77.27,7,10,201,155,46),(548,'tst027-clro03',82,7,10,201,165,36),(549,'tst028-clro02',91.69,7,9,534,489,44),(550,'tst029-clro02',83.62,7,9,534,446,87),(551,'tst030-clro02',45.1,7,9,534,241,293),(552,'tst031-clro02',90.06,7,9,534,481,53),(553,'tst032-clro02',54.27,7,9,534,290,244),(554,'tst033-clro02',44,7,9,534,235,299),(555,'tst034-clro02',80.75,7,9,534,431,103),(556,'tst035-clro02',91.72,7,9,534,490,44),(557,'tst036-clro02',51.43,7,9,534,275,259),(558,'DMX3_L019',0.13,10,15,408,1,408),(559,'Produccion_DMX3_4',0.18,10,15,298,1,297),(560,'PRO_ROZ_VMAX3_FC6_L001',0.17,10,13,320,1,319),(561,'DES_ROZ_VMAX3_SATA_L011',0.09,10,13,608,1,607),(562,'DES_ROZ_VMAX3_SATA_L012',0.09,10,13,608,1,607),(563,'DES_ROZ_VMAX3_SATA_L013',0.09,10,13,608,1,607),(564,'TST_ROZ_VMAX3_SATA_L016',0.09,10,13,608,1,607),(565,'TRA_ROZ_VMAX3_SATA_L014',0.09,10,13,608,1,607),(566,'TRA_ROZ_VMAX3_SATA_L015',0.09,10,13,608,1,607),(567,'PRO_ROZ_VMAX3_FC6_L002',0.17,10,13,320,1,319),(568,'PRO_ROZ_VMAX3_FC6_L003',0.17,10,13,320,1,319),(569,'PRO_ROZ_VMAX3_FC6_L004',0.17,10,13,320,1,319),(570,'PRO_ROZ_VMAX3_FC6_L005',0.17,10,13,320,1,319),(571,'PRO_ROZ_VMAX3_FC6_L006',0.17,10,13,320,1,319),(572,'PRO_ROZ_VMAX3_FC6_L007',0.17,10,13,320,1,319),(573,'PRO_ROZ_VMAX3_FC6_L008',0.17,10,13,320,1,319),(574,'PRO_ROZ_VMAX3_FC6_L009',0.17,10,13,320,1,319),(575,'PRO_ROZ_VMAX3_FC6_L010',0.17,10,13,320,1,319),(576,'PRO_COR_VMAX3_FC6_L001',0.17,10,13,320,1,319),(577,'Transito_DMX2000_1',80.07,10,20,596,477,119),(578,'Produccion_DMX3_2',83.53,10,15,596,497,98),(579,'Desarrollo_Clariion_4',15.65,10,14,300,47,253),(580,'Produccion_DMX3_1',77.7,10,15,596,463,133),(581,'VMFS_NFS_HDS',86.96,10,21,399,347,52),(582,'Desarrollo_Test',44.75,10,15,187,84,103),(583,'Produccion_COR_DMX800_1',92.3,10,18,612,565,47),(584,'Produccion_COR_DMX4_1',95.14,10,17,629,598,31),(585,'Desarrollo_Pool_b',0.12,10,15,459,1,459),(586,'Produccion_DMX3_5',67.43,10,15,204,138,66),(587,'Desarrollo_Clariion_1',80.63,10,14,600,483,116),(588,'Desarrollo_Clariion_2',71.93,10,14,600,431,168),(589,'Desarrollo_Clariion_3',84.92,10,14,600,509,90),(590,'Transito_DMX2000_2',76.22,10,20,596,454,142),(591,'Transito_DMX2000_3',75.47,10,20,596,449,146),(592,'Produccion_DMX3_3',72.12,10,15,298,215,83),(593,'Transito_DMX2000_4',8.77,10,20,298,26,272),(594,'Produccion_DS8300_Rozas_OIv2',16.02,10,22,2,0,1),(595,'Produccion_DS8100_COR_OIv2',16.02,10,19,2,0,1),(596,'Produccion_COR_DMX4_2',77.89,10,17,145,113,32),(597,'DMX3_L001',98.4,10,15,298,293,5),(598,'DMX3_L010',88.97,10,15,298,265,33),(599,'DMX3_L013',81.86,10,15,298,244,54),(600,'DMX3_L008',33.2,10,15,145,48,97),(601,'DMX800_L080',25.3,10,16,145,37,108),(602,'DMX800_L079',14.75,10,16,77,11,65);
/*!40000 ALTER TABLE `Datastores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Datastores_por_Datacenter`
--

DROP TABLE IF EXISTS `Datastores_por_Datacenter`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Datastores_por_Datacenter` (
  `idDatastores_por_Datacenter` int(11) NOT NULL default '0',
  `Nombre_Datacenter` varchar(45) collate latin1_spanish_ci default NULL,
  `Nombre_Datastore` varchar(45) collate latin1_spanish_ci default NULL,
  `Ocupacion_Percent` float default NULL,
  `Capacidad_Datastore` int(11) default NULL,
  `Ocupado_Datastore` int(11) default NULL,
  `Libre_Datastore` int(11) default NULL,
  `Grupo_Almacenamiento` int(11) default NULL,
  PRIMARY KEY  (`idDatastores_por_Datacenter`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Datastores_por_Datacenter`
--

LOCK TABLES `Datastores_por_Datacenter` WRITE;
/*!40000 ALTER TABLE `Datastores_por_Datacenter` DISABLE KEYS */;
INSERT INTO `Datastores_por_Datacenter` VALUES (1,'Centro_Respaldo','cor015-clcr01',56.73,267,151,115,4),(2,'Centro_Respaldo','cor016-clcr01',94.49,267,252,15,4),(3,'Centro_Respaldo','cor017-clcr01',64.36,267,172,95,4),(4,'Centro_Respaldo','cor018-clcr01',87.55,267,234,33,4),(5,'Centro_Respaldo','cor019-clcr01',84.25,267,225,42,4),(6,'Centro_Respaldo','cor020-clcr01',86.11,267,230,37,4),(7,'Centro_Respaldo','cor022-clcr01',93.54,267,250,17,4),(8,'Centro_Respaldo','cor023-clcr01',75.53,534,403,131,4),(9,'Centro_Respaldo','cor024-clcr01',69.2,534,369,164,4),(10,'Centro_Respaldo','cor025-clcr01',91.31,534,487,46,4),(11,'Centro_Respaldo','cor026-clcr01',89.67,534,479,55,4),(12,'Centro_Respaldo','cor027-clcr01',80.84,267,216,51,4),(13,'Centro_Respaldo','cor021-clcr01',0.21,262,1,261,4),(14,'Centro_Respaldo','cor005-clcr01',28.25,267,75,191,4),(15,'Centro_Respaldo','cor013-clcr01',73.94,534,395,139,4),(16,'Centro_Respaldo','cor001-clcr01',40.97,267,109,157,4),(17,'Centro_Respaldo','cor014-clcr01',11.79,534,63,471,4),(18,'Centro_Respaldo','cor002-clcr01',12.94,801,104,697,4),(19,'Centro_Respaldo','cor003-clcr01',25.59,534,137,397,4),(20,'Centro_Respaldo','cor004-clcr01',9.85,534,53,481,4),(21,'Centro_Respaldo','cor006-clcr01',12.34,534,66,468,4),(22,'Centro_Respaldo','cor007-clcr01',21.44,534,114,419,4),(23,'Centro_Respaldo','cor008-clcr01',9.85,534,53,481,4),(24,'Produccion_Principal','NFS',35.73,3277,1171,2106,11),(25,'Produccion_Principal','pro024-clro01',84.94,311,264,47,1),(26,'Produccion_Principal','pro039-clro01',86.89,267,232,35,1),(27,'Produccion_Principal','pro015-clro01',70.09,535,375,160,1),(28,'Produccion_Principal','pro017-clro01',91.45,535,489,46,1),(29,'Produccion_Principal','pro066-clro03',87.55,266,233,33,3),(30,'Produccion_Principal','pro070-clro03',92.12,266,245,21,3),(31,'Produccion_Principal','pro072-clro03',79.29,266,211,55,3),(32,'Produccion_Principal','pro073-clro03',67.67,266,180,86,3),(33,'Produccion_Principal','pro074-clro03',92.08,266,245,21,3),(34,'Produccion_Principal','pro095-clro03',67.45,268,181,87,3),(35,'Produccion_Principal','pro097-clro03',85.77,268,230,38,3),(36,'Produccion_Principal','prosa008-naro01',27.98,600,168,432,6),(37,'Produccion_Principal','pro106-clro03',90.62,268,243,25,3),(38,'Produccion_Principal','pro107-clro03',82.81,268,222,46,3),(39,'Produccion_Principal','pro108-clro03',83.9,268,225,43,3),(40,'Produccion_Principal','pro109-clro03',89.5,268,240,28,3),(41,'Produccion_Principal','pro111-clro03',87.66,268,235,33,3),(42,'Produccion_Principal','pro115-clro03',83.85,268,225,43,3),(43,'Produccion_Principal','pro118-clro03',82.38,268,221,47,3),(44,'Produccion_Principal','pro124-clro02',88.01,534,470,64,2),(45,'Produccion_Principal','pro126-clro02',85.08,534,454,80,2),(46,'Produccion_Principal','pro127-clro02',92.43,534,493,40,2),(47,'Produccion_Principal','pro128-clro02',94.22,534,503,31,2),(48,'Produccion_Principal','pro130-clro02',92.87,535,497,38,2),(49,'Produccion_Principal','prosa001-naro01',85.76,600,515,85,6),(50,'Produccion_Principal','prosa002-naro01',90.09,600,541,59,6),(51,'Produccion_Principal','prosa003-naro01',87,600,522,78,6),(52,'Produccion_Principal','prosa004-naro01',82.8,600,497,103,6),(53,'Produccion_Principal','prosa005-naro01',89.6,600,538,62,6),(54,'Produccion_Principal','prosa006-naro01',86.44,600,519,81,6),(55,'Produccion_Principal','prosa007-naro01',85.17,600,511,89,6),(56,'Produccion_Principal','prosa009-naro01',64.26,600,386,214,6),(57,'Produccion_Principal','prosa010-naro01',88.45,600,531,69,6),(58,'Produccion_Principal','extfc001-naro01',94.35,450,425,25,5),(59,'Produccion_Principal','extfc002-naro01',26.57,450,120,330,5),(60,'Produccion_Principal','extfc006-naro01',78.79,450,355,95,5),(61,'Produccion_Principal','extfc008-naro01',1.01,450,5,445,5),(62,'Produccion_Principal','isos',75.66,226,171,55,13),(63,'Produccion_Principal','prosa011-naro01',73.39,600,440,160,6),(64,'Produccion_Principal','prosa012-naro01',85.47,600,513,87,6),(65,'Produccion_Principal','prosa013-naro01',54.95,600,330,270,6),(66,'Produccion_Principal','prosa014-naro01-lab',59.87,600,359,241,7),(67,'Produccion_Principal','prosa015-naro01-lab',40.72,600,244,356,7),(68,'Produccion_Principal','prosa016-naro01-lab',47.94,600,288,312,7),(69,'Produccion_Principal','NFS_SATA',0.54,3705,20,3685,12),(70,'Produccion_Principal','extfc003-naro01',0.12,450,1,449,5),(71,'Produccion_Principal','extfc004-naro01',9.46,450,43,407,5),(72,'Produccion_Principal','extfc005-naro01',0.12,450,1,449,5),(73,'Produccion_Principal','extfc007-naro01',0.12,450,1,449,5),(74,'Produccion_Principal','prosa017-naro01',87.64,600,526,74,6),(75,'Produccion_Principal','prosa018-naro01',89.14,600,535,65,6),(76,'Produccion_Principal','prosa019-naro01',88.6,600,532,68,6),(77,'Produccion_Principal','templates',55.37,100,55,45,13),(78,'Produccion_Principal','pro032-clro01',89.08,267,238,29,1),(79,'Produccion_Principal','pro031-clro01',84.49,267,225,41,1),(80,'Produccion_Principal','pro030-clro01',90.99,267,243,24,1),(81,'Produccion_Principal','pro029-clro01',87.82,267,234,32,1),(82,'Produccion_Principal','pro028-clro01',82.72,267,221,46,1),(83,'Produccion_Principal','pro027-clro01',89.67,267,239,28,1),(84,'Produccion_Principal','pro026-clro01',81.24,311,252,58,1),(85,'Produccion_Principal','pro025-clro01',94.29,311,293,18,1),(86,'Produccion_Principal','pro033-clro01',84.98,267,227,40,1),(87,'Produccion_Principal','pro035-clro01',88.16,267,235,32,1),(88,'Produccion_Principal','pro037-clro01',88.74,267,237,30,1),(89,'Produccion_Principal','pro041-clro01',91.39,534,488,46,1),(90,'Produccion_Principal','pro034-clro01',90.78,267,242,25,1),(91,'Produccion_Principal','pro036-clro01',87.25,267,233,34,1),(92,'Produccion_Principal','pro038-clro01',72.34,267,193,74,1),(93,'Produccion_Principal','pro040-clro01',80.61,267,215,52,1),(94,'Produccion_Principal','pro042-clro01',93.82,534,501,33,1),(95,'Produccion_Principal','pro000-clro01',55.8,100,56,44,1),(96,'Produccion_Principal','pro010-clro01',75.86,100,76,24,1),(97,'Produccion_Principal','pro006-clro01',65.32,100,65,35,1),(98,'Produccion_Principal','pro002-clro01',83.93,200,168,32,1),(99,'Produccion_Principal','pro013-clro01',59.04,60,35,24,1),(100,'Produccion_Principal','pro008-clro01',63.44,100,63,36,1),(101,'Produccion_Principal','pro011-clro01',83.83,300,251,48,1),(102,'Produccion_Principal','pro014-clro01',92.8,340,315,24,1),(103,'Produccion_Principal','pro018-clro01',95.2,200,190,10,1),(104,'Produccion_Principal','pro012-clro01',81.88,250,204,45,1),(105,'Produccion_Principal','pro020-clro01',79.82,200,159,40,1),(106,'Produccion_Principal','pro137-clro02',73.62,535,394,141,2),(107,'Produccion_Principal','pro138-clro02',87.53,535,468,67,2),(108,'Produccion_Principal','pro003-clro01',75.83,100,76,24,1),(109,'Produccion_Principal','pro005-clro01',64.22,200,128,71,1),(110,'Produccion_Principal','pro007-clro01',66.64,100,66,33,1),(111,'Produccion_Principal','pro009-clro01',75.96,100,76,24,1),(112,'Produccion_Principal','pro019-clro01',85.16,200,170,30,1),(113,'Produccion_Principal','pro001-clro01',76.8,100,77,23,1),(114,'Produccion_Principal','prosa020-naro01',5.93,600,36,564,6),(115,'Produccion_Principal','prosa021-naro01',46.6,600,280,320,6),(116,'Produccion_Principal','prosa022-naro01-linked',6.45,600,39,561,13),(117,'Produccion_Principal','pro016-clro01',27.06,65,18,47,1),(118,'Produccion_Principal','pro023-clro01',87.91,267,235,32,1),(119,'Produccion_Principal','pro043-clro01',90.8,267,242,25,1),(120,'Produccion_Principal','pro044-clro01',87.17,267,233,34,1),(121,'Produccion_Principal','pro045-clro01',88.98,267,237,29,1),(122,'Produccion_Principal','pro046-clro01',87.83,267,234,32,1),(123,'Produccion_Principal','pro047-clro01',88.51,267,236,31,1),(124,'Produccion_Principal','pro048-clro01',94.65,267,252,14,1),(125,'Produccion_Principal','pro049-clro01',89.74,267,239,27,1),(126,'Produccion_Principal','pro050-clro01',69.12,267,184,82,1),(127,'Produccion_Principal','pro051-clro01',91.63,267,244,22,1),(128,'Produccion_Principal','pro052-clro01',87.64,267,234,33,1),(129,'Produccion_Principal','pro053-clro01',90.98,267,243,24,1),(130,'Produccion_Principal','pro054-clro01',93.98,267,251,16,1),(131,'Produccion_Principal','pro055-clro01',89.45,267,239,28,1),(132,'Produccion_Principal','pro056-clro01',79.29,267,212,55,1),(133,'Produccion_Principal','pro057-clro01',93.99,267,251,16,1),(134,'Produccion_Principal','pro058-clro01',83.41,267,223,44,1),(135,'Produccion_Principal','pro059-clro01',85.81,267,229,38,1),(136,'Produccion_Principal','pro021-clro01',91.67,532,487,44,1),(137,'Produccion_Principal','pro022-clro01',94.19,532,501,31,1),(138,'Produccion_Principal','pro060-clro03',93.95,266,250,16,3),(139,'Produccion_Principal','pro061-clro03',91.3,266,243,23,3),(140,'Produccion_Principal','pro062-clro03',93.82,266,249,16,3),(141,'Produccion_Principal','pro063-clro03',89.06,266,237,29,3),(142,'Produccion_Principal','pro064-clro03',90.18,266,240,26,3),(143,'Produccion_Principal','pro065-clro03',85.97,266,228,37,3),(144,'Produccion_Principal','pro067-clro03',92.82,266,247,19,3),(145,'Produccion_Principal','pro068-clro03',75.51,266,201,65,3),(146,'Produccion_Principal','pro069-clro03',85.04,266,226,40,3),(147,'Produccion_Principal','pro071-clro03',84.37,266,224,42,3),(148,'Produccion_Principal','pro075-clro03',89.71,266,238,27,3),(149,'Produccion_Principal','pro076-clro03',86.72,266,230,35,3),(150,'Produccion_Principal','pro077-clro03',88.22,266,234,31,3),(151,'Produccion_Principal','pro078-clro03',91.06,402,366,36,3),(152,'Produccion_Principal','pro079-clro03',94.47,402,380,22,3),(153,'Produccion_Principal','pro080-clro03',61.53,402,247,155,3),(154,'Produccion_Principal','pro081-clro03',77.59,402,312,90,3),(155,'Produccion_Principal','pro082-clro03',94,402,378,24,3),(156,'Produccion_Principal','pro083-clro03',92.68,402,372,29,3),(157,'Produccion_Principal','pro084-clro03',88.5,402,356,46,3),(158,'Produccion_Principal','pro085-clro03',90.2,402,362,39,3),(159,'Produccion_Principal','pro086-clro03',92.62,402,372,30,3),(160,'Produccion_Principal','pro087-clro03',94.48,402,380,22,3),(161,'Produccion_Principal','pro088-clro03',89.84,402,361,41,3),(162,'Produccion_Principal','pro089-clro03',88.07,402,354,48,3),(163,'Produccion_Principal','pro090-clro03',93,402,374,28,3),(164,'Produccion_Principal','pro091-clro03',90.8,402,365,37,3),(165,'Produccion_Principal','pro092-clro03',87.66,402,352,50,3),(166,'Produccion_Principal','pro093-clro03',91.42,402,367,34,3),(167,'Produccion_Principal','pro094-clro03',84.65,268,227,41,3),(168,'Produccion_Principal','pro096-clro03',93.62,268,251,17,3),(169,'Produccion_Principal','pro098-clro03',79.61,268,213,55,3),(170,'Produccion_Principal','pro099-clro03',83.19,268,223,45,3),(171,'Produccion_Principal','pro100-clro03',89.37,268,239,28,3),(172,'Produccion_Principal','pro101-clro03',89.45,268,240,28,3),(173,'Produccion_Principal','pro102-clro03',93.66,268,251,17,3),(174,'Produccion_Principal','pro103-clro03',73.23,268,196,72,3),(175,'Produccion_Principal','pro104-clro03',91.03,268,244,24,3),(176,'Produccion_Principal','pro105-clro03',76.44,268,205,63,3),(177,'Produccion_Principal','pro110-clro03',74.49,268,199,68,3),(178,'Produccion_Principal','pro112-clro03',78.86,268,211,57,3),(179,'Produccion_Principal','pro113-clro03',88.77,268,238,30,3),(180,'Produccion_Principal','pro114-clro03',76.81,268,206,62,3),(181,'Produccion_Principal','pro116-clro03',92.88,268,249,19,3),(182,'Produccion_Principal','pro117-clro03',93.63,268,251,17,3),(183,'Produccion_Principal','pro119-clro03',87.29,268,234,34,3),(184,'Produccion_Principal','pro120-clro03',85.03,268,228,40,3),(185,'Produccion_Principal','pro121-clro03',88.79,268,238,30,3),(186,'Produccion_Principal','pro122-clro03',87.4,268,234,34,3),(187,'Produccion_Principal','pro123-clro03',85.22,268,228,40,3),(188,'Produccion_Principal','pro125-clro02',88.22,534,471,63,2),(189,'Produccion_Principal','pro129-clro01',83.46,274,228,45,1),(190,'Produccion_Principal','pro131-clro02',89.67,534,479,55,2),(191,'Produccion_Principal','pro132-clro02',92.44,534,493,40,2),(192,'Produccion_Principal','pro133-clro02',90.1,534,481,53,2),(193,'Produccion_Principal','pro134-clro02',93.77,534,501,33,2),(194,'Produccion_Principal','pro135-clro02',90.56,534,483,50,2),(195,'Produccion_Principal','pro136-clro02',87.24,534,466,68,2),(196,'Produccion_Principal','prosa024-naro01',0.09,600,1,599,6),(197,'Produccion_Principal','prosa025-naro01',0.09,600,1,599,6),(198,'Produccion_Principal','prosa026-naro01',5.93,600,36,564,6),(199,'Produccion_Principal','prosa027-naro01',5.93,600,36,564,6),(200,'Produccion_Principal','prosa028-naro01',22.61,600,136,464,6),(201,'Produccion_Principal','prosa029-naro01',29.26,600,176,424,6),(202,'Test y Preproduccion','tst037-clro02',70.47,534,376,158,9),(203,'Test y Preproduccion','tst038-clro02',58.3,534,311,223,9),(204,'Test y Preproduccion','tst039-clro02',91.81,534,490,44,9),(205,'Test y Preproduccion','tst040-clro02',90.64,1068,968,100,9),(206,'Test y Preproduccion','tst042-clro02',83.16,534,444,90,9),(207,'Test y Preproduccion','tst043-clro02 TP',52.04,535,278,256,13),(208,'Test y Preproduccion','tst044-clro02',39.57,535,212,323,9),(209,'Test y Preproduccion','tst045-clro02',49.46,535,264,270,9),(210,'Test y Preproduccion','tstsa001-naro01',42.78,600,257,343,8),(211,'Test y Preproduccion','tstsa002-naro01',64.34,600,386,214,8),(212,'Test y Preproduccion','tstsa003-naro01',38.71,600,232,368,8),(213,'Test y Preproduccion','tstsa004-naro01',45.11,600,271,329,8),(214,'Test y Preproduccion','tstsa005-naro01',36.46,600,219,381,8),(215,'Test y Preproduccion','tstsa006-naro01',49.34,600,296,304,8),(216,'Test y Preproduccion','tstsa007-naro01',68.55,600,411,189,8),(217,'Test y Preproduccion','tstsa008-naro01',70.46,600,423,177,8),(218,'Test y Preproduccion','tstsa009-naro01',75.47,600,453,147,8),(219,'Test y Preproduccion','tstsa010-naro01',64.07,600,384,216,8),(220,'Test y Preproduccion','tstsa011-naro01',73.43,600,441,159,8),(221,'Test y Preproduccion','tstsa012-naro01',33.49,600,201,399,8),(222,'Test y Preproduccion','tstsa013-naro01',42.81,600,257,343,8),(223,'Test y Preproduccion','isos',75.66,226,171,55,13),(224,'Test y Preproduccion','tstsa014-naro01_dedicada',17.94,600,108,492,13),(225,'Test y Preproduccion','tstsa015-naro01',59.9,600,359,241,8),(226,'Test y Preproduccion','tstsa016-naro01',41.32,600,248,352,8),(227,'Test y Preproduccion','tst000-clro03',80.7,235,189,45,10),(228,'Test y Preproduccion','tst001-clro03',77.09,536,413,123,10),(229,'Test y Preproduccion','tst002-clro03',81.69,268,219,49,10),(230,'Test y Preproduccion','tst003-clro03',68.88,536,369,167,10),(231,'Test y Preproduccion','tst004-clro03',81.67,235,192,43,10),(232,'Test y Preproduccion','tst005-clro03',62.31,268,167,101,10),(233,'Test y Preproduccion','tst006-clro03',90.64,268,243,25,10),(234,'Test y Preproduccion','tst007-clro03',82.65,268,221,46,10),(235,'Test y Preproduccion','tst008-clro03',90.53,268,242,25,10),(236,'Test y Preproduccion','tst009-clro03',49.42,268,132,135,10),(237,'Test y Preproduccion','tst010-clro03',69.66,268,187,81,10),(238,'Test y Preproduccion','tst011-clro03',92.82,268,249,19,10),(239,'Test y Preproduccion','tst012-clro03',89.98,201,181,20,10),(240,'Test y Preproduccion','tst013-clro03',83.57,201,168,33,10),(241,'Test y Preproduccion','tst014-clro03',40.73,235,96,139,10),(242,'Test y Preproduccion','tst015-clro03',82.95,235,195,40,10),(243,'Test y Preproduccion','tst016-clro03',54.83,536,294,242,10),(244,'Test y Preproduccion','tst017-clro03',67.64,536,362,173,10),(245,'Test y Preproduccion','tst018-clro03',84.76,268,227,41,10),(246,'Test y Preproduccion','tst019-clro03',92.76,268,248,19,10),(247,'Test y Preproduccion','tst020-clro03',85.72,268,230,38,10),(248,'Test y Preproduccion','tst021-clro03',83.89,268,225,43,10),(249,'Test y Preproduccion','tst022-clro03',33.12,268,89,179,10),(250,'Test y Preproduccion','tst023-clro03',84.29,268,226,42,10),(251,'Test y Preproduccion','tst024-clro03',78.31,268,210,58,10),(252,'Test y Preproduccion','tst025-clro03',92.44,268,248,20,10),(253,'Test y Preproduccion','tst026-clro03',77.27,201,155,46,10),(254,'Test y Preproduccion','tst027-clro03',82,201,165,36,10),(255,'Test y Preproduccion','tst028-clro02',91.69,534,489,44,9),(256,'Test y Preproduccion','tst029-clro02',83.62,534,446,87,9),(257,'Test y Preproduccion','tst030-clro02',45.1,534,241,293,9),(258,'Test y Preproduccion','tst031-clro02',90.06,534,481,53,9),(259,'Test y Preproduccion','tst032-clro02',54.27,534,290,244,9),(260,'Test y Preproduccion','tst033-clro02',44,534,235,299,9),(261,'Test y Preproduccion','tst034-clro02',80.75,534,431,103,9),(262,'Test y Preproduccion','tst035-clro02',91.72,534,490,44,9),(263,'Test y Preproduccion','tst036-clro02',51.43,534,275,259,9),(264,'Bankia-PPMM','DMX3_L019',0.13,408,1,408,13),(265,'Bankia-PPMM','Produccion_DMX3_4',0.18,298,1,297,13),(266,'Bankia-PPMM','PRO_ROZ_VMAX3_FC6_L001',0.17,320,1,319,13),(267,'Bankia-PPMM','DES_ROZ_VMAX3_SATA_L011',0.09,608,1,607,13),(268,'Bankia-PPMM','DES_ROZ_VMAX3_SATA_L012',0.09,608,1,607,13),(269,'Bankia-PPMM','DES_ROZ_VMAX3_SATA_L013',0.09,608,1,607,13),(270,'Bankia-PPMM','TST_ROZ_VMAX3_SATA_L016',0.09,608,1,607,13),(271,'Bankia-PPMM','TRA_ROZ_VMAX3_SATA_L014',0.09,608,1,607,13),(272,'Bankia-PPMM','TRA_ROZ_VMAX3_SATA_L015',0.09,608,1,607,13),(273,'Bankia-PPMM','PRO_ROZ_VMAX3_FC6_L002',0.17,320,1,319,13),(274,'Bankia-PPMM','PRO_ROZ_VMAX3_FC6_L003',0.17,320,1,319,13),(275,'Bankia-PPMM','PRO_ROZ_VMAX3_FC6_L004',0.17,320,1,319,13),(276,'Bankia-PPMM','PRO_ROZ_VMAX3_FC6_L005',0.17,320,1,319,13),(277,'Bankia-PPMM','PRO_ROZ_VMAX3_FC6_L006',0.17,320,1,319,13),(278,'Bankia-PPMM','PRO_ROZ_VMAX3_FC6_L007',0.17,320,1,319,13),(279,'Bankia-PPMM','PRO_ROZ_VMAX3_FC6_L008',0.17,320,1,319,13),(280,'Bankia-PPMM','PRO_ROZ_VMAX3_FC6_L009',0.17,320,1,319,13),(281,'Bankia-PPMM','PRO_ROZ_VMAX3_FC6_L010',0.17,320,1,319,13),(282,'Bankia-PPMM','PRO_COR_VMAX3_FC6_L001',0.17,320,1,319,13),(283,'Bankia-PPMM','Transito_DMX2000_1',80.07,596,477,119,13),(284,'Bankia-PPMM','Produccion_DMX3_2',83.53,596,497,98,13),(285,'Bankia-PPMM','Desarrollo_Clariion_4',15.65,300,47,253,13),(286,'Bankia-PPMM','Produccion_DMX3_1',77.7,596,463,133,13),(287,'Bankia-PPMM','VMFS_NFS_HDS',86.96,399,347,52,13),(288,'Bankia-PPMM','Desarrollo_Test',44.75,187,84,103,13),(289,'Bankia-PPMM','Produccion_COR_DMX800_1',92.3,612,565,47,13),(290,'Bankia-PPMM','Produccion_COR_DMX4_1',95.14,629,598,31,13),(291,'Bankia-PPMM','Desarrollo_Pool_b',0.12,459,1,459,13),(292,'Bankia-PPMM','Produccion_DMX3_5',67.43,204,138,66,13),(293,'Bankia-PPMM','Desarrollo_Clariion_1',80.63,600,483,116,13),(294,'Bankia-PPMM','Desarrollo_Clariion_2',71.93,600,431,168,13),(295,'Bankia-PPMM','Desarrollo_Clariion_3',84.92,600,509,90,13),(296,'Bankia-PPMM','Transito_DMX2000_2',76.22,596,454,142,13),(297,'Bankia-PPMM','Transito_DMX2000_3',75.47,596,449,146,13),(298,'Bankia-PPMM','Produccion_DMX3_3',72.12,298,215,83,13),(299,'Bankia-PPMM','Transito_DMX2000_4',8.77,298,26,272,13),(300,'Bankia-PPMM','Produccion_DS8300_Rozas_OIv2',16.02,2,0,1,13),(301,'Bankia-PPMM','Produccion_DS8100_COR_OIv2',16.02,2,0,1,13),(302,'Bankia-PPMM','Produccion_COR_DMX4_2',77.89,145,113,32,13),(303,'Bankia-PPMM','DMX3_L001',98.4,298,293,5,13),(304,'Bankia-PPMM','DMX3_L010',88.97,298,265,33,13),(305,'Bankia-PPMM','DMX3_L013',81.86,298,244,54,13),(306,'Bankia-PPMM','DMX3_L008',33.2,145,48,97,13),(307,'Bankia-PPMM','DMX800_L080',25.3,145,37,108,13),(308,'Bankia-PPMM','DMX800_L079',14.75,77,11,65,13);
/*!40000 ALTER TABLE `Datastores_por_Datacenter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Elementos_virtuales`
--

DROP TABLE IF EXISTS `Elementos_virtuales`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Elementos_virtuales` (
  `idVMs` int(11) NOT NULL,
  `Hostname` varchar(45) character set latin1 default NULL,
  `VCPUs_instaladas` int(11) default NULL,
  `Memoria_instalada_MB` int(11) default NULL,
  `Almacenamiento_instalado_GB` int(11) default NULL,
  `Tipo_elemento_virtual` int(11) default NULL,
  `SO` int(11) default NULL,
  `Cluster` int(11) default NULL,
  `CPU_Consumida_Mhz` int(11) default NULL,
  `Memoria_Consumida_MB` int(11) default NULL,
  PRIMARY KEY  (`idVMs`),
  KEY `SO_id` (`SO`),
  KEY `Tipo elemento_virtual_id` (`Tipo_elemento_virtual`),
  KEY `Cluster_id` (`Cluster`),
  CONSTRAINT `Cluster_id` FOREIGN KEY (`Cluster`) REFERENCES `Clusters` (`idCluster`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `SO_id` FOREIGN KEY (`SO`) REFERENCES `Sistema_operativo` (`idSistema_operativo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Tipo elemento_virtual_id` FOREIGN KEY (`Tipo_elemento_virtual`) REFERENCES `Tipo_elemento` (`idTipo_elemento`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Elementos_virtuales`
--

LOCK TABLES `Elementos_virtuales` WRITE;
/*!40000 ALTER TABLE `Elementos_virtuales` DISABLE KEYS */;
INSERT INTO `Elementos_virtuales` VALUES (1,'VLISHTET - PROYECTO TETIS DE VALIDACION TARJE',1,3072,90,1,3,1,86,3061),(2,'VLISHSC2 - HOST ON DEMAND PARA COR',1,1024,30,1,3,1,109,847),(3,'PCS11917.grupo.cm.es',1,2048,30,1,1,1,454,1513),(4,'VLISHREP - REPOSITORIO FICHEROS ENTORNO SIP C',2,1024,20,1,3,1,216,759),(5,'V3KSDADT.grupo.cm.es',1,4096,79,1,2,1,129,2380),(6,'VLISHPFP.cm.es',1,1024,52,1,3,1,103,821),(7,'V8KALC02.grupo.cm.es',2,6144,100,1,2,1,481,4417),(8,'VLISHPF2.cm.es',1,1024,150,1,3,1,189,1020),(9,'V8KSDSDM.grupo.cm.es',2,4096,80,1,2,1,284,2955),(10,'V8KSHRFX.grupo.cm.es',2,2048,40,1,2,1,93,1128),(11,'VLISHPF1.cm.es',1,1024,150,1,3,1,193,1019),(12,'V3KCRBB2.grupo.cm.es',2,6144,65,1,2,1,463,4672),(13,'VLISHMFP  -  IMPRESION LEXMARK MFP PARA SIP',2,1024,20,1,3,1,138,891),(14,'V8KCROF4.Oficinas.grupo.cm.es',4,8192,62,1,2,1,639,3931),(15,'VLISHDEB - SERVIDOR DEBIAN COMUNICACIONES EN ',1,1024,358,1,3,1,16,787),(16,'V8KCRSV1.servicios.grupo.cm.es',4,8192,91,1,2,1,595,3718),(17,'V3KSHFBK - FAX CORPORATIVO BACKUP',2,2048,22,2,2,1,0,0),(18,'PCS11764.grupo.cm.es',2,2048,50,1,1,1,205,681),(19,'V8KSDSQL.grupo.cm.es',1,4096,80,1,2,1,165,3690),(20,'PCS11978.grupo.cm.es',2,2048,50,1,1,1,262,958),(21,'vlinags2.cm.es',2,2048,8,1,3,1,93,1727),(22,'V8KSPOF2.Oficinas.grupo.cm.es',2,6144,62,1,2,1,264,2146),(23,'V8KSPGR2.grupo.cm.es',2,6144,39,1,2,1,265,2164),(24,'VLISHSC1 - HOST ON DEMAND PARA COR',1,1024,30,1,3,1,110,854),(25,'V8KSHFPA.grupo.cm.es',2,2048,70,1,2,1,121,1137),(26,'PCS11761.grupo.cm.es',2,2048,50,1,1,1,274,1130),(27,'V3KPMI02 - PROYECTO MULTIDIOMA PORTALES INTER',2,4096,52,1,2,1,633,3047),(28,'PCS11933.grupo.cm.es',2,2048,50,1,1,1,314,1007),(29,'PCS11915.grupo.cm.es',1,1024,50,1,1,1,68,532),(30,'PCS11919.grupo.cm.es',1,1024,50,1,1,1,405,656),(31,'PCS11501.grupo.cm.es',2,2048,50,1,1,1,213,542),(32,'PCS11502.grupo.cm.es',2,2048,50,1,1,1,79,276),(33,'PCS11503.grupo.cm.es',2,2048,50,1,1,1,80,266),(34,'V8KVCEN4 - vCenter vSphere Produccion_replica',2,4096,44,3,2,1,1507,3689),(35,'PCS11914.grupo.cm.es',1,748,50,1,1,1,93,1727),(36,'vlishwcs.cm.es',2,4096,60,1,3,1,93,1727),(37,'PCS11712.grupo.cm.es',2,2048,50,1,1,1,282,1602),(38,'V3KSHFTP - BACKUP PELICAN FTP CENTRALIZADO',1,1024,16,1,2,1,169,506),(39,'V8KSHGW1.grupo.cm.es',1,2048,40,1,2,1,190,1563),(40,'V8KSHRTE.grupo.cm.es',2,2048,100,1,2,1,298,1433),(41,'V8KTIT06.Oficinas.grupo.cm.es',2,2048,46,1,2,1,260,1340),(42,'V8KTIT15.grupo.cm.es',1,2048,46,1,2,1,198,1363),(43,'V3KCRBB1 - SERVICIOS DE BLACKBERRY',2,6144,48,1,2,1,173,2249),(44,'V3KCDCR2 - SERVICIOS DE RED EN COR',2,2048,112,1,2,1,463,973),(45,'V3KCDCOR.grupo.cm.es',2,2048,812,1,2,1,351,1347),(46,'V8KCRGR4.grupo.cm.es',4,8192,62,1,2,1,724,5943),(47,'V3KEVCR2 - ENTERPRISE VAULT PARA COR',2,4096,136,1,2,1,141,1438),(48,'V8KCRTMP.grupo.cm.es',2,3072,80,1,2,1,239,1995),(49,'V3KEVCR3.grupo.cm.es',2,4096,132,1,2,1,119,2345),(50,'V8KSHBC1.grupo.cm.es',4,4096,48,1,2,1,302,1818),(51,'V3KSHOC4.grupo.cm.es',1,2048,72,1,2,1,176,1198),(52,'V3KTF001 - TEAM FOUNDATION SERVER',1,1024,70,1,2,1,123,403),(53,'VLISHAC2 Servidor Radius CISCO Backup ACS 5.1',2,6144,500,1,3,1,0,0),(54,'vlishbcx.cm.es',1,4096,80,1,3,1,93,1727),(55,'V3KROLF2.grupo.cm.es',1,1024,16,1,2,1,321,657),(56,'PCS11500.grupo.cm.es',2,2048,50,1,1,1,211,639),(57,'PCS11504.grupo.cm.es',2,2048,50,1,1,1,76,349),(58,'V8KSDBOB.grupo.cm.es',1,4096,80,1,2,1,167,2770),(59,'VLISHMQ3 - SERVIDOR DE MQ SERIES PARA AMBAR',2,4096,62,1,3,1,160,3245),(60,'PCS11854 - PUESTOS SIP',2,2048,50,1,1,2,189,716),(61,'VID10021 - OFICINAS EMI',2,2048,30,2,1,2,527,1020),(62,'VID10005 - OFICINAS EMI',2,2048,30,2,1,2,517,1055),(63,'VID10023 - OFICINAS EMI',2,2048,30,2,1,2,506,977),(64,'PCS80162 - NUSE_RECUPERADORES NA',2,2024,30,2,1,2,0,0),(65,'VID10040 - OFICINAS EMI',2,2048,30,2,1,2,534,1401),(66,'VID10016 - OFICINAS EMI',2,2048,30,2,1,2,554,1048),(67,'PCS11865 - PUESTOS NOS EMI',2,2048,30,2,1,2,527,1160),(68,'PCS11855 - PUESTOS NOS EMI',2,2048,30,2,1,2,506,1197),(69,'VIDBASE3 - NO ENCENDER VIDbase original',2,2048,35,2,1,2,0,0),(70,'PCS80404 - PUESTOS NOS EMI',2,2048,30,2,1,2,491,1048),(71,'PCS11847 - PUESTOS SIP',2,2048,50,1,1,2,196,762),(72,'VID10025 - OFICINAS EMI',2,2048,30,2,1,2,511,1048),(73,'PCS10615 - NUSE_RECUPERADORES',2,2048,50,1,1,2,353,1593),(74,'VID11006 - OFICINAS PREP',2,2048,35,2,1,2,438,1387),(75,'PCS11923.grupo.cm.es',2,2048,50,1,1,2,237,1971),(76,'VID10004 - OFICINAS EMI',2,2048,30,2,1,2,529,1078),(77,'VID10039 - OFICINAS EMI',2,2048,30,2,1,2,521,1058),(78,'VIDQ0003 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,537,1133),(79,'PCS11926 - PRUEBAS W7 LABORATORIO ESCRITORIOS',2,2048,40,2,1,2,375,1453),(80,'VIDQ0014 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,411,1085),(81,'VIDQ0019 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,442,1044),(82,'VID10001 - OFICINAS EMI',2,2048,30,2,1,2,524,1077),(83,'P0966 - PUESTO CAJA AVILA',2,2000,44,1,1,2,63,566),(84,'FY21.cajadeavila.es',2,1500,14,1,1,2,93,1727),(85,'p0988.cajadeavila.es',2,2048,149,1,1,2,93,1727),(86,'PCSPRUW7',1,1024,40,2,1,2,0,0),(87,'PCSPR2W7',2,2048,40,1,1,2,88,1545),(88,'V1142.cajadeavila.es',1,1024,25,1,1,2,93,1727),(89,'FP38.cajadeavila.es',1,2048,20,1,1,2,93,1727),(90,'VIDQ0027 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,364,1040),(91,'VIDQ0033 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,438,1202),(92,'VIDQ0035 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,1228,1028),(93,'VIDQ0037 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,354,1088),(94,'VIDQ0045 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,373,1044),(95,'VIDQ0048 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,361,1029),(96,'VIDQ0049 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,361,1031),(97,'VIDQ0047 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,365,1106),(98,'VIDQ1004 - OFICINAS CONTINGENCIA LINK',2,2048,35,2,1,2,104,248),(99,'PCS10608 - NUSE_RECUPERADORES',2,3072,30,1,1,2,199,2199),(100,'PCS10616 - AUDITORIA SIP',2,2048,50,1,1,2,469,1190),(101,'PCS11895 - PRUEBAS W7 LABORATORIO ESCRITORIOS',2,2048,40,1,1,2,250,1522),(102,'PCS10612.grupo.cm.es',2,3072,30,1,1,2,93,1727),(103,'PCS11857 - PUESTOS NOS EMI',2,2048,30,2,1,2,518,1168),(104,'VID10020 - OFICINAS EMI',2,2048,30,2,1,2,563,1055),(105,'PCS11846 - PUESTOS SIP',2,2048,50,1,1,2,180,754),(106,'@VID10000 - TEMPLATE PUESTOS OFICINAS EMI',1,1024,30,3,1,2,0,0),(107,'PCS80103.grupo.cm.es',2,2024,30,1,1,2,677,1389),(108,'PCS80106.grupo.cm.es',2,2024,30,1,1,2,787,1354),(109,'PCS10602 - NUSE_RECUPERADORES',2,3072,30,1,1,2,159,1092),(110,'VID10036 - OFICINAS EMI',2,2048,30,2,1,2,540,1023),(111,'PCS10638 - NUSE_RECUPERADORES',2,2024,30,1,1,2,431,1117),(112,'',2,3072,30,1,1,2,93,1727),(113,'SOAT0760 - SERVIDOR EMI',2,2048,80,1,3,2,836,1769),(114,'PCS70041 - PC DIRECCION AREA GESTION INFRAEST',2,2048,40,1,1,2,422,1382),(115,'@PCS##### - TEMPLATE PUESTOS NOS EMI',1,1024,30,3,1,2,0,0),(116,'PCS80160 - NUSE_RECUPERADORES NA',2,2024,30,2,1,2,0,0),(117,'PCS11866 - PUESTOS NOS EMI',2,2048,30,2,1,2,556,1204),(118,'VID10015 - OFICINAS EMI',2,2048,30,2,1,2,554,1122),(119,'PCS80203.grupo.cm.es',2,4096,40,1,1,2,572,2400),(120,'F89J.cajadeavila.es',2,3064,75,1,1,2,80,1326),(121,'PCS80114.grupo.cm.es',2,2024,30,1,1,2,687,1202),(122,'FP41 - PUESTO CAJA AVILA',1,800,20,2,1,2,0,0),(123,'FP44 - PUESTO CAJA AVILA',1,2048,20,2,1,2,0,0),(124,'FP47 - PUESTO CAJA AVILA',1,2048,20,2,1,2,0,0),(125,'FP32.cajadeavila.es',1,2048,20,1,1,2,93,1727),(126,'FP34.cajadeavila.es',1,2048,20,1,1,2,93,1727),(127,'VIDQ0044 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,347,1115),(128,'FP37.cajadeavila.es',1,2048,20,1,1,2,93,1727),(129,'VIDQ0031 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,343,1100),(130,'VIDQ0030 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,372,1014),(131,'VIDQ0043 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,362,1059),(132,'VIDQ0050 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,347,1120),(133,'VIDQ0018 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,349,1373),(134,'VIDBASEL',2,2048,35,2,1,2,23,91),(135,'V3KPRCAV - CajaAvila FastMail',2,4096,240,1,2,2,588,3033),(136,'PCS10601 - NUSE_RECUPERADORES',2,3072,30,1,1,2,134,766),(137,'PCS80116 - OF. DE REPRESENTACION NA',2,2024,30,2,1,2,0,0),(138,'VID##### - Original Puesto oficina NO ENCENDE',1,1024,30,2,1,2,0,0),(139,'PCS80109 - OF. DE REPRESENTACION',2,2024,30,1,1,2,320,1004),(140,'@VID11### - Template W7',1,1024,30,3,1,2,0,0),(141,'PCS10610 - NUSE_RECUPERADORES',2,3072,30,1,1,2,129,864),(142,'VIDQ0004 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,555,1222),(143,'VID10002 - OFICINAS EMI',2,2048,30,2,1,2,541,1090),(144,'PCS11849 - PUESTOS SIP',2,2048,50,1,1,2,190,782),(145,'SOAC0110 - SERVIDOR CONTINGENCIA',1,2048,100,1,3,2,378,1651),(146,'SOAB0110 - SERVIDOR CONTINGENCIA',1,2048,100,1,3,2,382,1651),(147,'VID10026 - OFICINAS EMI',2,2048,30,2,1,2,539,1023),(148,'PCS80108 - OF. DE REPRESENTACION',2,2024,30,1,1,2,413,1397),(149,'PCS10611 - NUSE_RECUPERADORES',2,3072,30,1,1,2,174,1193),(150,'VID10010 - OFICINAS EMI',2,2048,30,2,1,2,536,1035),(151,'VID10037 - OFICINAS EMI',2,2048,30,2,1,2,552,1063),(152,'PCS80406 - PUESTOS NOS EMI',2,2048,30,2,1,2,578,1310),(153,'VID10024 - OFICINAS EMI',2,2048,30,2,1,2,536,978),(154,'PCS80400 - PUESTOS NOS EMI',2,2048,30,2,1,2,597,1295),(155,'VIDQ0010 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,432,988),(156,'VID10006 - OFICINAS EMI-EPI',2,2048,30,2,1,2,68,303),(157,'VIDQ0025 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,602,1061),(158,'VIDQ0002 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,556,1053),(159,'PCS80120 - DESARROLLO GESTION INFRAESTRUCTURA',2,2024,30,1,1,2,1543,1237),(160,'PCS11972 - PRUEBAS W7 LABORATORIO ESCRITORIOS',2,2048,40,2,1,2,0,0),(161,'VIDQ0005 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,608,1164),(162,'VID10003 - OFICINAS EMI',2,2048,30,2,1,2,646,1086),(163,'VIDQ0012 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,429,1002),(164,'PCS11898 - PRUEBAS W7 LABORATORIO ESCRITORIOS',2,2048,40,1,1,2,372,1277),(165,'PCS11903.grupo.cm.es',2,2048,40,1,1,2,374,1242),(166,'PCS11906.grupo.cm.es',2,2048,40,1,1,2,379,1434),(167,'PCS80403 - PUESTOS NOS EMI',2,2048,30,2,1,2,642,1186),(168,'PCS11896 - PRUEBAS W7 LABORATORIO ESCRITORIOS',2,2048,40,1,1,2,409,1583),(169,'VIDQ0015 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,499,985),(170,'FPCA.cajadeavila.es',1,2048,18,1,1,2,93,1727),(171,'PCS80204.grupo.cm.es',2,4096,40,1,1,2,604,2140),(172,'FP45 - PUESTO CAJA AVILA',1,2048,20,2,1,2,0,0),(173,'FP36.cajadeavila.es',1,2048,20,1,1,2,93,1727),(174,'FP39.cajadeavila.es',1,2048,20,1,1,2,93,1727),(175,'FP40 - PUESTO CAJA AVILA',1,2048,20,2,1,2,2,21),(176,'VIDQ0042 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,368,1028),(177,'SOAD0110 - SERVIDOR CONTINGENCIA',1,2048,100,1,3,2,191,1816),(178,'PCS11899 - PRUEBAS W7 LABORATORIO ESCRITORIOS',2,2048,40,2,1,2,4748,1379),(179,'PCS10606 - NUSE_RECUPERADORES',2,3072,30,1,1,2,376,1469),(180,'PCS11861 - PUESTOS NOS EMI',2,2048,30,2,1,2,553,1207),(181,'VID10033 - OFICINAS EMI',2,2048,30,2,1,2,460,951),(182,'VID10029 - OFICINAS EMI',2,2048,30,2,1,2,566,1027),(183,'PCS80161 - NUSE_RECUPERADORES NA',2,2024,30,2,1,2,0,0),(184,'PCS11864 - PUESTOS NOS EMI',2,2048,30,2,1,2,588,1162),(185,'VID10042 - OFICINAS EMI',2,2048,30,2,1,2,520,1052),(186,'PCS80102.grupo.cm.es',2,2024,30,1,1,2,455,1341),(187,'VID10030 - OFICINAS EMI',2,2048,30,2,1,2,490,1016),(188,'VID10034 - OFICINAS EMI',2,2048,30,2,1,2,553,1043),(189,'VIDQ0008 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,415,1047),(190,'VIDQ0001 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,628,1184),(191,'PCS10622 - AUDITORIA SIP',2,2048,50,1,1,2,517,1152),(192,'PCS10637 - NUSE_RECUPERADORES',2,2024,30,1,1,2,496,1217),(193,'PCS80200 - SOPORTE DESDE UK-ASSIMA',2,2024,30,1,1,2,489,1384),(194,'PCS80401 - PUESTOS NOS EMI',2,2048,30,2,1,2,526,1124),(195,'VIDQ0017 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,441,969),(196,'PCS80104.grupo.cm.es',2,2024,30,1,1,2,527,1272),(197,'PCS10634 - NUSE_RECUPERADORES',2,2084,30,1,1,2,295,1203),(198,'PCS80226 - PCS EQUIPO DE PROCESO',2,2048,40,1,1,2,111,1547),(199,'PCS80227.grupo.cm.es',2,2048,40,1,1,2,1528,1661),(200,'VID10012 - OFICINAS EMI',2,2048,30,2,1,2,985,1090),(201,'VIDQ0024 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,424,993),(202,'VID10032 - OFICINAS EMI',2,2048,30,2,1,2,512,1029),(203,'PCS11897 - PRUEBAS W7 LABORATORIO ESCRITORIOS',2,2048,40,1,1,2,414,1527),(204,'VIDQ0011 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,665,1030),(205,'PCS11902 - PRUEBAS W7 LABORATORIO ESCRITORIOS',2,2048,40,1,1,2,365,1561),(206,'PCS80407.grupo.cm.es',2,2048,30,1,1,2,476,1132),(207,'F89E.cajadeavila.es',2,3316,149,1,1,2,128,1554),(208,'VIDBASET',2,2048,35,3,1,2,4,7),(209,'v1032.cajadeavila.es',1,1024,18,1,1,2,93,1727),(210,'FP42 - PUESTO CAJA AVILA',1,2048,20,2,1,2,6,87),(211,'FP46 - PUESTO CAJA AVILA',1,2048,20,2,1,2,0,0),(212,'FP49 - PUESTO CAJA AVILA',1,2048,20,2,1,2,11,181),(213,'FP31.cajadeavila.es',1,2048,20,1,1,2,93,1727),(214,'VIDQ0029 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,354,1083),(215,'VIDQ0040 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,367,1063),(216,'PCS10619 - AUDITORIA SIP',2,2048,50,1,1,2,488,1059),(217,'PCS80405 - PUESTOS NOS EMI',2,2048,30,2,1,2,555,1151),(218,'VID10019 - OFICINAS EMI',2,2048,30,2,1,2,634,1076),(219,'VIDQ0022 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,428,1023),(220,'VID10038 - OFICINAS EMI',2,2048,30,2,1,2,436,1004),(221,'',2,3072,30,1,1,2,93,1727),(222,'PCS80111 - OF. DE REPRESENTACION',2,2024,30,1,1,2,249,715),(223,'PCS80112 - OF. DE REPRESENTACION',2,2024,30,1,1,2,336,742),(224,'PCS80100.grupo.cm.es',2,2024,30,1,1,2,434,1400),(225,'VID10017 - OFICINAS EMI',2,2048,30,2,1,2,532,1160),(226,'VLIRODHC - Servidor DHCP para proyecto NUSE',1,256,8,1,3,2,114,248),(227,'PCS80113 - OF. DE REPRESENTACION',2,2024,30,1,1,2,297,697),(228,'PCS80121 - PRUEBAS CONEXION PORTAL VDI',2,2024,30,1,1,2,307,1316),(229,'PCS80105 - OF. DE REPRESENTACION',2,2024,30,1,1,2,857,1065),(230,'PCS10609 - NUSE_RECUPERADORES',2,3072,30,1,1,2,154,1100),(231,'PCS10603 - NUSE_RECUPERADORES',2,3072,30,1,1,2,339,662),(232,'VIDQ0020 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,437,1051),(233,'VID10041 - OFICINAS EMI',2,2048,30,2,1,2,544,1051),(234,'@PCS - W7 TEMPLATE PTrabaj Escritori40Gb',2,2048,40,3,1,2,0,0),(235,'PCS11904 - PRUEBAS W7 LABORATORIO ESCRITORIOS',2,2048,40,2,1,2,326,1417),(236,'PCS11929 - PRUEBAS W7 LABORATORIO ESCRITORIOS',2,2048,40,2,1,2,168,766),(237,'PCS11927.grupo.cm.es',2,2048,40,1,1,2,362,1540),(238,'F895.cajadeavila.es',2,2048,149,1,1,2,113,1897),(239,'PCS80202 - DESARROLLO GESTION PROCESO',2,4096,40,1,1,2,681,2396),(240,'V0898.cajadeavila.es',1,1024,30,1,1,2,93,1727),(241,'FP48 - PUESTO CAJA AVILA',1,2048,20,2,1,2,0,0),(242,'FP33.cajadeavila.es',1,2048,20,1,1,2,93,1727),(243,'VIDQ0034 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,354,1103),(244,'VIDQ0046 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,364,1084),(245,'VIDQ0039 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,350,1096),(246,'PCS80163 - NUSE_RECUPERADORES NA',2,2024,30,2,1,2,0,0),(247,'VIDQ1001 - OFICINAS CONTINGENCIA LINK',2,2048,35,2,1,2,72,256),(248,'VIDQ0057',2,2048,35,2,1,2,72,175),(249,'PCS80117 - OF. DE REPRESENTACION NA',2,2024,30,2,1,2,0,0),(250,'PCS10621 - AUDITORIA SIP',2,3072,50,1,1,2,929,1513),(251,'VID10022 - OFICINAS EMI',2,2048,30,2,1,2,578,1146),(252,'VIDQ0023 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,431,1055),(253,'PCS80110.grupo.cm.es',2,2024,30,1,1,2,365,825),(254,'PCS80101.grupo.cm.es',2,2024,30,1,1,2,437,1165),(255,'VIDQ0021 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,448,989),(256,'PCS10620.grupo.cm.es',2,2048,50,1,1,2,388,1013),(257,'VID10018 - OFICINAS EMI',2,2048,30,2,1,2,555,1005),(258,'VIDQ0006 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,441,994),(259,'PCS80164 - NUSE_RECUPERADORES NA',2,2024,30,2,1,2,0,0),(260,'VIDQ0016 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,437,981),(261,'VID10009 - OFICINAS EMI',2,2048,30,2,1,2,475,996),(262,'VID10007 - OFICINAS EMI-EPI',2,2048,30,2,1,2,279,281),(263,'VID10027 - OFICINAS EMI',2,2048,30,2,1,2,515,1054),(264,'VLIRODNE - Servidor DNS para EMI',1,256,8,1,3,2,116,247),(265,'PCS10605 - NUSE_RECUPERADORES',2,3072,30,1,1,2,144,975),(266,'VIDQ0007 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,444,968),(267,'PCS11848 - PUESTOS SIP',2,2048,50,1,1,2,188,673),(268,'PCS10617 - AUDITORIA SIP',2,2048,50,1,1,2,394,1015),(269,'PCS70040 - PC DIRECCION DEPTO. COMUNICACIONES',1,1024,40,1,1,2,192,798),(270,'PCS00TL4 - TEMPLATE TL4 BANCAJA FORMACION',1,768,15,2,1,2,0,0),(271,'PCS10607 - NUSE_RECUPERADORES',2,3072,30,1,1,2,135,869),(272,'PCS11859 - PUESTOS NOS EMI',2,2048,30,2,1,2,575,1208),(273,'VID10014 - OFICINAS EMI',2,2048,30,2,1,2,742,1063),(274,'VIDQ0013 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,435,967),(275,'PCS11905.grupo.cm.es',2,2048,40,1,1,2,395,1429),(276,'PCS80138',2,2048,40,1,1,2,75,1268),(277,'VIDQTEMP',2,2048,35,2,1,2,0,0),(278,'V8KAUDBC - DISCOS DE GRUPO PARA HISTORICOS OP',2,2048,969,1,2,2,120,1608),(279,'VIDQ0028 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,404,1061),(280,'FP43.cajadeavila.es',1,2048,20,1,1,2,93,1727),(281,'FP50 - PUESTO CAJA AVILA',1,2048,20,2,1,2,10,120),(282,'FP35.cajadeavila.es',1,2048,20,1,1,2,93,1727),(283,'VIDQ0026 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,363,1045),(284,'VIDQ0032 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,509,1041),(285,'VIDQ0036 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,331,1186),(286,'VIDQ0038 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,359,1069),(287,'VIDQ0041 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,358,1091),(288,'PCS11925 - PRUEBAS W7 LABORATORIO ESCRITORIOS',2,2048,40,1,1,2,205,1460),(289,'PCS11928 - PRUEBAS W7 LABORATORIO ESCRITORIOS',2,2048,40,2,1,2,257,1088),(290,'VIDQ0009 - OFICINAS CONTINGENCIA',2,2048,35,2,1,2,432,989),(291,'VIDQ1002 - OFICINAS CONTINGENCIA LINK',2,2048,35,2,1,2,108,219),(292,'VIDQ1003 - OFICINAS CONTINGENCIA LINK',2,2048,35,2,1,2,90,233),(293,'VID10028 - OFICINAS EMI',2,2048,30,2,1,2,519,1061),(294,'PCS80165 - NUSE_RECUPERADORES NA',2,2024,30,2,1,2,0,0),(295,'PCS80119 - OF. DE REPRESENTACION NA',2,2024,30,1,1,2,358,656),(296,'PCS80118 - OF. DE REPRESENTACION NA',2,2024,30,2,1,2,0,0),(297,'PCS80107 - OF. DE REPRESENTACION',2,2024,30,1,1,2,378,1104),(298,'VID10035 - OFICINAS EMI',2,2048,30,2,1,2,478,1004),(299,'VID10013 - OFICINAS EMI',2,2048,30,2,1,2,781,1070),(300,'VID10031 - OFICINAS EMI',2,2048,30,2,1,2,521,1073),(301,'VID10008 - OFICINAS EMI',2,2048,30,2,1,2,511,1036),(302,'PCS80402 - PUESTOS NOS EMI',2,2048,30,2,1,2,567,1202),(303,'VID10011 - OFICINAS EMI',2,2048,30,2,1,2,454,1004),(304,'VLIROWEB - HOMOLOGACIONES WEB',1,1024,14,1,3,3,19,949),(305,'VLIRODEB - SERVIDOR DEBIAN COMUNICACIONES',1,1024,350,1,3,3,137,989),(306,'VLIROBCR - BLUECOAT REPORTER',1,1024,30,1,5,3,47,979),(307,'VLIRODIS - DISTRIBUCION SOFTWARE LINUX OFICIN',1,512,36,1,5,3,18,276),(308,'V3KROBW1 - BANCWARE APLICACIONES P1',1,2048,48,1,2,3,147,863),(309,'VLIROMAS - MASTER VERSIONES SOFT. OFICINAS',2,2048,250,1,3,3,44,1933),(310,'VLIRO005 - CENTRALIZACION DE LOGS',1,512,13,1,5,3,34,417),(311,'V3KSUSP2.grupo.cm.es',2,1024,48,1,2,3,2577,820),(312,'V3KFAMAW - PROYECTO FAMA PRODUCCION',2,2048,52,1,2,3,81,826),(313,'VLIROSC1 - HOST ON DEMAND ROZAS 1',1,1024,30,1,5,3,80,929),(314,'V8KPKI01.grupo.cm.es',2,2048,65,1,2,3,214,1395),(315,'V8KSIM01.grupo.cm.es',2,4096,56,1,2,3,583,3232),(316,'V3KCVI01.grupo.cm.es',1,2048,51,1,2,3,456,1516),(317,'V2KROMR1.grupo.cm.es',1,2048,33,1,6,3,462,1440),(318,'V3KCWA01 - LIVE COMMUNICATION SERVER & SHAREP',1,512,16,1,2,3,179,356),(319,'S2KMI201 - DOCUMENTACION OFIC. INTERNACIONALE',1,1024,37,1,2,3,163,642),(320,'V3KHPBD1 - SERVIDOR BB.DD. PROYECTO BTO',2,2048,32,1,2,3,334,1634),(321,'V8KPKI02.grupo.cm.es',2,2048,65,1,2,3,219,1451),(322,'V3KEDEA1 - PORTAL EDEA CMMI3',2,2048,51,1,2,3,285,1144),(323,'V3KADTSM - CONSOLA ADMINISTRACION TSM',1,2048,32,1,2,3,254,1328),(324,'VLIROPF1 - Servidores Linux del Pelican',1,1024,150,1,3,3,240,1020),(325,'V3KGECAP.grupo.cm.es',1,1024,32,1,2,3,256,662),(326,'VLIGIS02 - SONDAS LINUX GIS',2,2048,24,1,3,3,297,1999),(327,'V3KRKL01.grupo.cm.es',1,1024,16,1,2,3,155,539),(328,'V3KROBLI.grupo.cm.es',2,1024,20,1,2,3,251,607),(329,'V2KRO008.cm.es',2,2048,66,1,6,3,1634,1499),(330,'VLIROMTX - MONITORES DE RENDIMIENTO',2,2048,50,1,3,3,1022,2032),(331,'V2KRO009.cm.es',4,4096,272,1,6,3,1480,1174),(332,'V3KHQ002 - HERRAMIENTAS DE QUEST SOFTWARE',1,2048,208,1,2,3,0,0),(333,'V3KSPST1.grupo.cm.es',1,2048,42,1,2,3,0,0),(334,'V3KROVUM.grupo.cm.es',1,1024,38,1,2,3,0,0),(335,'V3KWIKIM - WIKIMEDIA PARA SEGURIDAD',1,1024,22,1,2,3,0,0),(336,'V3KSQLD1 - SQL SERVER DESARROLLO 1',2,4096,313,1,2,3,0,0),(337,'VLIROISO.cm.es',1,1024,238,1,3,3,0,0),(338,'V3KSPST2.grupo.cm.es',1,1024,16,1,2,3,0,0),(339,'PCS11911 - SONDAS XP GIS',1,512,11,1,1,3,0,0),(340,'V3KLICO2 - SERVIDOR LICENCIAS TERMINAL SERVER',1,1024,8,1,2,3,0,0),(341,'SEXROSE2.grupo.cm.es',2,2048,22,1,2,3,0,0),(342,'vlirot10.cm.es',1,1024,8,1,3,3,93,1727),(343,'V2KROBB1 - BLACKBERRY 4',2,2048,34,1,2,3,0,0),(344,'V3KCPC01.grupo.cm.es',1,1024,28,1,2,3,0,0),(345,'V3KCDRO1 - Antiguo V3KCDROM',1,1024,305,1,2,3,0,0),(346,'V3KDINWS - DYNASIGHT WEB SERVER',1,4000,21,1,2,3,0,0),(347,'V2KROBW1.grupo.cm.es',1,2048,67,1,6,3,0,0),(348,'V8KROWEB - SERVIDOR WEB MIGRACION APLICACIONE',2,3072,105,1,5,3,0,0),(349,'VLIROOCS - INVENTARIO SOFTWARE LIBRE',1,1024,10,1,3,3,0,0),(350,'V8KENSQL.grupo.cm.es',2,2048,94,1,2,3,0,0),(351,'V8KPRT02.grupo.cm.es',2,4096,106,1,2,3,0,0),(352,'PCS11909 - SONDAS XP GIS',1,1024,10,1,1,3,0,0),(353,'vliromr3.cm.es',2,4096,34,1,3,3,93,1727),(354,'V3KSIGAL.grupo.cm.es',1,1024,18,1,2,3,0,0),(355,'V8KWSUP5.grupo.cm.es',2,2048,70,1,2,3,0,0),(356,'V8KAUSIP.grupo.cm.es',1,1024,244,1,2,3,0,0),(357,'VLIROPFE - Servidores Linux del Pelican',1,1024,150,1,3,3,0,0),(358,'V3KVCEN3.grupo.cm.es',4,4096,30,1,2,3,0,0),(359,'V3KAPGIN - APLICACIONES DE GESTION INTERNA',1,1024,46,1,2,3,0,0),(360,'V2KROIR3 - NICS-IR (INFORM. A REVELAR A TERCE',1,1024,21,1,6,3,0,0),(361,'V3KCPCP1.grupo.cm.es',1,2048,38,1,2,3,0,0),(362,'V3KOCS1 - LIVE COMMUNICATION SERVER & SHAREPO',1,512,16,1,2,3,0,0),(363,'V2KROARQ - PRUEBAS ARQUITECTURA',1,2048,48,1,6,3,0,0),(364,'V8KROSV1 - CONTROLADOR DE DOMINIO SERVICIOS',2,4096,72,1,5,3,0,0),(365,'VLIGIS03 - SONDAS LINUX GIS',2,2048,24,1,3,3,0,0),(366,'V2KLEF31 - LABORATORIO EXCHANGE 2003 (FRONTAL',1,512,8,1,2,3,0,0),(367,'V3KDOPER - XPRESSION DOCUMENTACION PERSONALIZ',1,1500,20,1,2,3,0,0),(368,'VLIROAST.cm.es',1,3072,100,1,3,3,0,0),(369,'V3KTRUE1 - TRUEPROOF SERVIDOR DE IMPRESION',1,1024,25,1,2,3,0,0),(370,'VLIROPX1 - DNS MASTER PILOTO SAURON',2,2052,30,1,3,3,0,0),(371,'V3KNICEW - NICE WEB BASED APPLICATIONS',1,1024,33,1,2,3,0,0),(372,'vliromr2.cm.es',2,4096,70,1,3,3,93,1727),(373,'vlirot07.cm.es',1,1024,8,1,3,3,93,1727),(374,'V3KCMEB5.grupo.cm.es',2,3072,33,1,2,3,0,0),(375,'V3KMERCU - SERVIDOR HERRAMIENTAS MERCURY',1,1024,28,1,2,3,0,0),(376,'VLIROT03 - GATEWAY DE TIVOLI PRODUCCION 3',1,1024,24,1,3,3,0,0),(377,'V8KTIT11 - SERVICIOS TITAN EN SS.CC.',1,2048,28,1,2,3,0,0),(378,'V3KROAR4 - PRUEBAS ARQUITECTURA',1,2048,57,1,2,3,0,0),(379,'V3KSMSID.grupo.cm.es',1,1024,16,1,2,3,0,0),(380,'V3KSUSP1.grupo.cm.es',2,1024,48,1,2,3,0,0),(381,'V8KWSUP4.grupo.cm.es',2,2048,75,1,2,3,0,0),(382,'V8KCMO04.grupo.cm.es',2,4096,95,1,2,3,0,0),(383,'V3KPLWEB.grupo.cm.es',2,2048,25,1,2,3,0,0),(384,'V3KTRPM1.grupo.cm.es',4,5120,32,1,2,3,702,2864),(385,'V3KHYN12.grupo.cm.es',2,8192,63,1,2,3,314,5767),(386,'V8KCCTR1.grupo.cm.es',2,4096,100,1,2,3,1401,3722),(387,'V3KSWDI1.grupo.cm.es',4,4096,116,1,2,3,412,3172),(388,'V3KSMSFW.grupo.cm.es',1,1024,16,1,2,3,186,510),(389,'V8KRORED.grupo.cm.es',2,4096,100,1,2,3,1606,2994),(390,'V3KESSB9 - ENABLEMENT ESSBASE SYSTEM9',2,4096,116,1,2,3,376,3006),(391,'V3KINVSR.grupo.cm.es',1,2048,25,1,2,3,224,1150),(392,'VLIROMR1 - MONITORES RENDIMIENTO Z%2fOS',2,1024,20,1,3,3,436,1002),(393,'V3KCVI02.grupo.cm.es',2,2048,61,1,2,3,757,1341),(394,'V3KSQLD3 - SQL SERVER DESARROLLO 3',2,4096,213,1,2,3,527,3273),(395,'V3KSCOMG.grupo.cm.es',1,1024,20,1,2,3,180,543),(396,'V3KROBPA - SERVIDOR ORACLE PARA BPA',2,2048,25,1,2,3,226,1103),(397,'VLIPTBRK - VIRTUALIZACION PUESTOS OFICINAS SI',2,1024,20,1,3,3,516,943),(398,'V3KHYN11.grupo.cm.es',2,8192,63,1,2,3,2029,5741),(399,'S3KROSTCENTER.grupo.cm.es',1,1024,218,1,2,3,530,860),(400,'PCS11921 - ALERTAS SIG',1,1024,10,1,1,3,83,838),(401,'V3KOM001.grupo.cm.es',2,1024,16,1,2,3,276,635),(402,'V3KHPDG1 - CONTROL DE DIAGNOSTICOS DE HP%2f L',1,2048,32,1,2,3,455,1375),(403,'vlirodoc.cm.es',1,1024,154,1,3,3,93,1727),(404,'V3KBKADM.grupo.cm.es',1,768,70,1,2,3,190,444),(405,'V2KROAR3 - PRUEBAS METODOS Y HERRAMIENTAS',1,2048,75,1,6,3,178,1355),(406,'V8KRODIS.grupo.cm.es',1,2048,70,1,2,3,253,1586),(407,'V3KV2RCC - V2 RED COMERCIAL Y CARTERAS',1,768,16,1,2,3,80,417),(408,'V3KWEBSC.grupo.cm.es',1,2048,58,1,2,3,259,1032),(409,'V3KLICO1 - SERVIDOR LICENCIAS TERMINAL SERVER',1,512,8,1,2,3,154,340),(410,'vlirot09.cm.es',1,1024,8,1,3,3,93,1727),(411,'vlirot08.cm.es',1,1024,8,1,3,3,93,1727),(412,'VLIROC01 - SERVIDOR INSTALACIONES POR RED',1,512,86,1,5,3,41,502),(413,'vlinagcn.cm.es',2,4096,8,1,3,3,93,1727),(414,'V3KSUSP4 - APLICACION WSUS PARA W7 y Vista',2,1024,50,1,2,3,642,843),(415,'V3KPPS01 - PROJECT PORTFOLIO SERVER 2007',1,4096,21,1,2,3,178,2053),(416,'V3KPMI01 - PROYECTO MULTIDIOMA PORTALES INTER',2,4096,52,1,2,3,554,3046),(417,'V3KROBW2 - BANCWARE APLICACIONES P2',1,2048,20,1,2,3,151,732),(418,'PCS11912.grupo.cm.es',1,1024,11,1,1,3,91,724),(419,'PCS11907.grupo.cm.es',1,1024,10,1,1,3,41,547),(420,'V3KBIOSF - VOCALPASSWORD FILE SYSTEM',1,1024,60,1,2,3,172,816),(421,'VLIROT06  - GATEWAY DE TIVOLI PRODUCCION 6',1,1024,8,1,3,3,97,971),(422,'V3KTWS01.grupo.cm.es',2,2048,20,1,2,3,234,884),(423,'V3KHPLR1 - HERRAMIENTAS DE LOAD RUNNER',1,1024,32,1,2,3,199,749),(424,'VLIROMPF.cm.es',1,1024,20,1,3,3,103,1004),(425,'V3KWEBEX - SERVIDOR WEB PLANOS CPD',1,768,16,1,2,3,188,490),(426,'V3KCITAW - SERVICIO WEB DE CITA PREVIA',1,1024,16,1,2,3,174,576),(427,'VNTRO00G - EUROGES PRODUCCION',1,512,41,1,6,3,217,433),(428,'VLIRO007 - DINAMIS TRANSITO',1,1024,15,1,3,3,58,970),(429,'VLIRMAS2 - CONFIGURACION SERVIDORES DE OFICIN',1,512,50,1,3,3,16,473),(430,'VLIROMFP - IMPRESION LEXMARK MFP PARA SIP',2,1024,20,1,3,3,179,843),(431,'V3KHERMI - HERRAMIENTAS MICROINFORMATICAS',1,1024,271,1,2,3,107,851),(432,'VLIROPUP - Configuracion servidores virtuales',2,2048,22,1,5,3,50,897),(433,'VSQL2K5P.grupo.cm.es',2,3000,80,1,2,3,200,2488),(434,'V3KROPSH.grupo.cm.es',2,2048,40,1,2,3,251,896),(435,'V3KCVIRP.grupo.cm.es',1,2048,52,1,2,3,1198,1101),(436,'V3KOCWP1.grupo.cm.es',1,1024,65,1,2,3,299,572),(437,'V3KROGIS.grupo.cm.es',2,2048,62,1,2,3,222,820),(438,'V3KDMO01 - PREVENCION BLANQUEO DE CAPITALES',1,1024,16,1,2,3,186,557),(439,'VLIROPX2 - DNS ESCLAVO PILOTO SAURON',2,1024,30,1,3,3,195,929),(440,'V2KROBW2 - BANCWARE - APLICACIONES 2',1,2048,14,1,6,3,113,962),(441,'V3KSDCAS - SERVICE DESK DE CA',2,4096,93,1,2,3,708,2944),(442,'V3KCSM01.grupo.cm.es',1,4096,70,1,2,3,366,2427),(443,'V2KRODS1 - DATASTREAM',1,1024,10,1,2,3,133,572),(444,'V8KRO00U.grupo.cm.es',2,4096,70,1,6,3,276,2997),(445,'V3KHPQC1.grupo.cm.es',1,4096,128,1,2,3,332,2870),(446,'vlirosvn.cm.es',1,512,15,1,3,3,93,1727),(447,'V8KTIT02 - SERVICIOS TITAN EN OFICINAS',1,2048,28,1,2,3,170,1595),(448,'V3KBCKSH - BACKUP DE SHAREPOINT 2007',1,1024,16,1,2,3,225,564),(449,'V3KLEEVA - LABORATORIO EXCHANGE 2003 (ENTERPR',1,512,18,1,2,3,176,433),(450,'V3KSWIFT.grupo.cm.es',2,4096,82,1,2,3,287,1897),(451,'V8KVDIB2.grupo.cm.es',2,2048,40,1,2,3,147,1695),(452,'PCS11910 - SONDAS XP NOS',1,1024,10,1,1,3,75,500),(453,'V3KADVIS - ADVISOR PRODUCCION',1,768,43,1,2,3,173,540),(454,'V3KHYN21.grupo.cm.es',2,8192,63,1,2,3,561,5313),(455,'V3KSQLD2 - SQL SERVER DESARROLLO 2',2,4096,270,1,2,3,962,3515),(456,'V3KHYN22.grupo.cm.es',2,8192,63,1,2,3,216,4645),(457,'V8KTWS01.grupo.cm.es',2,2048,56,1,6,3,1410,1546),(458,'V3KTS002.Oficinas.grupo.cm.es',1,3072,62,1,2,3,161,1870),(459,'V3KCVI03.grupo.cm.es',2,2048,51,1,2,3,765,1167),(460,'V2KRO00L - VISUAL AGE',1,1024,45,1,6,3,161,854),(461,'V2KROGIS.grupo.cm.es',4,2048,60,1,6,3,4670,1878),(462,'',1,1024,150,2,3,3,93,1727),(463,'S2KROFTP - PELICAN FTP',2,2048,64,1,6,3,811,1200),(464,'vlinags1.cm.es',2,2048,8,1,3,3,93,1727),(465,'V3KCVI04.grupo.cm.es',2,2048,51,1,2,3,625,1136),(466,'V3KROLF1.grupo.cm.es',1,1024,16,1,2,3,317,665),(467,'V3KHFM02.grupo.cm.es',4,8192,80,1,2,3,486,6316),(468,'VLIRO008 - DINAMIS PRODUCCION',1,2048,15,1,3,3,71,1973),(469,'V3KSUSP3.grupo.cm.es',2,2048,48,1,2,3,463,1632),(470,'VLIROFIP - FAX SOBRE IP',1,1024,25,1,5,3,121,958),(471,'V8KSPGR1.grupo.cm.es',2,6144,39,1,2,3,253,3782),(472,'V8KMSTR1.grupo.cm.es',2,4096,56,1,6,3,269,2422),(473,'V3KNOS01 - APLICACIONES NOS DE DESARROLLO',1,1536,42,1,2,3,340,1298),(474,'V3KPMI03 - PROYECTO MULTIDIOMA PORTALES INTER',2,4096,612,1,2,3,833,1931),(475,'V3KROAS2.grupo.cm.es',2,2048,67,1,2,3,134,965),(476,'V3KMOSS3 - PILOTO OCS',1,1024,16,1,2,3,166,576),(477,'VLIRORW1 - PANELES CONTACT CENTER',1,2048,7,1,5,3,581,1865),(478,'V8KTIT12 - SERVICIOS TITAN EN SS.CC.',1,2048,28,1,2,3,171,1382),(479,'V8KCMO03.grupo.cm.es',2,4096,95,1,2,3,517,2753),(480,'V8KROVB1.grupo.cm.es',2,2048,44,1,2,3,226,1349),(481,'V8KAEC02.grupo.cm.es',2,2048,40,1,2,3,301,1619),(482,'VLIROBIT - DISTRIBUCION DE CAJEROS',2,2048,56,1,3,3,1904,1977),(483,'V3KCORP2.grupo.cm.es',4,8192,73,1,2,3,467,6492),(484,'V3KBIOS1.servicios.grupo.cm.es',4,2048,20,1,2,3,349,904),(485,'V3KHYP02.grupo.cm.es',4,8192,66,1,2,3,539,5774),(486,'V8KPRT01.grupo.cm.es',4,4096,106,1,2,3,939,2503),(487,'V3KEPOPT - CONSOLA EPO PARA PUESTOS DE TRABAJ',4,4000,41,1,2,3,442,2714),(488,'V8KPRT04.grupo.cm.es',4,4096,96,1,2,3,479,2666),(489,'V3KBIOS2.servicios.grupo.cm.es',4,2048,20,1,2,3,331,869),(490,'V3KGASP1.grupo.cm.es',4,4096,120,1,2,3,1516,2271),(491,'V8KWEBMS - SERVIDOR WEB MICROSTRATEGY',4,3072,66,1,2,3,411,2347),(492,'V8KOM006.grupo.cm.es',4,4096,60,1,2,3,367,2864),(493,'V8KROBW1.grupo.cm.es',4,4096,60,1,2,3,212,2626),(494,'V3KCITAP - SERVICIO CITA PREVIA',1,1024,8,1,2,3,155,455),(495,'S2KROTAR - RECOLTAR ENVIO REMESAS',1,1024,33,1,6,3,776,652),(496,'V3KGEDOC - GENERACION DOCUMENTOS CUADERNO DE ',2,2048,28,1,2,3,323,1345),(497,'vlirot05.cm.es',1,1024,8,1,3,3,93,1727),(498,'V3KCVIRT.grupo.cm.es',2,2048,35,1,2,3,811,1446),(499,'V3KCALRM.grupo.cm.es',1,1024,63,1,2,3,467,838),(500,'V3KBIOSD.',2,1024,16,1,2,3,140,657),(501,'VLIROSC3 - HOST ON DEMAND ROZAS 2',1,1024,30,1,3,3,106,966),(502,'VLIRODH1 - Agente dhcrelay produccion',1,512,4,2,3,3,0,0),(503,'V3KHYN31.grupo.cm.es',2,8192,63,1,2,3,624,5493),(504,'VLIGIS01 - SONDAS LINUX GIS',2,2048,24,1,3,3,706,1681),(505,'V2KENIGM - EMISOR CA PARA PROYECTO ENIGMA',1,512,12,1,6,3,127,336),(506,'VLIROT04  - GATEWAY DE TIVOLI PRODUCCION 4',1,1024,8,1,3,3,98,962),(507,'V2KROAB1.cm.es',1,4096,24,1,6,3,254,2659),(508,'PCS11908 - SONDAS XP GIS',1,1024,10,1,1,3,59,542),(509,'V3KCMPR2.grupo.cm.es',4,8192,116,1,2,3,221,5269),(510,'vlirot02.cm.es',1,1024,8,1,3,3,93,1727),(511,'V3KHYN32.grupo.cm.es',2,8192,63,1,2,3,196,4532),(512,'V3KROFTP.grupo.cm.es',1,1024,16,1,2,3,163,496),(513,'vlirot01.cm.es',1,1024,8,1,3,3,93,1727),(514,'V8KFRS02 - SERVIDOR DE CMFILEREPLICATION',2,4096,42,1,5,3,670,3271),(515,'V3KPLLOG.servicios.grupo.cm.es',1,1024,34,1,2,3,202,572),(516,'VLIROAC1 - RADIUS CISCO ACS 5.1',2,6144,250,1,3,3,145,4891),(517,'V3KINTEL - INTELLINX PARA ARANEA',2,1500,58,1,2,3,368,913),(518,'VLIROM01 - IMAGENES DE SERVIDORES DE OFICINA',1,4096,103,1,3,3,65,3169),(519,'VLIROB01 - BBDD ADMON. OFICINAS',1,512,49,1,5,3,35,476),(520,'VLIROSCP - HOST ON DEMAND LAS ROZAS',1,1024,30,1,3,3,132,1007),(521,'V3KDIN01.grupo.cm.es',2,4000,23,1,2,3,338,2576),(522,'VLIROSC4 - MASTER. NO BORRAR',1,1024,30,2,3,3,0,0),(523,'V8KHPOI2.grupo.cm.es',2,8192,195,1,2,3,1609,7297),(524,'VLIROA01 - PRUEBAS ACTUALIZACION SERVIDORES L',1,512,10,2,3,3,0,0),(525,'VLIRORP1 - PROXY DE RADIA 1',1,2048,22,2,3,3,0,0),(526,'V3KRKL01_CLON',1,1024,16,2,2,3,155,539),(527,'V3KROAS1 - GESTION GRAMATICAS CALL CENTER',2,2048,58,1,2,3,208,1081),(528,'V3KWEBCP - UTILIDAD WEB CUADERNO DE PROYECTOS',2,2048,28,1,2,3,296,1230),(529,'V8KSPI01.grupo.cm.es',1,4096,65,1,2,4,437,2896),(530,'V8KSPI02.grupo.cm.es',1,4096,65,1,2,4,319,2739),(531,'V8KVDIB1.grupo.cm.es',2,2048,40,1,2,4,205,1453),(532,'V8KEPM01.grupo.cm.es',2,4096,80,1,2,4,284,2920),(533,'V8KAUDIT.grupo.cm.es',4,6144,566,1,2,4,1333,5072),(534,'V8KSQLGG.grupo.cm.es',4,8192,140,1,2,4,1451,7398),(535,'V8KVCEN4.grupo.cm.es',2,4096,44,1,2,4,1507,3689),(536,'V8KRO00G.grupo.cm.es',2,2048,90,1,2,4,300,1351),(537,'V8KPOLAR - NEOPOLAR PRODUCCION',2,4096,45,2,2,4,0,0),(538,'V3KOM004.grupo.cm.es',4,4096,202,1,2,4,289,2104),(539,'V8KROTPC.grupo.cm.es',2,8192,112,1,2,4,296,3850),(540,'V8KSQLNP - SQL SERVER APLICACION NEOPOLAR',4,4096,40,2,2,4,0,0),(541,'V8KJVOFI.grupo.cm.es',2,4096,148,1,2,4,238,1627),(542,'V8KRDIBP.grupo.cm.es',4,8192,120,1,2,4,813,3835),(543,'V8KWSUP1.grupo.cm.es',2,2048,90,1,2,4,485,1518),(544,'V8KPAEAT.grupo.cm.es',1,8192,148,1,2,4,219,4278),(545,'V8KSPPP1.grupo.cm.es',4,8192,130,1,2,4,2540,5906),(546,'V8KMSIS1.grupo.cm.es',2,4096,60,1,2,4,2010,2878),(547,'V8KMSIS2.grupo.cm.es',2,4096,60,1,2,4,93,1727),(548,'V8KR2VC4.grupo.cm.es',2,2048,44,1,2,4,148,1114),(549,'V8KSAM05.grupo.cm.es',1,4096,100,1,2,4,168,2222),(550,'V8KSAM07.grupo.cm.es',2,4096,60,1,2,4,250,2508),(551,'@Plantilla_FINAL_W2KASSP4',1,512,4,3,6,4,0,0),(552,'@V8K64SP2',1,2048,40,3,2,4,0,0),(553,'@V8K64BR2 - MASTER W2008 R2 64 BI',1,1128,40,3,2,4,0,0),(554,'V8KOM005.grupo.cm.es',4,4096,55,1,2,4,506,2728),(555,'',1,4096,80,3,2,4,93,1727),(556,'V8KCASOI.grupo.cm.es',4,8192,50,1,2,4,2143,4874),(557,'V8KCABOP.grupo.cm.es',4,8192,90,1,2,4,805,4691),(558,'V8KROVB2.grupo.cm.es',2,2048,44,1,2,4,145,904),(559,'V8KGSSAN.grupo.cm.es',2,4096,46,1,2,4,535,2114),(560,'V8KROWE2.grupo.cm.es',2,3072,110,1,2,4,291,1944),(561,'V8KEMAIL.grupo.cm.es',2,6144,60,1,2,4,146,1166),(562,'SLIROWCS',2,4096,40,1,3,4,270,3099),(563,'V8KSAMT1.grupo.cm.es',4,6000,100,1,2,4,401,4223),(564,'V8KXRBSC.grupo.cm.es',2,2048,40,1,2,4,400,1490),(565,'V8KSAM01.grupo.cm.es',2,8192,150,1,2,4,426,6448),(566,'V8KAPCAP.grupo.cm.es',2,4096,70,1,2,4,259,1800),(567,'V8KCAP50.grupo.cm.es',2,4096,340,1,2,4,234,1754),(568,'V8KPRT07.grupo.cm.es',2,4096,56,1,2,4,398,2508),(569,'V8KSPBK3.grupo.cm.es',1,2048,70,1,2,4,353,1648),(570,'V8KVWOR2.grupo.cm.es',1,2048,40,1,2,4,175,1242),(571,'V8KSPBK5.grupo.cm.es',1,2048,70,1,2,4,466,1774),(572,'V8KCHAUD.grupo.cm.es',2,4096,190,1,2,4,348,2718),(573,'V8KALC01.grupo.cm.es',2,6144,100,1,2,4,698,4345),(574,'V8KEPOPT.grupo.cm.es',4,4096,50,1,2,4,1196,3047),(575,'V8KROSV2.grupo.cm.es',2,4096,46,1,2,4,498,2458),(576,'V8KMQ001.grupo.cm.es',1,2048,40,1,2,4,273,1553),(577,'V8KARISP.grupo.cm.es',2,4096,80,1,2,4,296,2345),(578,'V8KOBSQL.grupo.cm.es',4,8192,340,1,2,4,1264,6983),(579,'V8KOBIT1.grupo.cm.es',4,4096,70,1,2,4,551,1932),(580,'V8KSQLSG.grupo.cm.es',4,8192,1150,1,2,4,2596,7567),(581,'V8KROGW1.grupo.cm.es',1,2048,40,1,2,4,190,1137),(582,'V8KROPM1.grupo.cm.es',1,2048,40,1,2,4,287,1322),(583,'SRVDC2 - CONTROLADOR DE DOMINIO CAJA AVILA',1,1024,16,1,2,4,388,775),(584,'SRVDatosAV - SERVIDOR DE DATOS CAJA AVILA',2,3072,1757,1,2,4,617,2186),(585,'V8KRORTE.grupo.cm.es',2,2048,100,1,2,4,335,1357),(586,'@V8KMAS32',1,2048,40,3,2,4,0,0),(587,'V8KROVPS.grupo.cm.es',1,2048,40,1,2,4,35,791),(588,'VLIRORP2 - PROXY DE RADIA 2',2,2048,22,2,3,4,0,0),(589,'V8KWSUP2.grupo.cm.es',2,2048,75,1,2,4,484,1425),(590,'V8KWSUP6.grupo.cm.es',2,2048,65,1,2,4,240,1334),(591,'V8KROFPA.grupo.cm.es',2,2048,70,1,2,4,814,1274),(592,'V8KCAROI.grupo.cm.es',2,4096,40,1,2,4,107,1992),(593,'@V8KCASDP - SERVICE DESK MANAGER PRODUCCION',4,8192,80,3,2,4,0,0),(594,'vlicapem',2,4096,68,1,3,4,93,1727),(595,'vlicamem.cm.es',2,4096,26,1,3,4,93,1727),(596,'VLICAVED.cm.es',2,2048,22,1,3,4,179,621),(597,'VLIROMQ2 - SERVIDOR MQ SERIES PARA AMBAR',2,4096,62,1,3,4,186,3237),(598,'V8KVDIW2.grupo.cm.es',1,1128,40,1,2,4,227,859),(599,'V8KUPMGR.grupo.cm.es',1,1024,94,1,2,4,53,683),(600,'V8KOBIT2.grupo.cm.es',4,4096,70,1,2,4,470,2502),(601,'V8KSAMT2.grupo.cm.es',4,6000,100,1,2,4,791,4622),(602,'VLIROPRU',1,3072,121,1,3,4,40,2899),(603,'V8KMIR01.grupo.cm.es',2,4096,90,1,2,4,1617,3004),(604,'V8KSAM06.grupo.cm.es',2,4096,60,1,2,4,396,2465),(605,'V8KRO00L.grupo.cm.es',1,2048,47,1,2,4,279,1454),(606,'V8KSAM02.grupo.cm.es',2,4096,90,1,2,4,229,2589),(607,'VLIROTET - PROYECTO TETIS DE VALIDACION TARJE',1,3072,90,1,3,4,87,3062),(608,'V8KSAM03.grupo.cm.es',2,2048,60,1,2,4,216,1400),(609,'V8KSQLMR.grupo.cm.es',2,8192,1030,1,2,4,1119,7561),(610,'V8KSAM04.grupo.cm.es',2,4096,60,1,2,4,496,2640),(611,'V8KROGTO.grupo.cm.es',2,2048,40,1,2,4,321,1430),(612,'VLIDOCIB - Repositorio de conocimientos de In',1,1024,40,1,3,4,80,905),(613,'V8KVDIMT.grupo.cm.es',1,1024,55,1,2,4,89,796),(614,'V8KCCTR3.grupo.cm.es',2,4096,100,1,2,4,308,3017),(615,'V8KROSV0.grupo.cm.es',2,4096,46,1,2,4,311,2683),(616,'V8KPRT06.grupo.cm.es',2,4096,106,1,2,4,350,2608),(617,'V8KFTP01.grupo.cm.es',1,2048,90,1,2,4,222,1469),(618,'V8KVAJ01.grupo.cm.es',1,2048,40,1,2,4,212,1482),(619,'V8KMSUS1.grupo.cm.es',1,2048,40,1,2,4,198,1264),(620,'V8KVDIWI.grupo.cm.es',1,1128,40,1,2,4,67,801),(621,'VLISMSID - COLECTOR DE IDS',4,3072,90,1,3,4,6284,2933),(622,'V8KSQL02.grupo.cm.es',2,4096,340,1,2,4,684,3541),(623,'V8KRORFX.grupo.cm.es',2,2048,40,1,2,4,140,1394),(624,'V8KSPBK7.grupo.cm.es',2,4096,60,1,2,4,55,551),(625,'V3KGSSAN - HERRAMIENTAS DE GESTION DE LA SAN',2,4096,119,1,2,4,976,2388),(626,'@V8K32BIT',2,2048,56,3,2,4,0,0),(627,'V8KPKI05.grupo.cm.es',2,2048,55,1,2,4,249,1122),(628,'VLIROPAN - SERVIDOR PANORAMA',2,2048,34,1,3,4,1559,1974),(629,'V8KCASDP.grupo.cm.es',4,8192,80,1,2,4,1027,5903),(630,'V8KCABSI.grupo.cm.es',2,4096,40,1,2,4,260,2492),(631,'V8KCAPIT.grupo.cm.es',1,4096,80,1,2,4,403,2579),(632,'V8KOM007.grupo.cm.es',2,3072,40,1,2,4,59,1452),(633,'',1,512,12,3,3,4,93,1727),(634,'V2KDMDS3 - BACKUP CONTENT DOCUMENTUM',2,1024,39,1,6,5,0,0),(635,'V3KRASM1.grupo.cm.es',2,2048,82,1,2,5,0,0),(636,'V3KALLOT.grupo.cm.es',1,3072,112,1,2,5,0,0),(637,'V3KCVI05.grupo.cm.es',2,2048,51,1,2,5,0,0),(638,'V3KCONF1.grupo.cm.es',1,1024,32,1,2,5,0,0),(639,'V3KSHPR3.grupo.cm.es',1,1024,20,1,2,5,0,0),(640,'vlirork2.cm.es',1,1024,10,1,3,5,93,1727),(641,'V3KSHPR1.grupo.cm.es',1,1024,20,1,2,5,0,0),(642,'V8KNTFRS.grupo.cm.es',1,2048,40,1,2,5,0,0),(643,'vlirora2.cm.es',1,1024,10,1,3,5,93,1727),(644,'V8KNWK02.grupo.cm.es',2,4096,56,1,6,5,0,0),(645,'V3KADAMW - SERVIDOR WEB PARA ADAM',2,2048,20,1,2,5,0,0),(646,'V8KPRT03.grupo.cm.es',2,4096,106,1,2,5,0,0),(647,'V3KSMSAM - SALA DE MERCADOS SAM',1,1048,30,1,2,5,0,0),(648,'S2KGWFTP.grupo.cm.es',1,1024,34,1,6,5,0,0),(649,'VLIGTSR2 - SERVIDOR CMGETSRV',2,1024,20,1,3,5,0,0),(650,'vlirork1.cm.es',2,2048,52,1,3,5,93,1727),(651,'V3KROOC3 - FRONTAL ONECLICK',1,2048,72,1,2,5,0,0),(652,'V3KVPSX1.grupo.cm.es',2,2048,52,1,2,5,0,0),(653,'VLIROBCX - VALIDACION XML PARA BLUECOAT',1,4096,80,1,3,5,0,0),(654,'V8KNWK01.grupo.cm.es',2,4096,56,1,6,5,0,0),(655,'VLIREPRH- REPOSITORIO RHEL 5',1,512,312,1,3,5,0,0),(656,'V8KROTMP - SERVICIO DISCO DE INTERCAMBIO',2,3072,69,1,2,5,0,0),(657,'V3KSCS01.Oficinas.grupo.cm.es',1,4000,84,1,2,5,0,0),(658,'V3KSMP04.grupo.cm.es',2,4096,92,1,2,5,0,0),(659,'V8KOM002 - SONDAS DEL SCOM',2,2048,32,1,5,5,0,0),(660,'V2KROSQL.grupo.cm.es',4,4096,362,1,6,5,1561,1401),(661,'V3KROVI2.grupo.cm.es',1,1024,52,1,2,5,0,0),(662,'VLIROGIP - GESTION DNS Y DHCP',1,4096,96,1,3,5,0,0),(663,'V8KCCTR2.grupo.cm.es',2,4096,140,1,2,5,0,0),(664,'V3KLCMS1 - SERVIDOR PARA AULA VIRTUAL',2,4000,410,1,2,5,0,0),(665,'SOAO0760 - SERVIDOR EPI 1',2,1024,65,1,3,5,0,0),(666,'SOAI0693 - DISTRIBUCION NOS EN SSCC',2,1024,70,1,3,5,673,999),(667,'V3KROGIP.grupo.cm.es',1,1024,20,1,2,5,193,437),(668,'SOAC0693 - DISTRIBUCION NOS EN SSCC',2,1024,75,1,3,5,661,998),(669,'V3KGISDS - GUIA DE INTERACCION MULTICANAL',1,1024,32,1,2,5,253,665),(670,'V3KMET01.grupo.cm.es',1,2048,122,1,2,5,393,1526),(671,'V3KROVI1.grupo.cm.es',1,1024,72,1,2,5,212,429),(672,'V3KAFMW1.grupo.cm.es',1,1024,37,1,2,5,240,519),(673,'V8KTITAN.grupo.cm.es',1,2048,22,1,2,5,90,1127),(674,'V3KADVIP - ADVISOR PRUEBAS',1,768,43,1,2,5,191,412),(675,'V8KSPOF1 - SECURPASS SERVER DOMINIO OFICINAS',2,6144,62,1,2,5,338,3260),(676,'V3KNBA01.grupo.cm.es',1,1024,20,1,2,5,225,555),(677,'SOAE0693 - DISTRIBUCION NOS EN SSCC',2,1024,75,1,3,5,654,998),(678,'V3KPPSD1 - PROJECT PORTFOLIO SERVICE DESARROL',1,4096,21,1,2,5,212,1309),(679,'V8KROBC1.grupo.cm.es',4,4096,48,1,2,5,1054,2072),(680,'V8KINVEN.grupo.cm.es',2,4096,236,1,2,5,455,3073),(681,'SOAE0760 - SERVIDOR MASTER EPI OLD',2,1024,200,1,3,5,16,80),(682,'vlirork3.cm.es',1,1024,10,1,3,5,93,1727),(683,'V3KPPST1 - PROJECT PORTFOLIO SERVICE TRANSITO',1,4096,21,1,2,5,210,1330),(684,'SOAD0693 - DISTRIBUCION NOS EN SSCC',2,1024,75,1,3,5,662,999),(685,'SOAH0693 - DISTRIBUCION NOS EN SSCC',2,1024,70,1,3,5,659,999),(686,'V8KAEC01.grupo.cm.es',2,2048,40,1,2,5,647,1803),(687,'V8KEPO45.grupo.cm.es',4,4096,40,1,2,5,809,2377),(688,'V8KNWK03.grupo.cm.es',4,4096,56,1,2,5,890,2614),(689,'V3KIMPRE - PETICIONES DE IMPRESION',2,2048,31,1,2,5,507,1319),(690,'SOAR0760 - SERVIDOR EPD',2,1024,75,1,3,5,650,1005),(691,'V3KHYN02.grupo.cm.es',2,8192,62,1,2,5,890,4364),(692,'VLIRORM1 - SERVIDOR MANAGER RADIA',2,4096,56,2,3,5,0,0),(693,'SOAG0693 - DISTRIBUCION NOS EN SSCC',2,1024,70,1,3,5,710,1004),(694,'SOAB0693 - DISTRIBUCION NOS EN SSCC',2,1024,75,1,3,5,719,1004),(695,'VLIROAP9 - APPLIANCE 802.1X',2,2048,25,1,3,5,53,468),(696,'VLIGTSR3 - SERVIDOR PTDEPLOY',2,1024,20,1,3,5,179,956),(697,'V3KDIN02 - UPDATE PILOTO DYNASIGHT',1,4000,23,1,2,5,236,2106),(698,'V3KHTML1.grupo.cm.es',2,2048,12,1,2,5,309,688),(699,'V3KWALST.grupo.cm.es',1,2048,32,1,2,5,217,945),(700,'V8KR2MS9.grupo.cm.es',2,4096,50,1,2,5,780,2536),(701,'s2krogip.',4,4096,53,1,6,5,93,1727),(702,'V8KFRS01.grupo.cm.es',2,4096,54,1,2,5,477,2288),(703,'V3KHYN01.grupo.cm.es',2,8192,62,1,2,5,863,4238),(704,'VLIROAP8 - APPLIANCE 802.1X',2,2048,25,1,3,5,98,1332),(705,'V8KSRV01 - SERVIDOR DE PETICIONES HOST',1,4000,62,1,2,5,306,2261),(706,'V8KROSM1.grupo.cm.es',2,2048,200,1,2,5,425,1494),(707,'V8KSEGIN.grupo.cm.es',1,1128,42,1,2,5,151,829),(708,'V8KPKI03.grupo.cm.es',2,2048,65,1,2,5,313,1254),(709,'V3KAYASS - KAYAKO SUPPORT',1,2048,62,1,2,5,349,1457),(710,'V2KNTFRS - SERVIDOR DE FICHEROS CMNTFRS',1,1024,8,1,6,5,36,233),(711,'V3KSHPR4.grupo.cm.es',1,1024,20,1,2,5,684,693),(712,'V3KEPO40 - CONSOLA ANTIVIRUS EPO 4.0',2,3072,27,1,2,5,393,2025),(713,'V3KARISP - ARIS PLATFORM DE ARQUITECTURA',1,2048,22,1,2,5,216,892),(714,'V3KGIUNT - ENTORNO DE PRUEBAS GIUNTI',2,4000,52,1,2,5,206,1865),(715,'V3KSAM01 - RESPALDO SALA MERCADOS SAM',1,1048,30,1,2,5,115,392),(716,'V8KROAR3.grupo.cm.es',2,2048,60,1,2,5,427,1711),(717,'V8KSHSQL - SQL 2005 PARA SHAREPOINT',1,2048,146,1,5,5,386,1889),(718,'VLIGTSR1 - PRODNEWS BLOG',2,1024,70,1,3,5,278,728),(719,'V8KNWLAB.grupo.cm.local',2,2048,81,1,6,5,835,1841),(720,'SOAN0760 - SERVIDOR EPD',2,1024,65,1,3,5,723,1010),(721,'VLIROFI1 - FAX SOBRE IP SIP',4,1024,50,1,3,5,408,844),(722,'V8KPKI04.grupo.cm.es',2,2048,80,1,2,5,293,1126),(723,'VLIROFTP - SERVIDOR FTP PARA IMPRESORAS MULTI',1,384,70,1,3,5,28,373),(724,'V8KROBW2.grupo.cm.es',4,4096,60,1,2,5,263,2089),(725,'@V3KCADTP - CONEXION ADT SERVICE DESK PRODUCC',1,4096,51,3,2,5,0,0),(726,'SOAE0760 - SERVIDOR MASTER EPI',2,2048,130,2,3,5,16,80),(727,'V2KPRUEBA - NO TOCAR',1,1024,8,2,6,5,0,0),(728,'SOAD0692 - SERVIDOR PRUEBAS DE DISTRIBUCION',1,1024,60,1,3,5,374,987),(729,'SOAJ0693 - DISTRIBUCION NOS EN SSCC',2,1024,70,1,3,5,500,995),(730,'@LIRORA1 - NO TOCAR',2,2048,53,3,3,5,0,0),(731,'V3KTRPM2.grupo.cm.es',4,5120,32,1,2,5,870,2935),(732,'PCS117XX - MASTER DE PRUEBAS PARA XP 2',2,1016,37,2,1,5,0,0),(733,'V3KCASAM.grupo.cm.es',1,1024,20,1,2,5,185,569),(734,'V3KSHPR2.grupo.cm.es',2,2048,20,1,2,5,548,1637),(735,'V8KOM001.grupo.cm.es',2,4096,85,1,2,5,355,3382),(736,'V3KGECA1 - GESTION CAPACIDAD ITIL',1,1024,32,1,2,5,164,433),(737,'V8KPRT05.grupo.cm.es',2,4096,106,1,2,5,354,2400),(738,'V8KTWS02.grupo.cm.es',2,2048,56,1,6,5,312,1288),(739,'V8KSPPP2.grupo.cm.es',4,8192,130,1,2,5,789,5900),(740,'V8KSQL01 - SERVIDOR SQL SERVER PARA DESARROLL',2,4096,340,1,5,5,1089,3621),(741,'V8KTIT01 - SERVICIOS TITAN EN OFICINAS',1,2048,28,1,2,5,172,1287),(742,'V3KVSSF5.grupo.cm.es',2,2048,20,1,2,5,265,1171),(743,'V8KFOG01 - FOGLIGHT PARA BB.DD.',2,4096,195,1,5,5,472,3608),(744,'V8KRO00J - MICROSTRATEGY- METADATA',2,2048,136,1,6,5,511,1752),(745,'V8KROSIL - SISTEMA DE INFORMACION LOCAL',1,2048,42,1,2,5,206,1486),(746,'V8KRO00H.grupo.cm.es',2,2048,70,1,2,5,226,1410),(747,'vlirora3.cm.es',1,1024,10,1,3,5,93,1727),(748,'VLIRODSO - DISTRIBUCION EMERGENCIA OFICINAS',2,4096,30,1,3,5,406,3663),(749,'SOAF0693 - DISTRIBUCION NOS EN SSCC',2,1024,70,1,3,5,507,999),(750,'SOAA0693 - DISTRIBUCION NOS EN SSCC',2,1024,70,1,3,5,518,997),(751,'V8KVWOR1.grupo.cm.es',1,2048,40,1,2,5,247,1421),(752,'@V3KWALST - COPIA WALL STREET. NO TOCAR',1,2048,32,3,2,5,0,0),(753,'V3KHYN03.grupo.cm.es',2,8192,62,1,2,5,828,6067),(754,'vlirora1.cm.es',2,2048,53,1,3,5,93,1727),(755,'SOAY0692 - SERVIDOR PRUEBAS DE DISTRIBUCION',1,512,30,1,3,5,318,507),(756,'V3KSUS30 - SERVIDOR PARA WINDOWS UPDATE',2,2048,52,1,2,5,371,1394),(757,'SOAQ0760 - SERVIDOR EPD',2,1024,75,1,3,5,500,1004),(758,'V8KSPBK1.grupo.cm.es',1,4096,70,1,2,5,330,2901),(759,'VLIROREP - REPOSITORIO FICHEROS ENTORNO SIP',2,1024,20,1,3,5,40,800),(760,'SOAP0760 - SERVIDOR EPI 1',2,1024,65,1,3,5,512,998),(761,'VLIROFI2 - FAX SOBRE IP SIP',4,2048,35,1,5,5,540,1724),(762,'VLIROMIG - SEGUIMIENTO MIGRACION BANCAJA',1,2048,20,1,3,5,30,1757),(763,'VLIRORP3 - PROXY DE RADIA 3',1,2048,22,2,3,5,0,0),(764,'V8KWSUP3.grupo.cm.es',2,2048,75,1,2,5,686,1619),(765,'V3KCADTP.grupo.cm.es',1,4096,51,1,2,5,202,2124),(766,'V8KROVB3.grupo.cm.es',2,2048,49,1,2,5,129,1179),(767,'V3KCORP1 - HYPERION CORPORACION DESARROLLO_re',2,4096,54,2,2,6,514,2443),(768,'VLISHAC2 - RADIUS CISCO BACKUP ACS 5.1_replic',2,6144,500,3,3,6,0,0),(769,'V3KSHFBK - FAX CORPORATIVO BACKUP_replica_4.1',2,2048,22,2,2,6,0,0),(770,'V8KPRT06 - SPOOL DE IMPRESION SIP_replica',2,4096,106,3,2,6,350,2608),(771,'V8KPRT07 - SPOOL DE IMPRESION DE LA TORRE II_',2,4096,56,3,2,6,398,2508),(772,'V8KSQLGG - SQL SERVER 2005 PARA GASPER Y GIS_',4,8192,140,3,2,6,1451,7398),(773,'V3KCSM01 - SERVIDOR CISCO CSM_replica',1,4096,70,3,2,6,366,2427),(774,'V3KCVI02 - CARTELERIA VIRTUAL DENEVA_replica',2,2048,61,3,2,6,757,1341),(775,'V3KCVIRT - CARTELERIA VIRTUAL DENEVA_replica',2,2048,35,3,2,6,811,1446),(776,'V3KGASP1 - SERVIDOR GASPER W2K3_replica',4,4096,120,3,2,6,1516,2271),(777,'VLIROMTX - MONITORES DE RENDIMIENTO_replica',2,2048,50,3,3,6,1022,2032),(778,'VLIROSC3 - HOST ON DEMAND ROZAS 2_replica',1,1024,30,3,3,6,106,966),(779,'V3KCVI01 - CARTELERIA VIRTUAL DENEVA_replica',1,2048,51,3,2,6,456,1516),(780,'V8KRORDR.grupo.cm.es',4,4096,40,1,2,6,448,943),(781,'V8KVDIB1 - BROKER VWORKSPACE PARA VDI_replica',2,2048,40,3,2,6,205,1453),(782,'V8KPRT03 - SPOOL DE IMPRESION CELENQUE_replic',2,4096,106,3,2,6,0,0),(783,'V8KPRT05 - SPOOL DE IMPRESION NUEVA TORRE_rep',2,4096,106,3,2,6,354,2400),(784,'V8KSPOF1 - SECURPASS SERVER DOMINIO OFICINAS_',2,6144,62,3,2,6,338,3260),(785,'VLIRORA1 - MANAGER DE RADIA_replica',2,2048,53,3,3,6,356,1876),(786,'VLIRORA2 - PROXY RADIA 1_replica',1,1024,10,3,3,6,0,0),(787,'VLIRORA3 - PROXY RADIA 2_replica',1,1024,10,3,3,6,545,969),(788,'V8KPRT01 - SPOOL IMPRESION LA TORRE_replica',4,4096,106,3,2,6,939,2503),(789,'VNTRO00G - EUROGES PRODUCCION_replica',1,512,41,3,6,6,217,433),(790,'V3KEPO40 - CONSOLA ANTIVIRUS EPO 4.0_replica',2,3072,27,3,2,6,393,2025),(791,'VLIROMR1 - MONITORES RENDIMIENTO Z%2fOS_repli',2,1024,20,3,3,6,436,1002),(792,'V3KSUS30 - SERVIDOR PARA WINDOWS UPDATE_repli',2,2048,52,3,2,6,371,1394),(793,'V8KPRT04 - SPOOL DE IMPRESION DIRECCION_repli',4,4096,96,3,2,6,479,2666),(794,'VLIROSC1 - HOST ON DEMAND ROZAS 1_replica',1,1024,30,3,5,6,80,929),(795,'V8KEPO45 - PILOTO CONSOLA EPO MCAFEE_replica',4,4096,40,3,2,6,809,2377),(796,'V8KROWEB - SERVIDOR WEB MIGRACION APLICACIONE',2,3072,105,3,5,6,0,0),(797,'V8KSPGR1 - SECURPASS SERVER DOMINIO GRUPO_rep',2,6144,39,3,2,6,253,3782),(798,'V8KTWS01 - TRACKER DE OPC PARA SQL SERVER_rep',2,2048,56,3,6,6,1410,1546),(799,'V8KTWS02 - TRACKER DE OPC PARA SQL SERVER_rep',2,2048,56,3,6,6,312,1288),(800,'VLIROGIP - GESTION DNS Y DHCP_replica',1,4096,96,3,3,6,0,0),(801,'V8KBKSQL - SERVIDOR PARA BACKUPS DE SQL SERVE',1,1024,140,1,2,6,25,797),(802,'V8KROBC1 - VALIDACION USUARIOS PROXY_replica_',4,4096,48,2,2,6,1054,2072),(803,'V8KROVBR.grupo.cm.es',2,2048,44,1,2,6,20,664),(804,'V8KSPOF2 - SECURPASS SERVER DOMINIO OFICINAS_',2,6144,62,2,2,6,264,2146),(805,'V8KSPGR1 - SECURPASS SERVER DOMINIO GRUPO_rep',2,6144,39,3,2,6,253,3782),(806,'V8KSPGR2 - SECURPASS SERVER DOMINIO GRUPO_rep',2,6144,39,3,2,6,265,2164),(807,'V8KROVBC - Veeam Backup and Replication V6',2,4096,44,1,2,6,209,2285),(808,'V3KSWDI1 - RECURSOS DE DISTRIBUCION SOFTWARE_',4,4096,116,3,2,6,412,3172),(809,'S2KROTAR - RECOLTAR ENVIO REMESAS_replica',1,1024,33,3,6,6,776,652),(810,'V3KBIOS1 - VOCALPASSWORD PRODUCCION 1_replica',4,2048,20,3,2,6,349,904),(811,'V3KCORP2 - HYPERION CORPORACION PRODUCCION_re',4,8192,73,3,2,6,467,6492),(812,'V3KBIOS2 - VOCALPASSWORD PRODUCCION 2_replica',4,2048,20,3,2,6,331,869),(813,'SEXROSE2 - FAX CORPORATIVO PRODUCCION_replica',2,2048,22,3,2,6,0,0),(814,'VLIRORW1 - PANELES CONTACT CENTER_replica',1,2048,7,3,5,6,581,1865),(815,'V3KBIOSF - VOCALPASSWORD FILE SYSTEM_replica',1,1024,60,3,2,6,172,816),(816,'V3KBKADM - ADM. CONNECTED Y RECOVERY MANAGER_',1,768,70,3,2,6,190,444),(817,'V3KCPC01 - MOTOR REGLAS SERVICE DESK_replica',1,1024,28,3,2,6,0,0),(818,'V3KHFM02 - HYPERION CIBELES PRODUCCION_replic',4,8192,80,3,2,6,486,6316),(819,'VLIROAC1 - RADIUS CISCO ACS 5.1_replica',2,6144,250,3,3,6,145,4891),(820,'V3KHYP02 - HYPERION CAJA ENTORNO PRODUCCION_r',4,8192,66,3,2,6,539,5774),(821,'V3KBIOSD - VOCALPASSWORD DESARROLLO_replica',2,1024,16,3,2,6,140,657),(822,'V8KENSQL - SQL Server 2008 R2 Equipo Servidor',2,2048,94,3,2,6,0,0),(823,'V3KINVSR - GESTION CONFIGURACION INVENTARIO_r',1,2048,25,3,2,6,224,1150),(824,'V3KTWS01 - SERVICIOS DE TRACKER PARA MAQUINAS',2,2048,20,3,2,6,234,884),(825,'P0966 - PUESTO CAJA AVILA_replica',2,2000,44,3,1,6,63,566),(826,'P1142  - PUESTO CAJA AVILA_replica',1,1024,25,3,1,6,231,761),(827,'VDI-DIRECCION  - PUESTO CAJA AVILA_replica',1,1024,30,3,1,6,46,727),(828,'V8KRDIBT - Pruebas Revista Digital Interna Ba',2,4096,115,1,2,8,0,0),(829,'V3KLCMSR.grupo.cm.es',4,4096,420,1,2,8,0,0),(830,'VLIRODH1 - Agente dhcrelay produccion (1)',1,512,4,2,5,8,0,0),(831,'V8KDEP01.grupo.cm.es',4,4096,350,1,2,8,0,0),(832,'PCS80019.grupo.cm.es',2,2048,40,1,1,8,94,2048),(833,'VLIPSCOM - Pruebas agente SCOM sobre Linux',1,512,10,1,3,7,28,505),(834,'PCSXLXP2 - EX2007 PRUEBAS CLIENTE XP',1,512,10,1,1,7,54,259),(835,'PCS11797 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(836,'V8KROTF3 - TEAM FOUNDATION SERVER DESARROLLO',4,4096,48,1,2,7,1623,3383),(837,'V8KSWARE - PILOTO CENTRAL ALARMAS SECUWARE',4,4024,256,1,2,7,891,2671),(838,'VLIIMPRE - PETICIONES DE IMPRESION',2,4096,16,1,3,7,267,403),(839,'V3KCASP1 - CA SPECTRUM AUTOMATION MANAGER',2,4096,52,1,2,7,675,2518),(840,'PCSXLXP1 - EX2007 PRUEBAS CLIENTE XP',1,512,10,1,1,7,56,310),(841,'V8KCA005 - Bankia Service Desk',2,6144,95,1,2,7,561,4851),(842,'V8KVCLIC - vCenter4 pruebas',1,1128,84,1,2,7,341,983),(843,'PCS11970 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(844,'V8KWALLP - PILOTO WALL STREET OFFICE 11.1',1,4096,65,1,2,7,74,2605),(845,'vliturbo',2,8192,16,1,3,7,93,1727),(846,'PCS11802 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(847,'V8KROEGO - REGISTRO OFICIAL DE ENTRADA',1,2048,40,1,2,7,142,1387),(848,'PCS11763 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(849,'PCS80235.grupo.cm.es',2,2048,40,1,1,7,755,1406),(850,'PCS11793 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(851,'V8KROEVP - GESTION DE ENTREGAS VALIDACION Y P',2,4096,70,1,2,7,53,1305),(852,'V8XLGCAS - EX2007 PRUEBAS EXCHANGE CAS',2,4096,40,1,2,7,87,2279),(853,'V8KR2PRF - TEMPLATE W2K8 OPTIMIZADA PERFORMAN',1,1024,44,2,2,7,0,0),(854,'PCS11882 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,279,1349),(855,'V8KO12L2 - PILOTO SCOM 2012',1,4096,80,1,2,7,251,3177),(856,'V8KPRDCM',4,4096,40,2,2,7,0,0),(857,'vliprumet',1,1024,6,1,3,7,93,1727),(858,'PCS80231.grupo.cm.es',2,2048,40,1,1,7,1482,1334),(859,'PCS80233 - PRUEBAS LIQUID',2,2048,40,2,1,7,278,991),(860,'PCS80232.grupo.cm.es',2,2048,40,1,1,7,1475,1434),(861,'PCS80234.grupo.cm.es',2,2048,40,1,1,7,1358,1596),(862,'V8KSPDA2.grupo.cm.es',1,2048,70,1,2,7,120,1426),(863,'V8KROSI1 - PILOTO GESTION DE CERTIFICADOS SEG',2,1128,40,1,2,7,264,981),(864,'V8KROAF1 - PILOTO ANALISIS FORENSES PARA SEG.',2,1024,40,1,2,7,376,812),(865,'VLIRAK03 - Proxy 2 de Radia Pruebas 7.8',1,2048,10,1,3,7,153,370),(866,'V8KMVD01 - SERVIDOR PILOTO PARA APLICACIONES ',2,4096,46,1,2,7,251,2196),(867,'PCS11799 - PRUEBAS XP LABORATORIO',2,2048,50,1,1,7,515,1359),(868,'PCS11805 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(869,'VLIROPRU2',1,3072,121,1,3,7,40,2899),(870,'VLIROSC2 - GESTION RESTO LINUX',1,1024,14,1,3,7,182,353),(871,'V8KADCER - Servidor AD Cert Services',1,1024,40,1,2,7,36,638),(872,'VLIRAK02 - Proxy 1 de Radia Pruebas 7.8',1,2048,10,1,3,7,143,412),(873,'VLIDOCPR - Repositorio de conocimientos de In',1,1024,40,1,3,7,175,687),(874,'VLIAPINT - PILOTO INTERFACE COMUNICACIONES',1,1024,20,1,3,7,26,656),(875,'VLIPRMQ1 - Servidor de pruebas clientes MQ Se',2,2048,15,1,3,7,270,1978),(876,'VLIDEBSC - Maquinas prueba agente SCOM sobre ',1,700,10,1,3,7,24,668),(877,'PCS11931 - APLICACION ISIS',1,1024,42,1,1,7,256,726),(878,'PCS11835 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(879,'PCS11920 - PCS EQUIPO PROCESO',2,2048,40,1,1,7,511,1653),(880,'PCS11784 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(881,'PCS11841 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(882,'PCS11843 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(883,'PCS11971 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(884,'@PCS00000 - W7 SP1 40 GB',1,1024,24,3,1,7,0,0),(885,'V8KOCF1P - FRONTAL 1 OCS SERVER R2',2,2048,65,1,2,7,669,1725),(886,'V3KHFM01 - HYPERION CIBELES DESARROLLO',2,4096,38,1,2,7,549,2401),(887,'PCS11893 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(888,'V3KCPEXT - SERVIDOR WEB CUADERNO DE PROYECTOS',1,2048,28,1,2,7,136,1190),(889,'V8KPACOM - PILOTO CENTRAL ALARMAS PACOM',4,4096,40,1,2,7,1426,2002),(890,'PCS11890 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(891,'VLIROTST- RHEL 5.2 Testing',1,1024,14,1,3,7,183,575),(892,'V8KSPD03 - FRONTAL SHAREPOINT 2010 DESARROLLO',1,2048,40,1,2,7,35,813),(893,'V8KGENOC - GESTION DE NOMINAS DE CONSEJEROS',2,2048,56,1,2,7,150,1726),(894,'V8XLGPF1 - EX2007 PRUEBAS EXCHANGE PUBLIC FOL',2,1128,42,1,2,7,178,982),(895,'PCS11782 - PRUEBAS XP LABORATORIO',2,2048,30,2,1,7,0,0),(896,'PCS11842 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(897,'@PCS##### - W7 50Gb',2,4096,50,3,1,7,0,0),(898,'PCS10666 - PRUEBAS USUARIOS',2,1024,30,2,1,7,0,0),(899,'PCS11806 - PRUEBAS XP LABORATORIO',2,2048,30,2,1,7,0,0),(900,'VLIROPAE - Pruebas Dpto. de Operacion',2,2048,60,1,3,7,308,1848),(901,'PCS11822 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(902,'V8XLODC1 - PRUEBAS DC LABORATORIO',1,1024,20,2,2,7,0,0),(903,'@MASTER_W8K de 64 bits_Parches hasta 1-marzo-',2,1128,40,3,2,7,0,0),(904,'VLICURUN - Maquina docencia curso UNIX%2fLINU',1,256,8,2,3,7,0,0),(905,'@PCS11905 - MASTER VDI XP. NO ARRANCAR',2,1024,30,3,1,7,0,0),(906,'PCS11781 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(907,'V8KVDIT2 - Pruebas VDI Distribuido',1,1024,44,2,2,7,0,0),(908,'VLIPRMAR - Prueba ftp Herramientas Microinfor',1,512,4,1,3,7,172,197),(909,'PCS11808 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(910,'V8KROTF1 - TEAM FOUNDATION SERVER DESARROLLO',4,4096,110,1,2,7,451,2591),(911,'VLINAGP1 - Servidor de pruebas de monitorizac',2,2048,8,2,3,7,0,0),(912,'VLICPMOD - VK_Modeler_1.2_Release_SE',1,2048,5,2,3,7,0,0),(913,'VLIPRMQ2  - Servidor de pruebas clientes MQ S',2,2048,15,1,3,7,262,578),(914,'VLICARST - SpAM RSI (Racemi)',1,1024,20,2,3,7,0,0),(915,'VLINAGP2 - Servidor de pruebas de monitorizac',2,2048,8,2,3,7,0,0),(916,'PCS11800 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(917,'SOAT##### - Maquina imagen',1,2048,50,2,3,7,0,0),(918,'PCS11900 - LABORATORIO EXCHANGE 2003 (WXP1)',1,256,6,2,1,7,0,0),(919,'',1,2048,52,1,2,7,93,1727),(920,'PCS11788 - PRUEBAS XP LABORATORIO',2,2048,30,2,1,7,0,0),(921,'VLICANFS - NFS y SAMBA para SPAM RSI',1,1024,55,2,3,7,0,0),(922,'PCS11875 - PC Virtual Microsoft',1,1024,50,2,1,7,0,0),(923,'VLITSTMD - Pruebas Sistemas Medios',1,1024,112,1,3,7,430,831),(924,'PCS11789 - PRUEBAS XP LABORATORIO',2,2048,30,2,1,7,0,0),(925,'@V8KSPR01 - COPIA TEMPORAL. NO TOCAR',2,8192,80,3,2,7,0,0),(926,'V8KCAITP - SERVIDOR ITPAM PARA SERVICE DESK',1,4096,80,1,2,7,348,2652),(927,'V8KRAP32 - CHEQUEO DIRECTORIO ACTIVO',2,2048,50,1,2,7,317,1575),(928,'VLISHFIP - FAX SOBRE IP PRUEBAS',1,1024,50,1,3,7,218,879),(929,'V3KSPST4.grupo.cm.es',1,2048,65,1,2,7,278,1369),(930,'PCS11894 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(931,'@V8KSQLR1 - COPIA TEMPORAL. NO TOCAR',2,8192,130,3,2,7,0,0),(932,'VLIPRFT1 - Prueba file transfer centralizado',2,2048,50,1,3,7,433,1895),(933,'VSLTSTED - Pruebas Solaris 10',2,2048,40,2,4,7,0,0),(934,'V3KVEEAM - Pruebas Veeam Reporter',2,2048,54,2,2,7,0,0),(935,'V8KSPDA1.grupo.cm.es',1,2048,52,1,2,7,273,1614),(936,'V8KSAMT3 - CA SPECTRUM AUTOMATION MANAGER',1,2048,70,1,2,7,1226,1821),(937,'PCS11858 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(938,'PCS11840 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(939,'PCS11885 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(940,'PCS11886  - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(941,'V3KDTS01 - SEGUNDO NODO DE INDEXACION PREPRO',4,4000,30,1,2,7,654,2229),(942,'PCS11803 - PRUEBAS XP LABORATORIO',2,2048,30,2,1,7,0,0),(943,'V8KOCSQP - WEB ACCESS PARA OCS SERVER R2',4,4096,80,1,2,7,376,2233),(944,'@MasterW2003-SP2paraClonar-Parches hasta 2 ab',1,1024,20,3,2,7,0,0),(945,'PCS11810 - PRUEBAS XP LABORATORIO',2,2048,30,2,1,7,0,0),(946,'V3KBKPC2 - BACKUP CONNECTED DE PRUEBAS. NO TO',1,2048,105,2,2,7,0,0),(947,'VLIPRVMT - PRUEBAS VM-TOOLS DEBIAN',1,3072,90,2,3,7,0,0),(948,'V3KCORP1 - HYPERION CORPORACION DESARROLLO',2,4096,54,1,2,7,514,2443),(949,'PCSPRUBC - Migraci+w7M-n de Aulas d',1,768,15,2,1,7,0,0),(950,'PCS11930 - APLICACION ISIS',2,2048,50,1,1,7,397,793),(951,'PCS11867 - APLICACION ISIS',1,1024,25,1,1,7,215,479),(952,'V3KROFPL - FAX PRUEBAS DE LOOPBACK',1,1024,28,1,2,7,134,491),(953,'PCS11934 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(954,'PCS80201 - PRU HOD',2,2048,40,1,1,7,445,1598),(955,'V8KCMEB5 - VANTAGE ANALIZER DESARROLLO',2,2048,44,1,2,7,123,915),(956,'PCS11813 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(957,'PCS11807 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(958,'PCS11975 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(959,'V8KWR264',1,1128,40,2,5,7,0,0),(960,'V3KROVDI - Antiguo vWorkspace',1,2048,0,2,2,7,0,0),(961,'PCS11936 - PRUEBAS W7 LABORATORIO',2,2048,40,1,1,7,515,1671),(962,'PCS11992 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(963,'V3KHPSOA - PRUEBAS HP QUALITY MANAGEMENT SOA',2,3072,54,1,2,7,164,1660),(964,'V8KROTF5 - TEAM FOUNDATION SERVER DESARROLLO',4,4096,90,1,2,7,790,2979),(965,'PCS11829 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,332,1137),(966,'VXKDOCS1',2,2048,20,1,2,7,141,853),(967,'VLIMNT02 - Cliente managed node tivoli transi',1,512,4,1,3,7,143,477),(968,'V8KPRUEBA - PRUEBAS SCOM LABORATORIO',1,4096,70,1,2,7,180,2810),(969,'V3KOML02 - SERVIDOR SCOM DE PRUEBAS',1,2048,33,1,2,7,172,974),(970,'V8KSHPR1 - PILOTO SHAREPOINT 2010',2,4096,70,1,2,7,709,3179),(971,'V8KOCF2P - FRONTAL 2 OCS SERVER R2',2,2048,65,1,2,7,373,1509),(972,'V8KROPSH - Repositorio de scripts powershell',1,1128,60,1,2,7,54,955),(973,'V8KSPPP3 - GESTION DOCUMENTAL ENTORNO PREPRO',2,6144,100,1,2,7,521,4957),(974,'',2,2048,38,1,2,7,93,1727),(975,'V3KSDESK - Service Desk CA',2,4096,25,1,2,7,160,2004),(976,'V3KSCSQL - Laboratorio SCOM  SQL',4,4096,199,1,2,7,894,2757),(977,'V3KWALP1 - WALL STREET OFFICE DE PRUEBAS',1,2048,32,1,2,7,123,1138),(978,'PCS11878 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(979,'VLITS031 - Maquina de pruebas operacion',1,1024,40,1,3,7,385,992),(980,'VLINAGPC - Servidor de pruebas de monitorizac',2,2048,8,1,3,7,1668,1922),(981,'VLIRAK01 - Manager de Radia Pruebas 7.8',2,4096,42,1,3,7,259,692),(982,'V8KSPPP4 - GESTION DOCUMENTAL ENTORNO PREPRO',2,6144,100,1,2,7,388,4385),(983,'PCS11845 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(984,'V8KCASQL - SQL SERVER PARA SERVICE DESK',1,4096,80,1,2,7,375,3608),(985,'V8KCONTA - PILOTO CONTAPLUS PARA TASAMADRID',1,2048,60,1,2,7,64,1050),(986,'PCS11765 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,339,1220),(987,'PCS11779 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(988,'PCS11772.grupo.cm.es',2,2048,50,1,1,7,386,1312),(989,'V3KEIKON - TERMINAL EIKON DE THOMSON REUTERS',1,1024,20,1,2,7,131,697),(990,'V3KRO001 - SERVIDOR GASPER DESARROLLO',4,4096,120,1,2,7,418,2197),(991,'V8KSPDA4 - BACKUP GRANJA EPM PARA SHAREPOINT',2,4096,60,1,2,7,53,677),(992,'VLITSTJL - Pruebas RHEL 5.5',1,1024,411,1,3,7,160,506),(993,'V8KSPD01.grupo.cm.es',2,4096,115,1,2,7,577,3159),(994,'V8KSQL04 - SQL SERVER PARA SHAREPOINT 2010',2,4096,183,1,2,7,965,3456),(995,'VLIVMA41 - VMware Management Assistant',1,512,25,1,3,7,193,509),(996,'PCS11809 - PRUEBAS XP LABORATORIO',2,2048,50,1,1,7,381,1131),(997,'PCS11796 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,306,903),(998,'PCS11820 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(999,'PCS11766 - PRUEBAS XP LABORATORIO',2,2048,50,1,1,7,591,1260),(1000,'PCS11824 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1001,'PCS11831 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1002,'PCS11804 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1003,'VLIPRORE - Servidor de Open Reports',2,2048,50,1,3,7,67,2047),(1004,'VLIPRHOD_CLON',1,1024,30,2,3,7,163,829),(1005,'V8KCART1',1,1128,40,2,2,7,0,0),(1006,'PCS11801 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,3,8),(1007,'PCS11774 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,242,718),(1008,'PCS11771.grupo.cm.es',2,2048,50,1,1,7,456,1408),(1009,'PCS11819.grupo.cm.es',2,2048,40,1,1,7,351,1694),(1010,'V8KO12L1 - PILOTO SCOM 2012',1,4096,80,1,2,7,485,3296),(1011,'PCS11794 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,68,271),(1012,'PCS11737',2,2048,40,2,1,7,12,25),(1013,'AD1-PCS11118',2,2048,50,2,1,7,0,0),(1014,'AD1-PCS11119',2,2048,40,2,1,7,0,0),(1015,'V3KSPST3.grupo.cm.es',2,2048,65,1,2,7,196,924),(1016,'PCS11768.grupo.cm.es',2,2048,50,1,1,7,175,626),(1017,'PCS11817.grupo.cm.es',2,2048,50,1,1,7,294,905),(1018,'V8KSPDA3.grupo.cm.es',1,2048,70,1,2,7,208,1205),(1019,'VLITEST -  Pruebas SCOM Red Hat',1,512,19,1,3,7,172,375),(1020,'VLIRORTS - Pruebas DSI',1,512,20,1,3,7,401,497),(1021,'VLIRAK04 - Proxy 3 de Radia Pruebas 7.8',1,2048,10,1,3,7,138,446),(1022,'V8KSHPR2 - PILOTO SHAREPOINT 2010',2,4096,70,1,2,7,714,3265),(1023,'PCS11869 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1024,'V8KSHCOL - PILOTO ANALITICA SHAREPOINT',2,2048,47,1,2,7,235,1663),(1025,'PCS11798 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(1026,'V8XLGDC1 -  PRUEBAS DC LABORATORIO',1,1024,36,1,2,7,176,930),(1027,'VLIICITS - Pruebas monitorizacion Icinga',1,1024,20,1,3,7,168,626),(1028,'V8KCLEAR - RATIONAL CLEAR CASE PRUEBAS',1,2048,100,1,2,7,97,1660),(1029,'V3KCAADT - SERVIDOR DE CONEXION ADT SERVICE D',1,4096,79,1,2,7,91,2106),(1030,'PCS11821 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(1031,'PCS11881  - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1032,'PCS11816 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(1033,'PCS11930 - APLICACION ISIS - NO ENCENDER',1,1024,25,2,1,7,397,793),(1034,'VLISYNCA - Maquina pruebas Syncway Caja Avila',1,512,8,2,3,7,0,0),(1035,'V3KVLABM - VC Lab Manager pruebas',1,1024,8,2,2,7,0,0),(1036,'PCS11974 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1037,'V8KVDIT1 - Pruebas VDI Distribuido',1,1024,44,2,2,7,0,0),(1038,'vlicycle',1,2048,40,1,3,7,93,1727),(1039,'V8KVDISL - Pruebas VDI Distribuido',1,1024,44,2,2,7,0,0),(1040,'PCS11876 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1041,'VLISCMTS - Pruebas Integracion SCCM con Linux',1,1024,8,2,3,7,0,0),(1042,'SOAW0480 - Servidor oficinas de pruebas',2,1024,35,2,3,7,0,0),(1043,'VLIROSQL - SQL SERVER PARA COMUNICACIONES',1,2048,250,1,3,7,116,1911),(1044,'PCS11924 - Pc virtual para las guardias',1,1024,50,2,1,7,0,0),(1045,'PCS11777 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,241,671),(1046,'V3KSMD03 - SERVIDOR WEB PARA SPEECHMINER',1,2048,62,1,2,7,155,979),(1047,'VLIPRAC1 - Servidor de Pruebas ACS',1,1024,20,2,3,7,0,0),(1048,'PCS11839 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1049,'VLIMNT01 - Cliente pruebas MN Tivoli',1,512,4,2,3,7,0,0),(1050,'V8XLGMB1 - EX2007 PRUEBAS EXCHANGE MAILBOX',2,2048,65,1,2,7,1739,1686),(1051,'V8KVDIGW - Pruebas VDI Distribuido',1,1024,44,2,2,7,0,0),(1052,'V3KCLEAR - RATIONAL CLEARCASE PRUEBAS',1,2048,68,1,2,7,326,1609),(1053,'@PCS00000 - ORIGINAL 25GB 20102011 NO CLONAR',1,1024,24,3,1,7,0,0),(1054,'PCS11888  - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1055,'V8KROTF4 - TEAM FOUNDATION SERVER DESARROLLO',4,4096,50,1,2,7,1527,3377),(1056,'V3KRSA01 -  RSA SERVER PARA SEGURIDAD',1,3000,128,1,2,7,296,2350),(1057,'V8KSQLSH - SQL SERVER PARA SHAREPOINT 2010',2,4096,120,1,2,7,636,3491),(1058,'V8KSQL05 - SQL SERVER PARA SHAREPOINT 2010',2,4096,170,1,2,7,2228,3686),(1059,'V8KSVION - SUBVERSION PARA DESARROLLO',2,3000,40,1,2,7,126,1953),(1060,'V8KCASDM - SERVICE DESK MANAGER',2,4096,80,1,2,7,264,2918),(1061,'PCS11785 - PRUEBAS XP LABORATORIO',2,2048,30,2,1,7,0,0),(1062,'V8KOCWAP - BACKEND%2fSQL PARA OCS SERVER R2',2,2048,65,1,2,7,229,1690),(1063,'PCS11773 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,325,1193),(1064,'PCS11815 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(1065,'PCS11973 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1066,'V3KR2SP2 - MASTER SP2 W2003 R2',1,1024,12,2,2,7,0,0),(1067,'V8XLGMB2 - EX2007 PRUEBAS EXCHANGE MAILBOX',2,2048,62,1,2,7,1910,1714),(1068,'PCS11873 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1069,'V3KMID01 - PROYECTO MULTIDIOMA DESARROLLO',2,4096,48,1,2,7,291,2914),(1070,'V8KSPD02 - FRONTAL SHAREPOINT 2010 DESARROLLO',2,4096,110,1,2,7,500,2953),(1071,'VLIROORE - SERVIDOR DE OPEN REPORTS',2,4096,37,1,3,7,204,884),(1072,'PCS11836 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1073,'PCS11811 - PRUEBAS XP LABORATORIO',2,2048,50,1,1,7,409,1297),(1074,'PCS11837 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1075,'PCS11827 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1076,'PCS11832 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1077,'PCS11977 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1078,'PCS11778 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(1079,'VLIONTAP - Appliance formativo para NetApp',2,1600,49,1,6,7,392,1597),(1080,'@PCS - W7 40Gb',2,2048,40,3,1,7,0,0),(1081,'VLIRORW2 - PANELES CONTACT CENTER',1,256,45,1,3,7,162,228),(1082,'V8KCMO02 - PILOTO CONSULTA MANUALES OPERATIVO',1,2048,65,1,2,7,364,1626),(1083,'@QA-PCS00000 - W7 SP1 40 GB',1,1024,24,3,1,7,0,0),(1084,'@PCS - W7 Template PuestosTrabajo 40Gb',2,2048,40,3,1,7,0,0),(1085,'PCS11814 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1086,'PCS11935 - PRUEBAS W7 LABORATORIO',2,2048,40,1,1,7,527,1744),(1087,'V8KCAST1 - ENTORNO TRANSITO PARA GIS-CA',1,1128,40,2,2,7,0,0),(1088,'VLIEYEOS - SERVIDOR DEBIAN',2,2048,20,1,3,7,12,921),(1089,'V8KCABT1',1,2048,40,2,2,7,0,0),(1090,'PCS11825 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1091,'PCS11889 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1092,'V3KSPST3 - SHAREPOINT 2007 ENTORNO DESARROLLO',2,2048,65,2,2,7,196,924),(1093,'PCS11767.grupo.cm.es',2,2048,50,1,1,7,521,1387),(1094,'V3KDOCS1',1,1024,20,2,2,7,0,0),(1095,'@PCS - XP TEMPLATE PUESTOS TRABAJO 50Gb',2,2048,50,3,1,7,242,637),(1096,'PCS11776 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,215,582),(1097,'VLIRO031 - Maquina de pruebas operacion',1,1024,115,1,3,7,64,1001),(1098,'PCS11976 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,192,655),(1099,'V8KSPR01 - FRONTAL SHAREPOINT Y APLICACIONES',2,8192,80,1,2,7,551,5660),(1100,'V8KSQLIC - SQL Server para vCenter4 pruebas',1,1024,64,1,2,7,156,878),(1101,'@SRV_AD_V8KROOF1',2,1128,22,1,2,7,47,636),(1102,'PCSPRU01 - Interna',2,2048,30,1,1,7,93,329),(1103,'@SRV_AD_V8KCRGR1',2,1128,22,1,2,7,47,636),(1104,'V8KROOF1 - CONTROLADOR DE DOMINIO OFICINAS SI',2,1128,22,1,2,7,59,829),(1105,'PCS11116 - ADPRU',2,2048,18,1,1,7,237,667),(1106,'VLIMNT03 - Cliente managed node tivoli transi',1,512,8,1,3,7,160,498),(1107,'@SRV_AD_V8KSRV01',1,2048,40,1,2,7,47,636),(1108,'V8KSQLR1 - SERVIDOR SQL PARA SHAREPOINT',2,8192,130,1,2,7,730,6300),(1109,'PREV8KROOF1_clon',2,1128,22,1,2,7,61,927),(1110,'PCS11113 - ADPRU',2,2048,18,1,1,7,190,838),(1111,'PCS11780 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(1112,'VLIPRUAD - PRUEBAS AUTENTICACION AD',1,2048,20,2,3,7,0,0),(1113,'VLIPRBIR - BUSINESS INTELLIGENCE REPORTS',1,1024,20,1,3,7,10,1013),(1114,'V8KAPLSK - PROYECTO APLISEK PARA AUDITORIA',1,2048,40,1,2,7,29,818),(1115,'PCS80225 - Alfa XP',2,2048,50,2,1,7,0,0),(1116,'V3KSPSD2 - SHAREPONT 2007 ENTORNO DESARROLLO',1,1024,33,1,2,7,189,582),(1117,'V8KO12DB - SQL SERVER PARA PILOTO SCOM 2012',4,4096,240,1,2,7,983,3478),(1118,'V3KHYP01 - HYPERION CAJA DESARROLLO',2,4096,54,1,2,7,454,2895),(1119,'PCS11786 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(1120,'V3KRO002 - SERVIDOR GASPER TRANSITO',4,4096,120,1,2,7,171,2263),(1121,'V8KCABOB - BUSINESS OBJECTS XI PARA SERVICE D',1,4096,80,1,2,7,384,2874),(1122,'PCS11879 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1123,'PCS11812 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(1124,'PCS80014 - Pruebas OCS Link',2,2048,40,1,1,7,622,1682),(1125,'PCS11884 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1126,'PCS11834 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1127,'PCS11833 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1128,'PCS11826 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1129,'V2KOML01 - SERVIDOR PRUEBAS LABEXCH EN SCOM',1,1024,8,1,6,7,47,923),(1130,'PCS11883  - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1131,'V3KSPSD1 - SHAREPOINT 2007 ENTORNO DESARROLLO',1,1024,33,1,2,7,104,531),(1132,'PCS11830 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1133,'V8KCMO01 - PILOTO CONSULTA MANUALES OPERATIVO',1,2048,65,1,2,7,489,1646),(1134,'PCS11838 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1135,'V3KOCSQP - WEB ACCESS PARA OCS SERVER R2',2,2048,64,1,2,7,310,858),(1136,'PCS11783 - PRUEBAS XP LABORATORIO',2,2048,30,2,1,7,0,0),(1137,'PCS11891 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1138,'PCS11844 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1139,'V3KGPEDT - PRUEBAS VARIAS WORKSPACE',2,2048,40,2,1,7,0,0),(1140,'PCS80205 - Alfa W7',2,2048,40,2,1,7,0,0),(1141,'PCS11868 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1142,'PCS11823 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,0,0),(1143,'PCS11769.grupo.cm.es',2,2048,50,1,1,7,538,1335),(1144,'V8KVC4U2 - PRUEBAS VC',2,2048,44,2,2,7,0,0),(1145,'PCS11990 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1146,'V8KROTF2 - TEAM FOUNDATION SERVER DESARROLLO',4,4096,68,1,2,7,1296,3437),(1147,'V8XLGHUB - EX2007 PRUEBAS EXCHANGE HUB',2,4096,50,1,2,7,650,2933),(1148,'VLIPRHOD - PRUEBAS HOD 11',1,1024,30,1,3,7,163,829),(1149,'PCS11787 - PRUEBAS XP LABORATORIO',2,2048,36,2,1,7,0,0),(1150,'@SRV_AD_V8KROGR1',2,2084,42,1,2,7,47,636),(1151,'V8KROGR1 - CONTROLADOR DE DOMINIO GRUPO SITE ',2,2084,42,1,2,7,69,1121),(1152,'PCS11892 - PRUEBAS W7 LABORATORIO',2,2048,40,2,1,7,0,0),(1153,'VLIDHCPT - Servidor DHCP entorno Test',1,256,8,1,3,7,160,221),(1154,'PREV8KROGR1_clon',2,1128,42,1,2,7,61,927),(1155,'V3KMIIS1.PREGRUPO.CM.ES',4,8192,105,1,2,7,93,1727),(1156,'@SRV_AD_V8KCROF1',2,1128,22,1,2,7,47,636),(1157,'PREV8KCROF2_clon',2,1128,22,1,2,7,62,922),(1158,'PREV8KEXGR1',2,1128,30,1,2,7,159,1003),(1159,'@SRV_AD_V8KADGPO',2,1128,40,1,2,7,47,636),(1160,'V8KCROF1 - CONTROLADOR DE DOMINIO OFICINAS SI',2,1128,22,1,2,7,54,848),(1161,'PCS11111- ADPRU',2,2048,18,1,1,7,266,748),(1162,'PCS11115 - ADPRU',2,2048,18,1,1,7,239,620),(1163,'V8KCRGR1 - CONTROLADOR DE DOMINIO GRUPO SITE ',2,1128,22,1,2,7,56,822),(1164,'V3KBKPC1 - BACKUP CONNECTED DE PRUEBAS. NO TO',1,2048,105,2,2,7,0,0),(1165,'@SRV_AD_V3KSRV01',1,1024,20,1,2,7,47,636),(1166,'PREV8KCRGR2_clon',2,1128,22,1,2,7,62,922),(1167,'PCS11791 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,304,879),(1168,'VLIVMNET - Maquina de pruebas Vmxnet3 Debian ',1,512,10,2,3,7,6,127),(1169,'VLIVMNE2 - Maquina de pruebas Vmxnet3 Debian ',1,512,10,2,3,7,2,10),(1170,'VLIVMNE3 - Maquina de pruebas Vmxnet3 Debian ',1,512,10,2,3,7,5,20),(1171,'VLIROGIB - Reporting Informes Gestion IB',1,1024,12,1,3,7,33,1022),(1172,'PCS11775 - PRUEBAS XP LABORATORIO',2,2048,50,1,1,7,478,1231),(1173,'PCS11792 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,56,156),(1174,'PCS11795 - PRUEBAS XP LABORATORIO',2,2048,50,2,1,7,2,11),(1175,'VLIVAUB1_clon',1,4096,150,2,3,7,0,0),(1176,'PCS11818 -  PRUEBAS XP LABORATORIO',2,2048,50,1,1,7,504,1445),(1177,'PCS11770 - PRUEBAS XP LABORATORIO',2,2048,50,1,1,7,346,1031),(1178,'c-353',4,4096,42,1,3,9,827,4016),(1179,'c-354',2,2048,42,1,3,9,0,0),(1180,'c-355',2,1024,42,1,3,9,0,0),(1181,'c-356',2,1024,42,1,3,9,0,0),(1182,'c-357',2,1024,162,1,3,9,0,0),(1183,'c-358',2,2048,42,1,3,9,95,2042),(1184,'c-785',4,8192,28,1,3,9,88,1434),(1185,'c-798',4,8192,28,1,3,9,126,2721),(1186,'c-520',4,8192,24,1,3,9,321,4345),(1187,'c-525',4,4096,32,1,3,9,355,793),(1188,'c-523',4,6144,36,1,3,9,385,1094),(1189,'c-527',4,6144,42,1,3,9,427,1852),(1190,'c-521',4,8192,24,1,3,9,121,803),(1191,'slirods1',2,4096,70,1,3,9,241,322),(1192,'c-529',4,8192,46,1,3,9,453,1486),(1193,'c-531',4,8192,34,1,3,9,638,4819),(1194,'c-528',4,8192,36,1,3,9,382,849),(1195,'c-530',4,8192,51,1,3,9,406,2302),(1196,'c-526',4,12288,36,1,3,9,788,7718),(1197,'c-522',4,8192,32,1,3,9,368,3143),(1198,'c-524',4,10240,47,1,3,9,734,8117),(1199,'S8KROVC1.cm.es',2,4096,40,1,2,9,0,0),(1200,'c-584',4,8192,32,1,3,9,214,7904),(1201,'c-583',4,8192,32,1,3,9,322,7906),(1202,'c-532',2,4096,30,1,3,9,110,3836),(1203,'c-533',2,4096,30,1,3,9,88,3836),(1204,'S8KSHVC2.cm.es',2,4096,40,1,2,9,0,0),(1205,'w2k8r2-tmp',1,1024,40,3,2,9,0,0),(1206,'c-290',2,8192,42,1,3,9,3634,3678),(1207,'c-297',4,8192,42,1,3,9,649,2074),(1208,'c-292',4,8192,42,1,3,9,810,2307),(1209,'c-383',4,8192,22,1,3,9,625,1650),(1210,'c-345',2,4096,27,1,3,9,554,839),(1211,'c-431',4,8192,36,1,3,9,511,936),(1212,'c-387',2,8192,37,1,3,9,404,1767),(1213,'c-403',4,8192,30,1,3,9,529,1553),(1214,'c-419',4,10240,46,1,3,9,610,3281),(1215,'c-240',4,8192,57,1,3,9,750,2218),(1216,'ssuronf1',2,512,884,1,3,9,111,117),(1217,'RHEL5_x86-64',1,512,12,3,3,9,0,0),(1218,'c-244',4,8192,37,1,3,9,679,4303),(1219,'c-291',4,8192,42,1,3,9,1110,4735),(1220,'c-384',4,8192,22,1,3,9,658,1750),(1221,'c-296',2,4096,42,1,3,9,337,334),(1222,'c-346',2,4096,27,1,3,9,439,758),(1223,'c-298',2,5120,42,1,3,9,397,1679),(1224,'c-388',4,8192,37,1,3,9,548,2285),(1225,'c-420',4,8192,46,1,3,9,719,3377),(1226,'s3krorp1.cm.es',4,4096,20,1,2,9,426,616),(1227,'W2K3-EE',2,1024,10,3,2,9,0,0),(1228,'c-450',4,8192,38,1,3,9,314,5346),(1229,'c-446',4,8192,30,1,3,9,521,6362),(1230,'c-462',4,8192,26,1,3,9,237,5968),(1231,'c-202',4,8192,50,1,3,9,762,6825),(1232,'c-243',2,8192,27,1,3,9,372,4899),(1233,'c-437',4,8192,22,1,3,9,257,6982),(1234,'c-434',4,8192,26,1,3,9,161,3257),(1235,'c-786',4,8192,44,1,3,9,1213,7896),(1236,'c-430',4,8192,36,1,3,9,286,5523),(1237,'c-405',2,8192,26,1,3,9,219,5345),(1238,'c-438',4,8192,34,1,3,9,976,7900),(1239,'c-475',4,8192,28,1,3,9,818,7902),(1240,'c-454',4,8192,31,1,3,9,153,5073),(1241,'c-589',4,8192,47,1,3,9,644,7899),(1242,'c-485',4,8192,49,1,3,9,1247,5652),(1243,'c-442',4,8192,71,1,3,9,159,4926),(1244,'c-590',4,8192,46,1,3,9,930,6586),(1245,'c-201',2,8192,57,1,3,9,386,6656),(1246,'c-404',2,8192,30,1,3,9,131,7891),(1247,'c-787',2,8192,40,1,3,9,159,7888),(1248,'c-406',2,8192,30,1,3,9,144,7701),(1249,'c-455',2,8192,47,1,3,9,138,7286),(1250,'c-459',2,8192,51,1,3,9,152,7429),(1251,'c-463',2,8192,31,1,3,9,112,5120),(1252,'c-439',4,8192,34,1,3,9,678,7898),(1253,'c-436',4,8192,22,1,3,9,699,7905),(1254,'c-447',2,8192,30,1,3,9,469,7766),(1255,'c-443',4,8192,55,1,3,9,2400,5990),(1256,'c-451',2,8192,34,1,3,9,203,7553),(1257,'c-204',4,8192,83,1,3,9,230,5723),(1258,'c-476',4,8192,28,1,3,9,458,7900),(1259,'c-336',4,16384,58,1,3,9,1626,4660),(1260,'c-398',4,8192,37,1,3,9,1081,4341),(1261,'c-433',4,8192,22,1,3,9,880,4294),(1262,'c-386',4,8096,52,1,3,9,532,3368),(1263,'c-390',4,8192,33,1,3,9,845,3274),(1264,'c-401',4,8096,52,1,3,9,864,3131),(1265,'c-408',4,8192,26,1,3,9,932,3877),(1266,'c-348',2,4096,26,1,3,9,425,2131),(1267,'c-312',4,4096,42,1,3,9,655,2319),(1268,'c-338',2,4096,22,1,3,9,599,2390),(1269,'c-374',2,4096,26,1,3,9,618,1716),(1270,'c-422',4,8192,66,1,3,9,1577,6401),(1271,'c-410',4,8192,46,1,3,9,2607,4079),(1272,'v3kshlm1',2,8192,20,2,2,9,0,0),(1273,'c-331',4,16384,58,1,3,9,1229,6413),(1274,'c-245',2,4096,30,1,3,9,373,459),(1275,'s3kroal3',2,2048,10,2,2,9,0,0),(1276,'c-299',4,4096,42,1,3,9,1067,2296),(1277,'c-347',2,4096,25,1,3,9,570,1279),(1278,'c-337',2,4096,22,1,3,9,598,2703),(1279,'c-373',2,4096,25,1,3,9,616,2080),(1280,'c-385',4,8192,52,1,3,9,531,4019),(1281,'c-409',4,8192,46,1,3,9,778,4710),(1282,'c-432',4,8192,22,1,3,9,1203,7912),(1283,'c-397',4,8192,37,1,3,9,1028,5296),(1284,'c-421',4,8192,66,1,3,9,1493,6403),(1285,'vlishpr1',1,1024,12,1,3,9,646,369),(1286,'vlishpr2',1,1024,12,1,3,9,643,400),(1287,'s3kshsq4',4,8192,10,2,2,9,0,0),(1288,'c-453',4,8192,28,1,3,9,828,4384),(1289,'c-474',4,8192,24,1,3,9,1631,7862),(1290,'c-484',4,8192,32,1,3,9,1357,4820),(1291,'c-478',4,8192,32,1,3,9,1788,6198),(1292,'c-449',4,8192,36,1,3,9,2052,6472),(1293,'c-469',4,8192,26,1,3,9,1496,7890),(1294,'c-480',4,8192,29,1,3,9,706,2463),(1295,'c-457',4,8192,37,1,3,9,747,4442),(1296,'c-471',4,8192,26,1,3,9,1671,6562),(1297,'c-426',4,8192,42,1,3,9,1606,6817),(1298,'c-441',4,8192,30,1,3,9,921,4452),(1299,'s3kshgd2',2,8192,20,2,2,9,0,0),(1300,'c-785',4,8192,28,1,3,9,88,1434),(1301,'c-789',4,8192,37,1,3,9,2029,7352),(1302,'s3kshal2',2,4096,30,2,2,9,0,0),(1303,'',4,8192,29,1,3,9,0,0),(1304,'c-587',4,8192,28,1,3,9,2471,5814),(1305,'c-535',2,4096,30,1,3,9,827,2543),(1306,'c-588',4,8192,28,1,3,9,1201,6281),(1307,'c-328',4,16384,58,1,3,9,278,4229),(1308,'c-456',4,8192,37,1,3,9,354,4325),(1309,'c-483',4,8192,32,1,3,9,902,4289),(1310,'c-797',4,8192,28,1,3,9,451,1031),(1311,'s3kshal5',2,2048,10,2,2,9,0,0),(1312,'c-781',2,4096,30,1,3,9,305,967),(1313,'c-784',4,8192,28,1,3,9,782,3256),(1314,'c-448',4,8192,36,1,3,9,960,4528),(1315,'s3kroal4',2,2048,10,2,2,9,0,0),(1316,'c-788',4,8192,38,1,3,9,1096,3643),(1317,'c-452',4,8192,28,1,3,9,717,4373),(1318,'c-468',4,8192,26,1,3,9,2641,7829),(1319,'c-011',4,8192,31,1,3,9,325,681),(1320,'c-477',4,8192,32,1,3,9,776,5312),(1321,'c-472',4,8192,26,1,3,9,2585,6540),(1322,'c-479',4,8192,29,1,3,9,373,2282),(1323,'s3kroad1.ssaa-clusters.cm.es',2,1024,10,1,2,9,80,239),(1324,'c-481',4,8192,29,1,3,9,352,4131),(1325,'s3krogd1.ssaa-clusters.cm.es',2,8192,20,1,2,9,281,1884),(1326,'s3krosq3',4,8192,10,2,2,9,0,0),(1327,'c-389',4,8192,35,1,3,9,490,2923),(1328,'c-473',4,8192,24,1,3,9,1406,5428),(1329,'c-407',4,8192,26,1,3,9,412,3253),(1330,'s3kroal1',2,4096,20,2,2,9,0,0),(1331,'s3krobrt.cm.es',2,4096,14,1,2,9,353,1075),(1332,'c-400',4,8192,52,1,3,9,341,2257),(1333,'c-425',4,8192,42,1,3,9,655,4339),(1334,'c-440',4,8192,30,1,3,9,543,4305),(1335,'v3krolm1.cm.es',2,8192,20,1,2,9,492,1333),(1336,'c-534',2,4096,30,1,3,9,595,2418),(1337,'c-585',4,8192,28,1,3,9,774,2882),(1338,'c-586',4,8192,28,1,3,9,511,1727),(1339,'c-780',2,4096,25,1,3,9,797,3802),(1340,'c-757',4,8192,226,1,3,9,170,5016),(1341,'c-755',4,8192,226,1,3,9,157,3522),(1342,'c-756',4,8192,226,1,3,9,156,3809),(1343,'c-754',4,8192,34,1,3,9,559,5734),(1344,'c-753',4,8192,226,1,3,9,527,3045),(1345,'c-752',4,8192,226,1,3,9,679,3956);
/*!40000 ALTER TABLE `Elementos_virtuales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GruposAlmacenamiento_reservado`
--

DROP TABLE IF EXISTS `GruposAlmacenamiento_reservado`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `GruposAlmacenamiento_reservado` (
  `idGrupoAlmacenamiento_reservado` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Mes` varchar(45) character set latin1 default NULL,
  `Ano` int(11) default NULL,
  `Reservado_Produccion_CLARIION_CX700` int(11) default NULL,
  `Reservado_Produccion_CLARIION_CX380` int(11) default NULL,
  `Reservado_Produccion_CLARIION_CX340` int(11) default NULL,
  `Reservado_Centro_Respaldo_CLARIION_CX340` int(11) default NULL,
  `Reservado_Netapp_FCAraneaEXTFC` int(11) default NULL,
  `Reservado_Netapp_SATA` int(11) default NULL,
  `Reservado_Netapp_SATA_Laboratorio` int(11) default NULL,
  `Reservado_Netapp_SATA_TEST` int(11) default NULL,
  `Reservado_Test_CLARIION_CX380` int(11) default NULL,
  `Reservado_Test_CLARIION_CX340` int(11) default NULL,
  `Reservado_NFS_FC` int(11) default NULL,
  `Reservado_NFS_SATA` int(11) default NULL,
  PRIMARY KEY  (`idGrupoAlmacenamiento_reservado`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `GruposAlmacenamiento_reservado`
--

LOCK TABLES `GruposAlmacenamiento_reservado` WRITE;
/*!40000 ALTER TABLE `GruposAlmacenamiento_reservado` DISABLE KEYS */;
INSERT INTO `GruposAlmacenamiento_reservado` VALUES ('2012-04-17 10:14:13','abril',2012,14,7,20,9,4,11,2,9,9,8,3,4);
/*!40000 ALTER TABLE `GruposAlmacenamiento_reservado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Grupos_almacenamiento`
--

DROP TABLE IF EXISTS `Grupos_almacenamiento`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Grupos_almacenamiento` (
  `idGrupos_almacenamiento` int(11) NOT NULL,
  `Grupo_almacenamiento` varchar(45) default NULL,
  PRIMARY KEY  (`idGrupos_almacenamiento`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Grupos_almacenamiento`
--

LOCK TABLES `Grupos_almacenamiento` WRITE;
/*!40000 ALTER TABLE `Grupos_almacenamiento` DISABLE KEYS */;
INSERT INTO `Grupos_almacenamiento` VALUES (1,'Produccion CLARIION CX-700'),(2,'Produccion CLARIION CX-380'),(3,'Produccion CLARIION CX-340'),(4,'Centro de Respaldo CLARIION CX-340'),(5,'Netapp FC Aranea (EXTFC)'),(6,'Netapp SATA'),(7,'Netapp SATA pruebas Laboratorio'),(8,'Netapp SATA entorno de TEST'),(9,'Test CLARIION CX-380'),(10,'Test CLARIION CX-340'),(11,'NFS FC'),(12,'NFS SATA'),(13,'OTROS'),(14,'CLARIION CX-340 (PPMM)'),(15,'Symmetrix DMX-3 (PPMM)'),(16,'Symmetrix DMX-800 (PPMM)'),(17,'Symmetrix DMX-4 (PPMM)'),(18,'Symmetrix DMX-800 (PPMM)'),(19,'IBM DS8100 (PPMM)'),(20,'Symmetrix DMX-2000 (PPMM)'),(21,'NFS Hitachi (PPMM)'),(22,'IBM DS8300 (PPMM)');
/*!40000 ALTER TABLE `Grupos_almacenamiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Hipervisores`
--

DROP TABLE IF EXISTS `Hipervisores`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Hipervisores` (
  `IDHipervisores` int(11) NOT NULL,
  `Hostname` varchar(45) character set latin1 default NULL,
  `Num_cores` int(11) default NULL,
  `Memoria_Instalada_MB` float default NULL,
  `Red_instalada_Gb` float default NULL,
  `Red_consumida_Gb` float default NULL,
  `CPU_Consumida_Mhz` float default NULL,
  `CPU_Instalada_Mhz` float default NULL,
  `Memoria_Consumida_MB` float default NULL,
  `IDCluster` int(11) default NULL,
  PRIMARY KEY  (`IDHipervisores`),
  KEY `Nombre vm` (`IDHipervisores`),
  KEY `Nombre Cluster` (`IDCluster`),
  CONSTRAINT `Id Cluster` FOREIGN KEY (`IDCluster`) REFERENCES `Clusters` (`idCluster`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Hipervisores`
--

LOCK TABLES `Hipervisores` WRITE;
/*!40000 ALTER TABLE `Hipervisores` DISABLE KEYS */;
INSERT INTO `Hipervisores` VALUES (1,'svmrobk2.cm.es',16,65532.4,8,0.000418987,120,38401.3,1688.87,6),(2,'svmro022.cm.es',24,131068,9,9.01032e-05,11590.6,57602,39464.4,2),(3,'svmrobk3.cm.es',16,65532.4,8,0.000383759,595.68,38401.3,2799.38,6),(4,'svmro002.cm.es',16,131069,9,0.00152694,10613.9,38401.4,36123.8,3),(5,'svmro006.cm.es',16,131069,9,0,0,38401.4,0,3),(6,'svmro007.cm.es',16,131069,9,0,0,38401.4,0,3),(7,'svmro010.cm.es',16,131069,9,0,0,38400,0,5),(8,'svmro009.cm.es',24,131069,8,0.00136232,18761.5,57602,87351,4),(9,'svmro008.cm.es',16,131069,9,0.00127527,7018.68,38401.4,31482.7,3),(10,'svmro011.cm.es',16,131069,9,0.000817928,15092.4,38400,44317,5),(11,'svmro004.cm.es',24,131069,8,0.00694731,15847.3,57602,86906.2,4),(12,'svmro013.cm.es',16,131069,8,0.000849447,10006,38401.4,45849.4,3),(13,'svmro003.cm.es',24,131069,8,0.00402152,20489.1,57602,86114.9,4),(14,'svmro012.cm.es',16,131069,9,0.00161661,15985.5,38401.3,53222.3,5),(15,'svmro015.cm.es',16,131069,7,0.002077,14556.3,38401.4,71374.7,5),(16,'svmro014.cm.es',16,131069,7,0.00100917,11399,38401.4,53020.5,3),(17,'svmro005.cm.es',16,131069,9,0.00055645,9390.93,38401.4,39960.1,3),(18,'svmro016.cm.es',16,131069,7,0.000540628,10315.4,38401.4,39171.4,3),(19,'svmro019.cm.es',16,131068,9,0.000353584,10092.1,38401.4,35439.4,2),(20,'svmpru04.cm.es',8,131068,6,0.000216513,8061.46,23466.6,45328,7),(21,'svmpru05.cm.es',16,131068,5,0.000182333,18183.5,38401.4,74363.2,7),(22,'svmpru03.cm.es',16,131068,6,0.00115502,13532.3,38400,62978.8,7),(23,'svmcor02.cm.es',24,131069,10,0.00130145,8365.14,57602,59419.2,1),(24,'svmpru01.cm.es',16,131068,6,0.000810556,16834,38400,65205.3,7),(25,'svmro017.cm.es',8,34805.4,9,0,0,20267.4,0,8),(26,'svmro024.cm.es',8,32757.4,9,0,0,20267.4,0,8),(27,'svmro027.cm.es',24,131068,9,0.000109434,13444.3,57602,38542.1,2),(28,'svmro025.cm.es',8,32757.4,9,1.44291e-05,180.39,20267.4,3473.57,8),(29,'svmro026.cm.es',8,32757.4,9,0,0,20267.4,0,8),(30,'svmro028.cm.es',24,131068,9,7.67517e-05,13193,57602,34952.7,2),(31,'svmro018.cm.es',8,34805.4,9,0.000114555,96,20267.4,1422.45,8),(32,'svmro020.cm.es',16,131068,8.1,5.67245e-05,9492.64,38401.4,30365,2),(33,'svmcor03.cm.es',24,131069,10,0.000249348,7245.43,57602,49155,1),(34,'svmro001.cm.es',16,131069,9,0.0022116,10373.6,38401.4,65231.4,3),(35,'svmro021.cm.es',24,131068,9,0.000209036,11972.1,57602,35919.3,2),(36,'svmpru02.cm.es',16,131068,6,0.000445509,13547.5,38399.9,75970.5,7),(37,'svmro023.cm.es',8,32757.4,9,1.15299e-05,83.89,20267.4,1350.8,8),(38,'svmrobk1.cm.es',16,65532.4,8,0.00127183,427.39,38401.3,5762.71,6),(39,'sliro414.cm.es',8,32757.4,4,0,3212.44,14917.2,13085.7,9),(40,'10.64.132.26',32,262096,10,0,211.58,63840.1,3865.4,9),(41,'sliro249.cm.es',16,65535.6,2,0.000231543,6734.25,36702.5,40604.4,9),(42,'sliro257.cm.es',24,65488.7,6,0,1433.92,47880.5,36327.9,9),(43,'sliro212.cm.es',8,32767.4,4,0.000174122,9951.46,21350.7,24094,9),(44,'sliro213.cm.es',8,32767.4,4,7.50637e-05,6559.75,21350.7,22741,9),(45,'sliro253.cm.es',16,131071,5,0.000160494,8746.67,34116.6,105403,9),(46,'sliro254.cm.es',16,131071,5,0.000340023,7793.17,34116.3,113805,9),(47,'slish007.cm.es',8,65535.4,5.1,0.000502272,15604,21350.6,51445.7,9),(48,'sliro218.cm.es',8,65535.6,6,0.000364952,9978.72,21350.7,47604.5,9),(49,'slish256.cm.es',16,131071,10,0.000630569,27147.3,34116.5,105974,9),(50,'sliro255.cm.es',16,131071,12,0.00141674,21678.6,34116.4,105960,9),(51,'slish735.cm.es',4,16369.8,2,1.68514e-05,659.21,9600.34,14219.2,9),(52,'sliro714.cm.es',4,16369.8,2,0.000649618,1917.33,9600.34,14419.4,9);
/*!40000 ALTER TABLE `Hipervisores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Media_mem_asig_por_vm`
--

DROP TABLE IF EXISTS `Media_mem_asig_por_vm`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Media_mem_asig_por_vm` (
  `idMedia_mem_asig_por_vm` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Mes` varchar(45) character set latin1 default NULL,
  `Ano` int(11) default NULL,
  `Memoria_media_asignada_vms` int(11) default NULL,
  `Media_mem_asig_por_vm_Centro_Respaldo` int(11) default NULL,
  `Media_mem_asig_por_vm_Escritorios` int(11) default NULL,
  `Media_mem_asig_por_vm_Produccion_1` int(11) default NULL,
  `Media_mem_asig_por_vm_Produccion_2` int(11) default NULL,
  `Media_mem_asig_por_vm_Produccion_3` int(11) default NULL,
  `Media_mem_asig_por_vm_Produccion_Backup` int(11) default NULL,
  `Media_mem_asig_por_vm_Test_y_Preproduccion` int(11) default NULL,
  `Media_mem_asig_por_vm_Integracion` int(11) default NULL,
  PRIMARY KEY  (`idMedia_mem_asig_por_vm`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Media_mem_asig_por_vm`
--

LOCK TABLES `Media_mem_asig_por_vm` WRITE;
/*!40000 ALTER TABLE `Media_mem_asig_por_vm` DISABLE KEYS */;
INSERT INTO `Media_mem_asig_por_vm` VALUES ('2012-02-29 16:20:53','febrero',2012,112580,262139,786409,1179623,393208,524277,196597,655341,167883),('2012-03-28 12:09:01','marzo',2012,2292,2981,1661,2257,3697,2401,3210,2194,2970),('2012-04-27 00:26:00','abril',2012,3018,2981,2082,2262,3765,2401,3210,2184,2970);
/*!40000 ALTER TABLE `Media_mem_asig_por_vm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Memoria_Consumida_Percent`
--

DROP TABLE IF EXISTS `Memoria_Consumida_Percent`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Memoria_Consumida_Percent` (
  `idMemoria_Consumida_Percent` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Mes` varchar(45) character set latin1 default NULL,
  `Ano` int(11) default NULL,
  `Memoria_Total_Percent` int(11) default NULL,
  `Memoria_Consumida_Centro_Respaldo` int(11) default NULL,
  `Memoria_Consumida_Escritorios` int(11) default NULL,
  `Memoria_Consumida_Produccion_1` int(11) default NULL,
  `Memoria_Consumida_Produccion_2` int(11) default NULL,
  `Memoria_Consumida_Produccion_3` int(11) default NULL,
  `Memoria_Consumida_Produccion_Backup` int(11) default NULL,
  `Memoria_Consumida_Test_y_Preproduccion` int(11) default NULL,
  `Memoria_Consumida_Integracion` int(11) default NULL,
  PRIMARY KEY  (`idMemoria_Consumida_Percent`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Memoria_Consumida_Percent`
--

LOCK TABLES `Memoria_Consumida_Percent` WRITE;
/*!40000 ALTER TABLE `Memoria_Consumida_Percent` DISABLE KEYS */;
INSERT INTO `Memoria_Consumida_Percent` VALUES ('2012-02-29 08:52:22','febrero',2012,51,43,42,65,60,62,54,41,73),('2012-03-28 12:09:01','marzo',2012,51,53,41,64,60,57,59,41,15),('2012-04-27 00:26:00','abril',2012,51,56,50,57,61,49,55,40,14);
/*!40000 ALTER TABLE `Memoria_Consumida_Percent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Memoria_Disponible_GB`
--

DROP TABLE IF EXISTS `Memoria_Disponible_GB`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Memoria_Disponible_GB` (
  `idMemoria_Disponible_GB` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Mes` varchar(45) character set latin1 default NULL,
  `Ano` int(11) default NULL,
  `Memoria_Total_GB` int(11) default NULL,
  `Memoria_Disponible_Centro_Respaldo` int(11) default NULL,
  `Memoria_Disponible_Escritorios` int(11) default NULL,
  `Memoria_Disponible_Produccion_1` int(11) default NULL,
  `Memoria_Disponible_Produccion_2` int(11) default NULL,
  `Memoria_Disponible_Produccion_3` int(11) default NULL,
  `Memoria_Disponible_Produccion_Backup` int(11) default NULL,
  `Memoria_Disponible_Test_y_Preproduccion` int(11) default NULL,
  `Memoria_Disponible_Integracion` int(11) default NULL,
  PRIMARY KEY  (`idMemoria_Disponible_GB`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Memoria_Disponible_GB`
--

LOCK TABLES `Memoria_Disponible_GB` WRITE;
/*!40000 ALTER TABLE `Memoria_Disponible_GB` DISABLE KEYS */;
INSERT INTO `Memoria_Disponible_GB` VALUES ('2012-02-28 10:46:04','febrero',2012,4068,86,229,660,28,202,124,-111,151),('2012-03-28 12:09:01','marzo',2012,4068,84,203,654,8,200,1,-84,149),('2012-04-27 00:26:00','abril',2012,5252,84,272,655,-2,200,1,-96,181);
/*!40000 ALTER TABLE `Memoria_Disponible_GB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Memoria_Instalada_GB`
--

DROP TABLE IF EXISTS `Memoria_Instalada_GB`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Memoria_Instalada_GB` (
  `idMemoria_Instalada_GB` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Mes` varchar(45) character set latin1 default NULL,
  `Ano` int(11) default NULL,
  `Memoria_Total_GB` int(11) default NULL,
  `Memoria_Instalada_Centro_Respaldo` int(11) default NULL,
  `Memoria_Instalada_Escritorios` int(11) default NULL,
  `Memoria_Instalada_Produccion_1` int(11) default NULL,
  `Memoria_Instalada_Produccion_2` int(11) default NULL,
  `Memoria_Instalada_Produccion_3` int(11) default NULL,
  `Memoria_Instalada_Produccion_Backup` int(11) default NULL,
  `Memoria_Instalada_Test_y_Preproduccion` int(11) default NULL,
  `Memoria_Instalada_Integracion` int(11) default NULL,
  PRIMARY KEY  (`idMemoria_Instalada_GB`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Memoria_Instalada_GB`
--

LOCK TABLES `Memoria_Instalada_GB` WRITE;
/*!40000 ALTER TABLE `Memoria_Instalada_GB` DISABLE KEYS */;
INSERT INTO `Memoria_Instalada_GB` VALUES ('2012-02-29 07:55:05','febrero',2012,4068,256,768,1152,384,512,192,640,164),('2012-03-28 12:09:01','marzo',2012,4068,256,768,1152,384,512,192,640,164),('2012-04-27 00:26:00','abril',2012,5252,256,768,1152,384,512,192,640,196);
/*!40000 ALTER TABLE `Memoria_Instalada_GB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Memoria_asignada_vms`
--

DROP TABLE IF EXISTS `Memoria_asignada_vms`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Memoria_asignada_vms` (
  `idMemoria_asignada_vms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Mes` varchar(45) character set latin1 default NULL,
  `Ano` int(11) default NULL,
  `Memoria_media_asignada_vms` int(11) default NULL,
  `Memoria_asignada_vms_Centro_Respaldo` int(11) default NULL,
  `Memoria_asignada_vms_Escritorios` int(11) default NULL,
  `Memoria_asignada_vms_Produccion_1` int(11) default NULL,
  `Memoria_asignada_vms_Produccion_2` int(11) default NULL,
  `Memoria_asignada_vms_Produccion_3` int(11) default NULL,
  `Memoria_asignada_vms_Produccion_Backup` int(11) default NULL,
  `Memoria_asignada_vms_Test_y_Preproduccion` int(11) default NULL,
  `Memoria_asignada_vms_Integracion` int(11) default NULL,
  PRIMARY KEY  (`idMemoria_asignada_vms`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Memoria_asignada_vms`
--

LOCK TABLES `Memoria_asignada_vms` WRITE;
/*!40000 ALTER TABLE `Memoria_asignada_vms` DISABLE KEYS */;
INSERT INTO `Memoria_asignada_vms` VALUES ('2012-02-28 07:43:19','febrero',2012,2698,170,539,492,356,310,81,751,NULL),('2012-03-28 12:09:01','marzo',2012,2292,172,565,498,376,312,191,724,15),('2012-04-27 00:26:00','abril',2012,3018,172,496,497,386,312,191,736,15);
/*!40000 ALTER TABLE `Memoria_asignada_vms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Num_elem_reg`
--

DROP TABLE IF EXISTS `Num_elem_reg`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Num_elem_reg` (
  `idNum_elem_reg` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Mes` varchar(45) character set latin1 default NULL,
  `Ano` year(4) default NULL,
  `Num_elem` int(11) default NULL,
  PRIMARY KEY  (`idNum_elem_reg`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci COMMENT='Numero de elementos registrados';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Num_elem_reg`
--

LOCK TABLES `Num_elem_reg` WRITE;
/*!40000 ALTER TABLE `Num_elem_reg` DISABLE KEYS */;
INSERT INTO `Num_elem_reg` VALUES ('2011-11-03 17:35:03','noviembre',2011,1321),('2012-03-28 12:09:01','marzo',2012,1274),('2012-04-27 00:26:00','abril',2012,1345);
/*!40000 ALTER TABLE `Num_elem_reg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Num_vms_off`
--

DROP TABLE IF EXISTS `Num_vms_off`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Num_vms_off` (
  `idNum_vms_off` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Mes` varchar(45) character set latin1 default NULL,
  `Ano` int(11) default NULL,
  `Num_vms` varchar(45) character set latin1 default NULL,
  PRIMARY KEY  (`idNum_vms_off`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Num_vms_off`
--

LOCK TABLES `Num_vms_off` WRITE;
/*!40000 ALTER TABLE `Num_vms_off` DISABLE KEYS */;
INSERT INTO `Num_vms_off` VALUES ('2011-11-03 10:04:57','noviembre',2011,'0'),('2012-03-28 12:09:01','marzo',2012,'303'),('2012-04-27 00:26:00','abril',2012,'321');
/*!40000 ALTER TABLE `Num_vms_off` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Num_vms_on`
--

DROP TABLE IF EXISTS `Num_vms_on`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Num_vms_on` (
  `idNum_vms_on` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Mes` varchar(45) character set latin1 default NULL,
  `Ano` int(11) default NULL,
  `Num_vms` int(11) default NULL,
  PRIMARY KEY  (`idNum_vms_on`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Num_vms_on`
--

LOCK TABLES `Num_vms_on` WRITE;
/*!40000 ALTER TABLE `Num_vms_on` DISABLE KEYS */;
INSERT INTO `Num_vms_on` VALUES ('2011-11-03 12:07:52','noviembre',2011,1272),('2012-03-28 12:09:01','marzo',2012,890),('2012-04-27 00:26:00','abril',2012,939);
/*!40000 ALTER TABLE `Num_vms_on` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Numero_Maximo_Elementos_Virtuales`
--

DROP TABLE IF EXISTS `Numero_Maximo_Elementos_Virtuales`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Numero_Maximo_Elementos_Virtuales` (
  `idNum_max_elementosvirtuales` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Numero_Maximo_Elementos_Virtuales` int(11) default NULL,
  PRIMARY KEY  (`idNum_max_elementosvirtuales`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Numero_Maximo_Elementos_Virtuales`
--

LOCK TABLES `Numero_Maximo_Elementos_Virtuales` WRITE;
/*!40000 ALTER TABLE `Numero_Maximo_Elementos_Virtuales` DISABLE KEYS */;
INSERT INTO `Numero_Maximo_Elementos_Virtuales` VALUES ('2012-04-11 09:27:49',1443);
/*!40000 ALTER TABLE `Numero_Maximo_Elementos_Virtuales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OTROS_ELEMENTOS`
--

DROP TABLE IF EXISTS `OTROS_ELEMENTOS`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `OTROS_ELEMENTOS` (
  `idOTROS_ELEMENTOS` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Mes` varchar(45) character set latin1 default NULL,
  `Año` int(11) default NULL,
  `Num_otros_elem` int(11) default NULL,
  PRIMARY KEY  (`idOTROS_ELEMENTOS`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `OTROS_ELEMENTOS`
--

LOCK TABLES `OTROS_ELEMENTOS` WRITE;
/*!40000 ALTER TABLE `OTROS_ELEMENTOS` DISABLE KEYS */;
INSERT INTO `OTROS_ELEMENTOS` VALUES ('2011-11-03 10:12:35','noviembre',2011,0);
/*!40000 ALTER TABLE `OTROS_ELEMENTOS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Ratio_mem_vms_mem_ESX`
--

DROP TABLE IF EXISTS `Ratio_mem_vms_mem_ESX`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Ratio_mem_vms_mem_ESX` (
  `idRatio_mem_vms_mem_ESX` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Mes` varchar(45) character set latin1 default NULL,
  `Ano` int(11) default NULL,
  `mem_total_vms` int(11) default NULL,
  `mem_total_ESX` int(11) default NULL,
  `Ratio_mem_vms_por_mem_ESX` float default NULL,
  PRIMARY KEY  (`idRatio_mem_vms_mem_ESX`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Ratio_mem_vms_mem_ESX`
--

LOCK TABLES `Ratio_mem_vms_mem_ESX` WRITE;
/*!40000 ALTER TABLE `Ratio_mem_vms_mem_ESX` DISABLE KEYS */;
INSERT INTO `Ratio_mem_vms_mem_ESX` VALUES ('2012-02-29 07:35:55','febrero',2012,2698,4068,66.3149),('2012-03-28 12:09:01','marzo',2012,2852,4068,70.1019),('2012-04-27 00:26:00','abril',2012,3964,5252,75.4794);
/*!40000 ALTER TABLE `Ratio_mem_vms_mem_ESX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Ratio_vcpus_por_core`
--

DROP TABLE IF EXISTS `Ratio_vcpus_por_core`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Ratio_vcpus_por_core` (
  `idRatio_vcpus_por_core` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Mes` varchar(45) character set latin1 default NULL,
  `Ano` int(11) default NULL,
  `vcpus` int(11) default NULL,
  `cores` int(11) default NULL,
  `Ratio_vcpus_por_core` float default NULL,
  PRIMARY KEY  (`idRatio_vcpus_por_core`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Ratio_vcpus_por_core`
--

LOCK TABLES `Ratio_vcpus_por_core` WRITE;
/*!40000 ALTER TABLE `Ratio_vcpus_por_core` DISABLE KEYS */;
INSERT INTO `Ratio_vcpus_por_core` VALUES ('2012-02-28 19:35:38','febrero',2012,2052,616,NULL),('2012-03-28 12:09:01','marzo',2012,2200,616,NULL),('2012-04-27 00:26:00','abril',2012,2680,808,331.683);
/*!40000 ALTER TABLE `Ratio_vcpus_por_core` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Sistema_operativo`
--

DROP TABLE IF EXISTS `Sistema_operativo`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Sistema_operativo` (
  `idSistema_operativo` int(11) NOT NULL,
  `Nombre_Sistema_Operativo` varchar(45) character set latin1 default NULL,
  PRIMARY KEY  (`idSistema_operativo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Sistema_operativo`
--

LOCK TABLES `Sistema_operativo` WRITE;
/*!40000 ALTER TABLE `Sistema_operativo` DISABLE KEYS */;
INSERT INTO `Sistema_operativo` VALUES (1,'Windows Escritorios'),(2,'Windows Server'),(3,'Linux'),(4,'Solaris'),(5,'Other'),(6,'Resto');
/*!40000 ALTER TABLE `Sistema_operativo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tipo_elemento`
--

DROP TABLE IF EXISTS `Tipo_elemento`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `Tipo_elemento` (
  `idTipo_elemento` int(11) NOT NULL,
  `Tipo_Elemento` varchar(45) character set latin1 default NULL,
  PRIMARY KEY  (`idTipo_elemento`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `Tipo_elemento`
--

LOCK TABLES `Tipo_elemento` WRITE;
/*!40000 ALTER TABLE `Tipo_elemento` DISABLE KEYS */;
INSERT INTO `Tipo_elemento` VALUES (1,'VM encendida'),(2,'VM registrada'),(3,'ELEMENTO_REGISTRADO');
/*!40000 ALTER TABLE `Tipo_elemento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storage_instalado_vm`
--

DROP TABLE IF EXISTS `storage_instalado_vm`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `storage_instalado_vm` (
  `idMemoria_storage_instalado_vms` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Mes` varchar(45) character set latin1 default NULL,
  `Ano` int(11) default NULL,
  `Storage_Total` int(11) default NULL,
  `Storage_Instalado_Respaldo` int(11) default NULL,
  `Storage_Instalado_Escritorios` int(11) default NULL,
  `Storage_Instalado_Produccion_1` int(11) default NULL,
  `Storage_Instalado_Produccion_2` int(11) default NULL,
  `Storage_Instalado_Produccion_3` int(11) default NULL,
  `Storage_Instalado_Produccion_Backup` int(11) default NULL,
  `Storage_Instalado_Test_y_Preproduccion` int(11) default NULL,
  `Storage_Instalado_Integracion` int(11) default NULL,
  PRIMARY KEY  (`idMemoria_storage_instalado_vms`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `storage_instalado_vm`
--

LOCK TABLES `storage_instalado_vm` WRITE;
/*!40000 ALTER TABLE `storage_instalado_vm` DISABLE KEYS */;
/*!40000 ALTER TABLE `storage_instalado_vm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vcpus_por_vm_total_entorno`
--

DROP TABLE IF EXISTS `vcpus_por_vm_total_entorno`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `vcpus_por_vm_total_entorno` (
  `idvcpus_por_vm_total_entorno` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Mes` varchar(45) character set latin1 default NULL,
  `Ano` int(11) default NULL,
  `vcpus_por_vm_Total_entorno` int(11) default NULL,
  `vcpus_por_vm_total_Centro_Respaldo` int(11) default NULL,
  `vcpus_por_vm_total_Escritorios` int(11) default NULL,
  `vcpus_por_vm_total_Produccion_1` int(11) default NULL,
  `vcpus_por_vm_total_Produccion_2` int(11) default NULL,
  `vcpus_por_vm_total_Produccion_3` int(11) default NULL,
  `vcpus_por_vm_total_Produccion_Backup` int(11) default NULL,
  `vcpus_por_vm_total_Test_y_Preproduccion` int(11) default NULL,
  `vcpus_por_vm_total_Integracion` int(11) default NULL,
  PRIMARY KEY  (`idvcpus_por_vm_total_entorno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `vcpus_por_vm_total_entorno`
--

LOCK TABLES `vcpus_por_vm_total_entorno` WRITE;
/*!40000 ALTER TABLE `vcpus_por_vm_total_entorno` DISABLE KEYS */;
INSERT INTO `vcpus_por_vm_total_entorno` VALUES ('2012-02-28 13:38:03','febrero',2012,2052,105,494,356,199,230,36,621,11),('2012-03-28 12:09:01','marzo',2012,2200,105,551,362,212,232,131,594,13),('2012-04-27 00:26:00','abril',2012,2680,105,452,363,218,234,131,606,13);
/*!40000 ALTER TABLE `vcpus_por_vm_total_entorno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vms_total_entorno`
--

DROP TABLE IF EXISTS `vms_total_entorno`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `vms_total_entorno` (
  `idvms_total_entorno` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Mes` varchar(45) character set latin1 default NULL,
  `Ano` int(11) default NULL,
  `vms_Total_entorno` int(11) default NULL,
  `vms_total_Centro_Respaldo` int(11) default NULL,
  `vms_total_Escritorios` int(11) default NULL,
  `vms_total_Produccion_1` int(11) default NULL,
  `vms_total_Produccion_2` int(11) default NULL,
  `vms_total_Produccion_3` int(11) default NULL,
  `vms_total_Produccion_Backup` int(11) default NULL,
  `vms_total_Test_y_Preproduccion` int(11) default NULL,
  `vms_total_Integracion` int(11) default NULL,
  PRIMARY KEY  (`idvms_total_entorno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `vms_total_entorno`
--

LOCK TABLES `vms_total_entorno` WRITE;
/*!40000 ALTER TABLE `vms_total_entorno` DISABLE KEYS */;
INSERT INTO `vms_total_entorno` VALUES ('2012-02-23 18:54:30','febrero',2012,1204,54,329,220,98,131,21,351,0),('2012-03-28 12:09:01','marzo',2012,1274,59,348,226,104,133,61,338,5),('2012-04-27 00:26:00','abril',2012,1345,59,244,225,105,133,61,345,5);
/*!40000 ALTER TABLE `vms_total_entorno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `test`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `test` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `test`;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-05-03 10:51:08
