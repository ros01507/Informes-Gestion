
#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="PoolsNames_Escritorios";
# PERL MYSQL CONNECT()

my $lastlogin;
my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
my $dbi = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table( idPoolsNameEscritorios, PoolName, Escritorios, UltimoLogon) VALUES (?,?,?,?)");

open (INSERT, "input_poolsnums");

my $datos=0;

while(<INSERT>) {

$datos++;

chomp;

my ($Poolname, $Escritorios) = split /,/;

my $sti = $dbi->prepare( "select * from Pools_Sesiones_ALL where Poolname=" . "'" . $Poolname . "'"  . " order by LastTimeLoggedIn DESC limit 1");
$sti->execute;

while ( my @row = $sti->fetchrow_array( ) ) {

$lastlogin= $row[4];

                            }


$sth->execute($datos,$Poolname, $Escritorios, $lastlogin);
               };

close (INSERT);

$dbh->disconnect;

