
#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="Pools_Sesiones_ALL";

# PERL MYSQL CONNECT()

my $Idname;
my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
my $dbi = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table( idPools_sesiones_ALL, CurrentUser, VirtualMachineName, Poolname, LastTimeLoggedIn, idPoolNameEscritorio) VALUES (?,?,?,?,?,?)");
my $sti = $dbi->prepare( "SELECT * FROM PoolsNames_Escritorios");

open (INSERT, "input_sessions_all");

my $datos=0;

while(<INSERT>) {

$datos++;

chomp;

my ($CurrentUser, $VirtualMachineName, $Poolname, $LastTimeLoggedIn)= split /,/;
my $sti = $dbi->prepare( "SELECT * FROM PoolsNames_Escritorios");
$sti->execute;

while ( my @row = $sti->fetchrow_array( ) ) {

if ($row[1] eq $Poolname)  {

$Idname= $row[0];
last;}

                            }


$sth->execute($datos,$CurrentUser, $VirtualMachineName, $Poolname, $LastTimeLoggedIn, $Idname );
               };

close (INSERT);

$dbh->disconnect;

