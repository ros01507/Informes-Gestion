#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="Num_Sesiones_ultimo_mes";

# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table( idNum_Sesiones_ultimo_mes, CurrentUser, VirtualMachineName, Poolname) VALUES (?,?,?,?)");


open (INSERT, "input_sesiones_ultimo_mes");

my $datos=0;

while(<INSERT>) {

$datos++;

chomp;

my ($CurrentUser,$VirtualMachineName,$Poolname) = split /,/;
$sth->execute($datos,$CurrentUser,$VirtualMachineName,$Poolname);

               };

close (INSERT);

$dbh->disconnect;

