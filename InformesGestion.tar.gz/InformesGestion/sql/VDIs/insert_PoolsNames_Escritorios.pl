
#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="PoolsNames_Escritorios";

# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table(  idPoolsNameEscritorios, PoolName, Escritorios) VALUES (?,?,?)");


open (INSERT, "input_poolsnums");

my $datos=0;

while(<INSERT>) {

$datos++;

chomp;

my ($Poolname, $Escritorios) = split /,/;

$sth->execute($datos,$Poolname,$Escritorios);
               };

close (INSERT);

$dbh->disconnect;

