
#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="Pools_Sesiones_24";

# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);


$sth = $dbh->prepare("INSERT INTO $table( idPools_sesiones_24, CurrentUser, VirtualMachineName, Poolname, LastTimeLoggedIn) VALUES (?,?,?,?,?)");
$sth->execute( );


open (INSERT,"input_sessions_24");

my $datos=0;

while(<INSERT>) {

$datos++;

chomp;

my ($CurrentUser, $VirtualMachineName, $Poolname, $LastTimeLoggedIn)= split /,/;


$sth->execute($datos,$CurrentUser, $VirtualMachineName, $Poolname, $LastTimeLoggedIn);

               };

close (INSERT);

$dbh->disconnect;
