DELETE FROM VDIs;
DELETE FROM PoolsNames;
DELETE FROM PoolsNames_Escritorios;
DELETE FROM Pools_Sesiones_ALL;
DELETE FROM Pools_Sesiones_24;

