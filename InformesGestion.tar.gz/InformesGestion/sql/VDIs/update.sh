
cd /root/InformesGestion/sql/VDIs
mv -f /datos/usuarios/A163440/VDIs/*.csv .

### Formatea ficheros importados de SQL Reporting ###
sed 1d salida.csv | sed 1d | sed '$d'| sed '$d' | sed '/^$/d' > input_vdi 
sed 1d pools.csv | sed 1d | sed '$d'| sed '$d' | sed '/^$/d' > input_pools
sed 1d pools_nums.csv | sed 1d | sed '$d'| sed '$d' | sed '/^$/d' > input_poolsnums
sed 1d sessions_all.csv | sed 1d | sed '$d'| sed '$d' | sed '/^$/d' | sed -e 's/\.[0-9]*//g'| sed '/,NULL/d' > input_sessions_all
sed 1d sessions_24.csv | sed 1d | sed '$d'| sed '$d' | sed '/^$/d' | sed -e 's/\.[0-9]*//g' | sed '/,NULL/d' | sed '/,NULL/d' > input_sessions_24

### Borra registros de tablas ###

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion < borra_registros.sql

### Inserta valores en tablas ###

perl insert_vdi.pl
perl insert_poolnames.pl
perl insert_num_sess_pools.pl
perl insert_sesiones_ALL.pl
perl insert_sesiones_24.pl
perl insert_PoolsNames_Escritorios_lastlogin.pl




