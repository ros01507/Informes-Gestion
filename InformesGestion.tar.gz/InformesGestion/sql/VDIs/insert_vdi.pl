
#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="VDIs";

# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table(  id_VDIs, CurrentUser, VirtualMachineName , Poolname) VALUES (?,?,?,?)");


open (INSERT, "input_vdi");

my $datos=0;

while(<INSERT>) {

$datos++;

chomp;

my ($CurrentUser, $VirtualMachineName, $Poolname) = split /,/;

$sth->execute($datos,$CurrentUser,$VirtualMachineName,$Poolname);
               };

close (INSERT);

$dbh->disconnect;

