
#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="PoolsNames";

# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table( idPoolsName, PoolName) VALUES (?,?)");


open (INSERT, "input_pools");

my $datos=0;

while(<INSERT>) {

$datos++;

chomp $_;
chomp $datos;
$_=~ s/\r//g;

$sth->execute($datos,$_);
#print $datos . ";" . $_ . "\n";
               };

close (INSERT);

$dbh->disconnect;

