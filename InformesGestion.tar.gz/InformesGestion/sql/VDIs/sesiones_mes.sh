dos2unix sessions_ultimo_mes.csv
sed 1d sessions_ultimo_mes.csv | sed 1d | sed '$d'| sed '$d' | sed '/^$/d' > input_sesiones_ultimo_mes
perl insert_sesiones_ultimo_mes.pl
perl insert_poolnames_mes.pl
