FILENAME='vms_2'
count=0
IFS='
'
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select * from Clusters"
cat $FILENAME | while read LINE
do
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select Hostname,Cluster from Elementos_virtuales where Hostname LIKE '$LINE%' and Hostname NOT LIKE '%_replica'" 
#mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select Almacenamiento_instalado_GB from Elementos_virtuales where Hostname LIKE '$LINE%' and Hostname NOT LIKE '%_replica'"
    
done
