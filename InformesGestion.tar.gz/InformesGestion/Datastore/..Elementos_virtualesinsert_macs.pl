#/usr/bin/perl
use DBI;
# MYSQL CONFIG VARIABLES
my $host = "vlirompf.cm.es";
my $database = "Informes_Gestion";
my $user;
my $password;
my $table="Datastores";
my $clus;
my $cluster;


# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table( idDatastore, Nombre_datastore, Ocupacion_Percent, Cluster, Grupo_Almacenamiento, Capacidad_Datastore, Ocupado_Datastore, Libre_Datastore) VALUES (?,?,?,?,?,?,?,?)");

open (INSERT, "datos.txt");

 my $datos=0;

while(<INSERT>) {

 $datos++;

chomp;

my ($name,$ocup,$cls,$dts,$usado,$free) = split /,/;

# Clasificacion Grupos de Almacenamiento 

if ( $name =~ /^pro/ && $name=~ /clro01$/ ){$grupo=1;}  
elsif ($name =~ /^pro/ && $name=~ /clro02$/) {$grupo=2;}
elsif ( $name =~ /^pro/ && $name=~ /clro03$/) {$grupo=3;}
elsif ($name =~ /^cor/ && $name=~ /clcr01$/ ) {$grupo=4;}
elsif ($name =~ /^extfc/ && $name=~ /naro01$/ ) {$grupo=5;}
elsif ($name =~ /^prosa/ && $name=~ /naro01$/ ) {$grupo=6;}
elsif ($name =~ /^prosa/ && $name=~ /naro01-lab$/ ) {$grupo=7;}
elsif ( $name =~ /^tstsa/ && $name=~ /naro01$/) {$grupo=8;}
elsif ( $name =~ /^tst/ && $name=~ /clro02$/) {$grupo=9;}
elsif ( $name =~ /^tst/ && $name=~ /clro03$/) {$grupo=10;}
elsif ( $name =~ /^NFS/ && $name=~ /SATA$/) {$grupo=12;}
elsif ( $name =~ /^NFS/) {$grupo=11;}
elsif ($name =~ /DMX3/ || $name=~ /Desarrollo_Pool_b/ || $name=~ /Desarrollo_Test/) {$grupo=15;}
elsif ( $name =~ /^DMX800/) {$grupo=16;}
elsif ($name =~ /^Produccion_COR_DMX4/ ) {$grupo=17;}
elsif ($name =~ /DMX800/ ) {$grupo=18;}
elsif ($name =~ /DS8100/ ) {$grupo=19;}
elsif ($name =~ /DS8300/ ) {$grupo=22;}
elsif ( $name =~ /DMX2000/) {$grupo=20;}
elsif ( $name =~ /VMFS_NFS_HDS/) {$grupo=21;}
elsif ( $name =~ /^Desarrollo_Clariion_/ ){$grupo=14;}
elsif ( $name =~ /datastore/ || $name=~ /^Local/  ){$grupo=23;}
elsif ($name =~ /isos/ || $name=~ /templates/) {$grupo=24;}
elsif ($name =~ /^pross/ && $name=~ /naro01$/ ) {$grupo=25;}
elsif ($name =~ /TST_ROZ_VMAX3_SATA/ ) {$grupo=26;}
elsif ($name =~ /TST_COR_VMAX2_SATA/ ) {$grupo=27;}
elsif ($name =~ /Produccion_DS8300_Rozas/ ) {$grupo=28;}
elsif ($name =~ /Produccion_DS8100_COR/ ) {$grupo=29;}
elsif ($name =~ /PRO_ROZ_VMAX3_FC6/ ) {$grupo=30;}
elsif ($name =~ /PRO_COR_VMAX2_FC6/ ) {$grupo=31;}
elsif ($name =~ /DES_ROZ_VMAX3_SATA/ ) {$grupo=32;}
elsif ( $name =~ /^pro/ && $name=~ /svcro$/) {$grupo=33;}
elsif ( $name =~ /^cor/ && $name=~ /svc$/) {$grupo=34;}
elsif ( $name =~ /^pro3t.svc/ && $name=~ /ro$/) {$grupo=35;}
elsif ( $name =~ /^pro2t.svc/ && $name=~ /ro$/) {$grupo=36;}	
elsif ( $name =~ /^pro3t.svc/ && $name=~ /ro$/) {$grupo=37;}
elsif ( $name =~ /^pro2t.svc/ && $name=~ /ro$/) {$grupo=38;}
else {$grupo=13;}

# Clasificacion Cluster

if ( $cls =~ /CentroRespaldo_01/ ){$clus=1;}
elsif ( $cls =~ /Escritorios/ ) {$clus=2;}
elsif ( $cls =~ /Produccion_01/) {$clus=3;}
elsif ( $cls =~ /Produccion_02/ ) {$clus=4;}
elsif ( $cls =~ /Produccion_03/ ) {$clus=5;}
elsif ( $cls =~ /Produccion_Backup/ ) {$clus=6;}
elsif ( $cls =~ /Test_y_Preprod_01/ ) {$clus=7;}
elsif ( $cls =~ /Aranea_01/ ) {$clus=8;}
elsif ( $cls =~ /^Standalone/) {$clus=10;}
elsif ( $cls =~ /Produccion_04/ ) {$clus=11;}
elsif ( $cls =~ /CentroRespaldo_02/ ){$clus=12;}
elsif ( $cls =~ /Preproduccion/ ){$clus=13;}
elsif ( $cls =~ /Entorno_Test/ ){$clus=14;}
elsif ( $cls =~ /Test/ ){$clus=15;}
elsif ( $cls =~ /Produccion1/ ){$clus=16;}
elsif ( $cls =~ /Produccion2/ ){$clus=17;}
elsif ( $cls =~ /Desarrollo/ ){$clus=18;}
elsif ( $cls =~ /Escritorios01/){$clus=20;}
elsif ( $cls =~ /Pre-Produccion/ ){$clus=21;}
elsif ( $cls =~ /SQL_Produccion/ ){$clus=22;}
elsif ( $cls =~ /Pre-Dimensionamiento/ ){$clus=23;}
elsif ( $cls =~ /SQL_Previos/ ){$clus=24;}
elsif ( $cls  =~ /Escritorios_1/ ){$clus=27;}
elsif ( $cls  =~ /Escritorios_2/ ){$clus=28;}
elsif ( $cls  =~ /CentroRespaldo_03/ ){$clus=26;}
elsif ( $cls  =~ /CentroRespaldo_02/ ){$clus=12;}
else {$clus=9;}

$sth->execute( $datos,$name, $ocup, $clus, $grupo, $dts, $usado, $free);
               };

close (INSERT);

$dbh->disconnect;

# idDatastore
