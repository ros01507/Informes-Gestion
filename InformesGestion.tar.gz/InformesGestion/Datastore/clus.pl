#!/usr/bin/perl -w
#use locale;
use strict;
use warnings;
use Getopt::Long;
use VMware::VIRuntime;
use VMware::VILib;


		 
# validate options, and connect to the server
Opts::parse();
Opts::validate();
Util::connect();

my $capacity;
my $free;
my $ocupado;
my $capacidad;
my $esp_ocupado;

# Open file,

open (DATOS,">>datos.txt");

 my $clusters = Vim::find_entity_views (view_type => 'ClusterComputeResource');

foreach my $cluster (@$clusters) {
#   my $cpu = Vim::get_views (mo_ref_array => $cluster->summary);
    my $datastores = Vim::get_views (mo_ref_array => $cluster->datastore);
    foreach my $datastore (@$datastores) {
    
    if ($datastore->info->name !~ /Local/) {
#   effectiveCpu= $cpu->effectiveCpu;
    $capacity=$datastore->summary->capacity;
    $free=$datastore->info->freeSpace;
    if ($free eq 0 ) {$ocupado = 100} else {
   
    $esp_ocupado=($capacity-$free);
    $ocupado=$esp_ocupado;
    $ocupado=($ocupado*100)/$capacity;
    $ocupado=sprintf("%.2f",$ocupado);
                                     }
     $capacidad=($capacity/1073741824);
     $esp_ocupado=($esp_ocupado/1073741824);
     $free=($free/1024/1024);
     $free=sprintf("%.2f",$free);
     $esp_ocupado=sprintf("%.2f",$esp_ocupado);

     print DATOS $datastore->info->name . "," . $ocupado . "," . $cluster->name . "," . $capacidad . "," . $esp_ocupado . "," . $free . "\n";

                                           }
            }
            }
        print "\n";
close (DATOS);
Util::disconnect();

sub Fail {
    my ($msg) = @_;
    Util::disconnect();
    die ($msg);
    exit ();
}

