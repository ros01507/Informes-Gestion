#!/usr/bin/perl -w
use strict;
use warnings;
use Getopt::Long;
use VMware::VIRuntime;
use VMware::VILib;

$ENV{VI_SERVER}="v12kvcent.cm.es";
$ENV{VI_URL}="https://v12kvcent.cm.es/sdk/webService";

# validate options, and connect to the server
Opts::parse();
Opts::validate();
Util::connect();

open (DATOS,">>cluster");


my $clusters;
    $clusters = Vim::find_entity_views (view_type => 'ClusterComputeResource');
    Fail ("No clusters found.\n") unless (@$clusters);

foreach my $cluster (@$clusters) {

    my $hosts = Vim::get_views (mo_ref_array => $cluster->host);
#    print "Cluster: ", $cluster->name, "\n";
    foreach my $host (@$hosts) {
#      print "Host: ",  $host->summary->config->name, "\n";
 print DATOS $host->summary->config->name . "," . $cluster->name . "\n";                              }
      
    }
Util::disconnect();

sub Fail {
    my ($msg) = @_;
    Util::disconnect();
    die ($msg);
    exit ();
}

