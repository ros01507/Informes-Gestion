#!/usr/bin/perl
#
# Copyright 2006 VMware, Inc.  All rights reserved.
#

Opts::parse();
Opts::validate();


use VMware::VIRuntime;


Util::connect();

my $hostname;
my $numcores;
my $memory;
my $spd;
my $speed;
my $prf;
my $cpu_mhz;
my $cpu_cores;
my $cpu_install;

# Get all ESX objects

my $hosts = Vim::find_entity_views(view_type => 'HostSystem');

# Open file,

#open (DATOS,">>hypervisores");

foreach (@$hosts) {

$hostname= $_->summary->config->name;

my $memoryManager = Vim::get_views (mo_ref_array => $_->configManager->memoryManager);


foreach my $memoryManager(@$memoryManager) {

#$memoryreservedSC=$memoryManager->consoleReservationInfo->serviceConsoleReserved;
#$memoryreservedVM=$memoryManager->virtualMachineReservationInfo->virtualMachineReserved;
print $memoryManager . "\n";

                };


# print $hostname . "," . $memoryreservedSC . "," . $memoryreservedVM .  "\n";
# print DATOS $hostname . "," . $numcores . "," . $memory . "," . $speed . "," . $cpu_install .  "\n";

};

Util::disconnect();
