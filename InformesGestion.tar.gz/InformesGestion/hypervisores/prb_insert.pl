use warnings;
# no warnings 'numeric';
use Getopt::Long;
use VMware::VIRuntime;
use VMware::VILib;

# validate options, and connect to the server

open (INSERT, "hypervisoresF.txt");

while(<INSERT>) {

my ($hostname,$cores,$memoria,$redinst,$cpuinst,$perf_red,$perf_cpu,$perf_mem,$cluster) = split /,/;
if ($perf_mem ne "" ) {$perf_mem=$perf_mem/1024;} else {}
if (($perf_red=~/\d/) && ($num >= 0) && ($num < 10)) {$perf_red=$perf_red/1024;}


# Clasificacion ID Clusters

if ( $cluster =~ /CentroRespaldo_01/ ){$clus=1;}
elsif ( $cluster =~ /Escritorios/ ) {$clus=2;}
elsif ( $cluster =~ /Produccion_01/) {$clus=3;}
elsif ( $cluster =~ /Produccion_02/ ) {$clus=4;}
elsif ( $cluster =~ /Produccion_03/ ) {$clus=5;}
elsif ( $cluster =~ /Produccion_Backup/ ) {$clus=6;}
elsif ( $cluster =~ /Test_y_Preprod_01/ ) {$clus=7;}
elsif ( $cluster =~ /Aranea_01/ ) {$clus=8;}
elsif ( $cluster =~ /Produccion_04/ ) {$clus=11;}
elsif ( $cluster =~ /CentroRespaldo_02/ ) {$clus=12;}
elsif ( $cluster =~ /Preproduccion/ ) {$clus=13;}
elsif ( $cluster =~ /Entorno_Test/ ) {$clus=14;}
else {$clus=9;}

              
                };

close (INSERT);

