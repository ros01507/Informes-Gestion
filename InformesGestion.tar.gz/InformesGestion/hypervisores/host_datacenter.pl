
#!/usr/bin/perl -w

use warnings;
use VMware::VIRuntime;
 
Opts::parse();
Opts::validate();
Util::connect();
my ($host_views, $datacenter, $hostname);

my $datacenter_view = Vim::find_entity_views(view_type => 'Datacenter');
foreach (@$datacenter_view) 
{
     $datacenter = $_->name;
     $host_views = Vim::find_entity_views(
          view_type => 'HostSystem', begin_entity => $_
     );
     
     foreach (@$host_views) 
     {
          
               print $_->name . ";" . $datacenter . "\n";
              
               
          }
     }
Util::disconnect();
