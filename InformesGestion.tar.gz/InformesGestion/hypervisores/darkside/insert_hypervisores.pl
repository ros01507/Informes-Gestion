
#/usr/bin/perl
use strict;
use warnings;
use Getopt::Long;
use VMware::VIRuntime;
use VMware::VILib;

# validate options, and connect to the server
Opts::parse();
Opts::validate();
Util::connect();


use DBI;
# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $user;
my $password;
my $table="Hipervisores";
my $clus;
my $cluster;
my $sth;
my $datos=0;

# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table( IDHipervisores, Hostname, Num_cores, Memoria_Instalada_MB,Red_instalada_Gb,Red_consumida_Gb,CPU_consumida_Mhz,CPU_Instalada_Mhz,Memoria_Consumida_MB,IDCluster) VALUES (?,?,?,?,?,?,?,?,?,?)");

open (INSERT, "hypervisoresF.txt");

while(<INSERT>) {
$datos++;

my ($hostname,$cores,$memoria,$redinst,$cpuinst,$perf_red,$perf_cpu,$perf_mem,$cluster) = split /,/;

if ($perf_red ne "") {

$perf_red=($perf_red/1024/1024);}

if ($perf_mem ne "") {

$perf_mem=($perf_mem/1024);}


# Clasificacion ID Clusters

if ( $cluster =~ /CentroRespaldo_01/ ){$clus=1;}
elsif ( $cluster =~ /Escritorios/ ) {$clus=2;}
elsif ( $cluster =~ /Produccion_01/) {$clus=3;}
elsif ( $cluster =~ /Produccion_02/ ) {$clus=4;}
elsif ( $cluster =~ /Produccion_03/ ) {$clus=5;}
elsif ( $cluster =~ /Produccion_Backup/ ) {$clus=6;}
elsif ( $cluster =~ /Test_y_Preprod_01/ ) {$clus=7;}
elsif ( $cluster =~ /Aranea_01/ ) {$clus=8;}
else {$clus=9;}

$sth->execute( $datos, $hostname, $cores, $memoria, $redinst, $perf_red, $perf_cpu, $cpuinst, $perf_mem, $clus);
              
                };

close (INSERT);
Util::disconnect();
$dbh->disconnect;

