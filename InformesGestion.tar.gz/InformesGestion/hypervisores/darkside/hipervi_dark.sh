perl hostsystem.pl
perl perf.pl --countertype net --freq monthly >> perf_red
perl perf.pl --countertype cpu --freq monthly > perf_cpu
perl perf.pl --countertype mem --freq monthly > perf_mem
perl clus.pl
perl comb.pl
