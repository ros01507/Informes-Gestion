my $hostname;
my $prf;
my $consumo;
my $hst;
my $prfcpu;
my $prfmem;
my $memname;
my $prfred;
my $clus;
my $netperf;
my $perfomancered;
my $perfomancecpu;
my $perfomancememoria;
my $clustername;

open(HOST,"hypervisores");
open(PERFRED, "perf_red");
open(PERFMEM, "perf_mem");
open(PERFCPU, "perf_cpu");
open(CLUS, "cluster");
open(HYP,">>/root/InformesGestion/hypervisores/hypervisoresF.txt");

my @host=<HOST>;
my @perfred=<PERFRED>;
my @perfcpu=<PERFCPU>;
my @perfmem=<PERFMEM>;
my @perfclus=<CLUS>;


 foreach $hostname (@host) {
   
   chomp $hostname;

   $hst=substr($hostname,0,8);

 

 foreach $prfred (@perfred) {

#   chomp $prfred;

   ($redname,$perfomancered) = split(/,/,$prfred );
   
   $redname= substr($redname,0,8);
   
     
   if ($hst =~ m/$redname/) {last;}       

                            } 
chomp $perfomancered;

 foreach $prfcpu (@perfcpu) {

   ($cpuname,$perfomancecpu) = split(/,/,$prfcpu);
   
   $cpunme= substr($cpuname,0,8);

  
   if ($hst =~ m/$cpunme/)  {last;}

                            }
 chomp $perfomancecpu;
          
 foreach $prfmem (@perfmem) {

   ($memorianame,$perfomancememoria) = split(/,/,$prfmem);

   $memname=substr($memorianame,0,8);

   if ($hst =~ m/$memname/) {last;}
                            
                            } 
 chomp $perfomancememoria;


 foreach $clus (@perfclus) {

   chomp $clus;

   ($clusname,$clustername) = split(/,/,$clus );
   
   $clsname= substr($clusname,0,8);

  
   if ($hst =~ m/$clsname/) {last;}
   
                          }

print HYP $hostname . "," . $perfomancered . "," . $perfomancecpu ."," . $perfomancememoria . "," . $clustername . "\n";
    
   
                         }


close(HOST);
close(PERFCPU);
close (HYP);
close (PERFMEM);
close (PERFRED);
close (CLUS);

