my $hostname;
my $prf;
my $consumo;
my $hst;
my $prfcpu;
my $prfmem;
my $memname;
my $prfred;
my $clus;
my $netperf;
my $perfomancered;
my $perfomancecpu;
my $perfomancememoria;
my $clustername;

open(HOST,"hypervisores");

open(CLUS,">>cluster");

my @host=<HOST>;
my @clus=<CLUS>;


 foreach $hostname (@host) {
   
   chomp $hostname;

   $hst=substr($hostname,0,8);

 print CLUS $hst. "," . "standalone" . "\n";
                          }



close(HOST);
close (CLUS);

