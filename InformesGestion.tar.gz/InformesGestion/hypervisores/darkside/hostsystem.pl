#!/usr/bin/perl
#
# Copyright 2006 VMware, Inc.  All rights reserved.
#

use VMware::VIRuntime;

$ENV{VI_SERVER}="V12KVPPMM.grupo.cm.es";
$ENV{VI_URL}="https://V12KVPPMM.grupo.cm.es/sdk/webService";

Opts::parse();
Opts::validate();
Util::connect();

my $hostname;
my $numcores;
my $memory;
my $spd;
my $speed;
my $prf;
my $cpu_mhz;
my $cpu_cores;
my $cpu_install;

# Get all ESX objects

my $vm_viwewshosts = Vim::find_entity_views(view_type => 'HostSystem');

# Open file,

open (DATOS,">>hypervisores");

foreach (@$vm_viwewshosts) {


$hostname= $_->summary->config->name;
$numcores= $_->hardware->cpuInfo->numCpuCores;
$cpu_mhz= $_->hardware->cpuInfo->hz;
$cpu_cores= $_->hardware->cpuInfo->numCpuCores;
$cpu_install=(($cpu_mhz/1000000)*$cpu_cores);
$cpu_install= sprintf("%.2f",$cpu_install);
$memory= (($_->hardware->memorySize)/1048576);
$memory = sprintf("%.2f",$memory);
$spd= $_->config->network->pnic;
foreach (@$spd) {
  
	if ($_->linkSpeed ne "")  {
	$speed= ($_->linkSpeed->speedMb)+$speed;
                }
                };


 $speed=$speed/1000;

 print DATOS $hostname . "," . $numcores . "," . $memory . "," . $speed . "," . $cpu_install .  "\n";
 $speed = "";

};





# disconnect from the server

Util::disconnect();
close (DATOS);
