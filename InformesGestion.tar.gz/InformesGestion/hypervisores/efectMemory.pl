#!/usr/bin/perl

#
# Copyright 2006 VMware, Inc.  All rights reserved.
#

Opts::parse();
Opts::validate();


use VMware::VIRuntime;


Util::connect();

my $hostname;
my $numcores;
my $memory;
my $spd;
my $speed;
my $prf;
my $cpu_mhz;
my $cpu_cores;
my $cpu_install;
my $hostname;

# Get all ESX objects

my $ComputeResource = Vim::find_entity_views(view_type => 'ClusterComputeResource');

# Open file,

# open (DATOS,">>hypervisores");

foreach my $ComputeResource (@$ComputeResource) {

#    my $hosts = Vim::get_views (mo_ref_array => $ComputeResource->host);

#  foreach my $host (@$hosts) {
# $hostname= $host->summary->config->name;                              }




$efectiveMemory= $ComputeResource->summary->effectiveMemory;
$totalmemory=$ComputeResource->summary->totalMemory/1024/1024;
print " Name Cluster: " . $ComputeResource->name . " Memoria Total: " . $totalmemory . "MB  Memoria Efectiva: " . $efectiveMemory . "MB" . "\n";
print "\n";
};

# disconnect from the server
Util::disconnect();
close (DATOS);
