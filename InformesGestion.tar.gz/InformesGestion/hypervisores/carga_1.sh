echo "################################ GENERACION TABLA HIPERVISORES ###############################"


echo "## BORRADO DE FICHEROS DE DATOS##"

cd /root/InformesGestion/hypervisores/PF

rm -f hypervisores
rm -f perf_red
rm -f cluster
rm -f perf_cpu
rm -f perf_mem

cd /root/InformesGestion/hypervisores/darkside

rm -f hypervisores
rm -f perf_red
rm -f cluster
rm -f perf_cpu
rm -f perf_mem


cd /root/InformesGestion/hypervisores

rm -f hypervisores
rm -f perf_red
rm -f cluster
rm -f perf_cpu
rm -f perf_mem
rm -f hypervisoresF.txt


echo "## TOMA DE DATOS ##"

cd /root/InformesGestion/hypervisores

perl hostsystem.pl
perl perf.pl --countertype net --freq monthly > perf_red
perl prb_clus.pl
perl perf.pl --countertype cpu --freq monthly > perf_cpu
perl perf.pl --countertype mem --freq monthly > perf_mem
perl comb.pl

cd /root/InformesGestion/hypervisores/darkside

perl hostsystem.pl
perl perf.pl --countertype net --freq monthly >> perf_red
perl perf.pl --countertype cpu --freq monthly > perf_cpu
perl perf.pl --countertype mem --freq monthly > perf_mem
perl clus.pl
perl comb.pl

cd /root/InformesGestion/hypervisores/PF

perl hostsystem.pl
perl perf.pl --countertype net --freq monthly >> perf_red
perl perf.pl --countertype cpu --freq monthly > perf_cpu
perl perf.pl --countertype mem --freq monthly > perf_mem
perl clus.pl
perl comb.pl

cd /root/InformesGestion/hypervisores
perl insert_hypervisores.pl
