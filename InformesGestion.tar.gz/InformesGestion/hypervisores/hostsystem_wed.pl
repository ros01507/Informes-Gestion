#!/usr/bin/perl -w
use VMware::VIRuntime;


Opts::parse();
Opts::validate();
Util::connect();

my $dc = "Produccion_01";

my $datacenter = Vim::find_entity_view ( view_type      => "Datacenter",
                                         filter         => { name => $dc },
                                    );

my $host = Vim::find_entity_views ( view_type       => "HostSystem",
                                   begin_entity    => $datacenter,
                                );
print $dc . "\n";

foreach my $host ( @$host )
{


    print $host->name."\n";
}
Util::disconnect();
