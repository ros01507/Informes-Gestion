#!/usr/bin/perl -w

use strict;
use warnings;

use VMware::VIRuntime;
use VMware::VILib;

Opts::parse();
Opts::validate();

Util::connect();

open (VMs, "vmachines");

while (<VMs>) {


my $vm_name = $_;
chomp $vm_name;
my $newName = substr($vm_name,0,8);
my $vm_view = Vim::find_entity_view(view_type => 'VirtualMachine', 
                                    filter => {'name' => "$vm_name"});
Fail ("Virtual Machine $vm_name was not found.\n") unless ($vm_view);


my $virtualMachineConfigSpec = VirtualMachineConfigSpec->new (
                                 name => $newName);
print "Changing $vm_name to $newName\n";
eval {
    $vm_view->ReconfigVM( spec => $virtualMachineConfigSpec);
    };
if ($@) {
    print "Reconfiguration failed.\n $@";
    }
else {
    print "Virtual Machine name was changed.\n";
    }

# logout
           };
close(VMs);
Util::disconnect();
 
             

sub Fail {
    my ($msg) = @_;
    Util::disconnect();
    die ($msg);
    exit ();
}


