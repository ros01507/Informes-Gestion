DELETE FROM Campos_Notes;
