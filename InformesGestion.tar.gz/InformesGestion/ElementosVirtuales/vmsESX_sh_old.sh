###### GENERACION FICHEROS vms_Esx #########

cd /root/InformesGestion/ElementosVirtuales
rm -f vms_Esx.txt
perl vms_Esx.pl
rm -f /root/InformesGestion/ElementosVirtuales/locales/vms_Esx.txt
cp  vms_Esx.txt /root/InformesGestion/ElementosVirtuales/locales
cd darkside
perl vms_Esx_dark.pl

cd ..
cd PF

perl vms_Esx_PF.pl

###### BORRADO TABLA CAMPOS NOTES  ######

cd ..

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion < delVirtualesESX.sql


##### INTRODUCIMOS DATOS EN TABLA ####

perl insert_Vms_ESX.pl
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion < /root/InformesGestion/sql/borra_Locales_PendientesMigrar.sql
cd /root/InformesGestion/ElementosVirtuales/locales
perl insert_table_locales.pl
