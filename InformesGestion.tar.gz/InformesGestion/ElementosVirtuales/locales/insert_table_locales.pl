#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="Locales_PendientesMigrar";
my $infra;

# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
my $dbi = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table( idLocales_PendientesMigrar, Nombre_VM, Servicio, Responsable, Peticionario,DireccionIP,Entorno) VALUES (?,?,?,?,?,?,?)");

open (INSERT, "vms_Esx.txt");

my $datos=0;
print "#### MAQUINAS DE LAS QUE NO SON RESPONSABLES PPLL ####" . "\n";
while(<INSERT>) {

chomp;

my ($name,$path,$pws,$clus,$esx,$srv,$responsable,$pet,$alta,$vcenter,$dir,$entorno) = split /;/;
my @soTable="";

$sti = $dbi->prepare("SELECT * FROM Maquinas_PPLL WHERE SERVIDOR='$name'");
$sti->execute( );

@soTable = $sti->fetchrow_array( );

if ($soTable[1] ne "") {
$datos++;

$sth->execute( $datos, $name, $srv, $responsable, $pet,$dir,$entorno); 
                     }

else {print $name . "\n";}

$sti->finish( );
}
close (INSERT);

$dbh->disconnect;
$dbi->disconnect;


