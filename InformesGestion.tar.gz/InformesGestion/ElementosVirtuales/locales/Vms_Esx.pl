#!/usr/bin/perl

# Copyright 2006 VMware, Inc.  All rights reserved.
#

use strict;

use encoding "ISO-8859-1";
#use encoding "utf-8";

Opts::parse();
Opts::validate();


use VMware::VIRuntime;

my $so;
my $vcpu;
my $memoria;
my $totaldisk;
my @vmname;
my $hostname;
# my @datos;
my $vmname;
my $vmtype;
my $powerstate;
my $devices;
my $vmnme;
my $toolstatus;
my $name;
my $esxName;
my $key;
my $value;
my $pathvm;
my $alta;


Util::connect();

# Open file,

open (DATOS,">>vms_Esx.txt");

my $cluster_views = Vim::find_entity_views(view_type => 'ClusterComputeResource');

foreach my $clus (@$cluster_views) {
    my $cluster_name=$clus->name;
    
my $host_views = Vim::find_entity_views(view_type => 'HostSystem',
                                        begin_entity => $clus);

foreach my $host (@$host_views) {

$esxName=$host->summary->config->name;

# get views of all VM's.
my $vm_views = Vim::find_entity_views(view_type => 'VirtualMachine',
                                      begin_entity => $host);

foreach (@$vm_views) {


if (!defined ($_->config->name)) {next}
my $aplicacion=undef;
my $responsable=undef;
my $servicio=undef;
my $entorno=undef;
my $caducidad=undef;
my $peticionario=undef;
my $notes=undef;

	
# get Name to Virtual Machine      
          
   
         $vmnme = $_->config->name;                      
         my $template= $_->summary->config->template;
          @vmname = split(/\s+/,$vmnme);
          $vmname= $vmname[0];
  
    
     
# get vcpu, memory, Disk Capacity
     
    $so= $_->config->guestFullName;
    $vcpu= $_->config->hardware->numCPU;
    $memoria= $_->config->hardware->memoryMB;
    $devices = $_->config->hardware->device;
    $powerstate= $_->runtime->powerState->val;      
    $hostname= $_->summary->guest->hostName;
    my $custom= $_->summary->customValue;
    $pathvm= $_->summary->config->vmPathName;



foreach my $customflds (@$custom) {
  
  $key = $customflds->key;
  $value = $customflds->value;

if ($key eq "1") {chomp($responsable=$value);}
elsif ($key eq "207") {chomp($aplicacion=$value);}
elsif ($key eq "102") {chomp($servicio=$value);}
elsif ($key eq "103") {chomp($entorno=$value);}
elsif ($key eq "205") {chomp($caducidad=$value);}
elsif ($key eq "105") {chomp($peticionario=$value);}
elsif ($key eq "509") {chomp($alta=$value);}


else {}

 };
           


      
      
# Print in to file, Hostname o Vmname, vcpu, memory, Capacity Disk.
             # binmode(STDOUT, ":utf8");   

	      print DATOS  $vmnme . ";" . $pathvm . ";" . $powerstate . ";" . $cluster_name . ";" . $esxName . ";" . $servicio . ";" . $responsable . ";" . $peticionario . ";" . $alta . ";" . "vcentdpl.cm.es" . "\n";


};
};
};
Util::disconnect();

close (DATOS);


                                
