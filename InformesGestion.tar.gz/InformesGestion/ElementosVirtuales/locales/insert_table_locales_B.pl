
#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="Locales_PendientesMigrar";
my $infra;

# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
my $dbi = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
my $dbj = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table( idLocales_PendientesMigrar, Nombre_VM, Servicio, Responsable, Peticionario,DireccionIP,Entorno) VALUES (?,?,?,?,?,?,?)");

open (INSERT, "vms_Esx.txt");

my $datos=0;
#print "#### MAQUINAS DE LAS QUE NO SON RESPONSABLES PPLL ####" . "\n";
while(<INSERT>) {

chomp;

my ($name,$path,$pws,$clus,$esx,$srv,$responsable,$pet,$alta,$vcenter,$dir,$entorno) = split /;/;

$name=substr($name,0,14);
# print $name . "\n";
my @soTable="";

$sti = $dbi->prepare("SELECT * FROM Maquinas_PPLL WHERE SERVIDOR LIKE '$name%'");
$sti->execute( );

$stj = $dbj->prepare("SELECT * FROM x86_imagenes WHERE hostname LIKE '$name%'");
$stj->execute( );

@soTable = $sti->fetchrow_array( );
@soTable86 = $stj->fetchrow_array( );

if (($soTable[1] ne "") || ($soTable86[2] ne "") && ($name != /replica$/)){
$datos++;

$sth->execute( $datos, $name, $srv, $responsable, $pet,$dir,$entorno); 
                     }

else {}

$sti->finish( );
$stj->finish( );
}
close (INSERT);

$dbh->disconnect;
$dbi->disconnect;
$dbj->disconnect;


