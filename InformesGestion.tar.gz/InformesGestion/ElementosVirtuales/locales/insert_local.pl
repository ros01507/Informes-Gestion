
#/usr/bin/perl
use DBI;
binmode(STDOUT, ":utf8");
# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="Maquinas_PPLL";


# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table( idMaquinas_PPLL,SERVIDOR) VALUES (?,?)");

open (INSERT, "locales.txt");

my $datos=1800;

while(<INSERT>) {

$datos++;

chomp;



$sth->execute($datos,$_);
               };

close (INSERT);

$dbh->disconnect;
