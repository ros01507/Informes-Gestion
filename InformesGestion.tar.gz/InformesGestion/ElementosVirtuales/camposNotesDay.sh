

####### GENERACION FICHEROS CAMPO NOTES #########


cd /root/InformesGestion/ElementosVirtuales
rm -f annotations
perl CamposNotes.pl > annotations
cd darkside
perl CamposNotesDark.pl >> ../annotations
cd ..
cd PF
perl CamposNotesPF.pl  >> ../annotations
cd ..

###### BORRADO TABLA CAMPOS NOTES  ######

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion < delCamposNotes.sql


##### INTRODUCIMOS DATOS EN TABLA ####

perl insert_Campos_Notes.pl



