#!/usr/bin/perl -w
# Permission Export Utility v1.0
# Contribution by: Karl Rumelhart (krumelhart@vmware.com)
#
# For each for each type of managed entity, HostSystem, VirtualMachine, Datacenter,
# Folder, ComputeResource (i.e. host or cluster), and ResourcePool, this script
# retrieves all objects of that type and then all permissions that are set on the
# objects. It prints out the Object Type, Object Name, User/Group, and Role in comma
# separated value format. This can be piped to a file (.> foo.csv. in windows) and
# opened with Excel.
# Version History:
# V1.00 - (22 Dec 2006)
use strict;
use Getopt::Long;
use VMware::VIRuntime;
my %opts = (service_url => undef,
	    userid => undef,
	    password => undef);
GetOptions (\%opts,
	    "service_url=s",
	    "userid=s",
	    "password=s");

if( !defined ($opts{service_url} && $opts{userid} && $opts{password} ) ) {
    help();
    exit (1);
}

# login
Vim::login(service_url => $opts{service_url}, user_name => $opts{userid}, password => $opts{password});

# the authorization manager is the key to getting permission info
my $auth_mgr = Vim::get_view(mo_ref => Vim::get_service_content()->authorizationManager);
# Get all roles and put them in a hash so we can easily get the name corresponding to
# a roleId
my %role_hash;
my $role_list = $auth_mgr->roleList;
foreach (@$role_list) {
    $role_hash{$_->roleId} = $_->name;
}
# Heading for csv columns
print "Object Type, Object Name, User/Group, Role\n";
# for each type of managed entity run through all objects of that type and all
# permissions defined on that object and print out the corresponding Object Type,
# Object Name, User/Group, Role
my @obj_types = ("HostSystem", "VirtualMachine", "Datacenter", "Folder", \
		 "ComputeResource", "ResourcePool");
foreach my $this_type (@obj_types){
    my $obj_views = Vim::find_entity_views(view_type => $this_type);
    foreach (@$obj_views) {
	my $obj_name = $_->name;
	my $perm_array = $auth_mgr->RetrieveEntityPermissions(entity => $_, inherited => 1);
	foreach(@$perm_array) {
# print object type and name
	    print $this_type . ", " . $obj_name . ", ";
# print user/group and role
	    print $_->principal . ", " . $role_hash{$_->roleId} . "\n";
	}
    }
}
# logout
Vim::logout();

sub help {
    my $help_text = <<END;
  USAGE:
    printperms.pl --service_url <SDK service URL> --userid <VC user login> --password <VC password>
      Example:
	perl printperms.pl --service_url https://localhost/sdk/vimService --userid
	administrator --password mypassword
	The output will be in csv format. Pipe to a file to open with Excel.
END
print $help_text;
}
