##http://www.domain.com/cgi-bin/ip.cgi##
#!/usr/local/bin/perl

$name = "s8kvcent";
$n = `nslookup $name | grep Address`; chop($n);
$Dir = substr($n, rindex($n, " ")+1); 

print "IP: " . $Dir  . "\n";
exit;


