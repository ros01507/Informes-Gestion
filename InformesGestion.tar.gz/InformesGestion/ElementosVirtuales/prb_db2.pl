#!/usr/bin/perl

# $Id: test.pl,v 11.7 2004/02/01 11:16:16 timbo Exp $
#
# Copyright (c) 1994-1998 Tim Bunce
#
# See COPYRIGHT section in DBI.pm for usage and distribution rights.


# This is now mostly an empty shell I experiment with.
# The real tests have moved to t/*.t
# See t/*.t for more detailed tests.


#use DBI;

use DBI::DBD;   # simple test to make sure it's okay

use Config;
use Getopt::Long;
use strict;

#use DBI;
#use DBD::DB2::Constants;
use DBD::DB2;

#system ". /home/db2inst1/sqllib/db2profile";

#system "env > /tmp/env.txt";
#system "export DB2INSTANCE=db2inst1";

#$dbh = DBI->connect("dbi:DB2:db_name", $username, $password);
#$dbh = DBI->connect("dbi:DB2:DBNIAA01", "db2inst1", "eriver96");
#my $string="DBNIAA01";
my $string="dbi:DB2:B01PORT_DESA";
#my $string="dbi:DB2:DBMSDATA";
my $user="appuser";
my $pass="";
my $db="B01PORT_DESA";
my $hostname="10.102.101.14";
my $port="50000";
#my $string = "dbi:DB2:DATABASE=$db; HOSTNAME=$hostname; PORT=$port;
#PROTOCOL=TCPIP; UID=$user; PWD=$pass;";
my $dbh = DBI->connect($string, $user, $pass) || die "Connection failed with
 error: $DBI::errstr";

if (!defined($dbh)) {
print "Crap, am exiting ??? \n";
exit; }

#my $stmt = "select current timestamp from sysibm.sysdummy1;";
#my $stmt = "select * from nia.mstr_config;";
#my $sth = $dbh->prepare($stmt);
#$sth->execute();

#while( my @array = $sth->fetchrow_array ) {
# print "$array[0]\n";
#}
#print "$string\n";
#my $dbh = DBI->connect($string, $user, $pass) || die "Connection failed wit
#h error: $DBI::errstr";

#$sth->finish();
  $dbh->disconnect();
