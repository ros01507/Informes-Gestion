
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion <  /root/InformesGestion/sql/borra_elvirtuales.sql

cd /root/InformesGestion/ElementosVirtuales
rm -f datos.txt
rm -f perf_cpu
rm -f perf_mem
rm -f virtualesF
rm -f annotations

cd /root/InformesGestion/ElementosVirtuales/PF

rm -f datos.txt
rm -f perf_cpu
rm -f perf_mem
rm -f perf_overhead

cd /root/InformesGestion/ElementosVirtuales/darkside

rm -f datos.txt
rm -f perf_cpu
rm -f perf_mem
rm -f perf_overhead


cd /root/InformesGestion/ElementosVirtuales

perl Elementos_virtuales.pl
perl perf.pl --countertype cpu --freq monthly --entity VirtualMachine > perf_cpu
perl perf.pl --countertype mem --freq monthly --entity VirtualMachine > perf_mem
perl  perf_overhead.pl --countertype mem --freq monthly --entity VirtualMachine > perf_overhead
perl comb.pl

cd /root/InformesGestion/ElementosVirtuales/PF

perl Elementos_virtuales_PF.pl
#perl perf.pl --countertype cpu --freq daily --entity VirtualMachine > perf_cpu
#perl perf.pl --countertype mem --freq daily --entity VirtualMachine > perf_mem
#perl perf_overhead.pl --countertype mem --freq daily --entity VirtualMachine > perf_overhead
perl comb.pl

cd /root/InformesGestion/ElementosVirtuales/darkside

perl Elementos_virtuales_dark.pl
perl perf.pl --countertype cpu --freq daily --entity VirtualMachine > perf_cpu
perl perf.pl --countertype mem --freq daily --entity VirtualMachine > perf_mem
perl perf_overhead.pl --countertype mem --freq daily --entity VirtualMachine > perf_overhead
perl comb.pl


cd /root/InformesGestion/ElementosVirtuales

perl insert_elementos_virtuales.pl
