
perl Elementos_virtuales_dark.pl

perl perf.pl --countertype cpu --freq monthly --entity VirtualMachine > perf_cpu

perl perf.pl --countertype mem --freq monthly --entity VirtualMachine > perf_mem

perl perf_overhead.pl --countertype mem --freq monthly --entity VirtualMachine > perf_overhead

perl comb.pl
