#!/usr/bin/perl

# Copyright 2006 VMware, Inc.  All rights reserved.
#

use strict;
use encoding "ISO-8859-1";
use VMware::VIRuntime;

$ENV{VI_SERVER}="s8krovc1.cm.es";
$ENV{VI_URL}="https://s8krovc1.cm.es/sdk/webService";

my $so;
my $vcpu;
my $memoria;
my $totaldisk;
my @vmname;
my $hostname;
# my @datos;
my $vmname;
my $vmtype;
my $powerstate;
my $devices;
my $vmnme;
my $toolstatus;
my $name;

Opts::parse();
Opts::validate();
Util::connect();

# Open file,

open (DATOS,">>datos.txt");

    
my $host_views = Vim::find_entity_views(view_type => 'HostSystem');

foreach my $host (@$host_views) {

# get views of all VM's.
my $vm_views = Vim::find_entity_views(view_type => 'VirtualMachine',
                                      begin_entity => $host);

foreach (@$vm_views) {

if (!defined ($_->config->name)) {next}
	
# get Name to Virtual Machine      
          
          $vmnme = $_->config->name;
         my $template= $_->summary->config->template;
          @vmname = split(/\s+/,$vmnme);
          $vmname= $vmname[0];
  
    
     
# get vcpu, memory, Disk Capacity
     
    $so= $_->config->guestFullName;
    $vcpu= $_->config->hardware->numCPU;
    $memoria= $_->config->hardware->memoryMB;
    $devices = $_->config->hardware->device;
    $powerstate= $_->runtime->powerState->val;
    
    if (defined ($_->summary->guest->toolsStatus)) { 
            $toolstatus= $_->summary->guest->toolsStatus->val;
                                                   }
    
    $hostname= $_->summary->guest->hostName;
    foreach my $device(@$devices) {
                if (($device->deviceInfo->label =~ m/Hard disk/)) {
                    my $capKB = $device->capacityInKB/1048576;
                    $totaldisk = ($totaldisk + $capKB);
                    $totaldisk = sprintf("%.2f",$totaldisk);
                 };
                                 
          };
    
     if (( $toolstatus =~ m/toolsOk/)&&( $so !~ /Other/)){
          
           $name=$hostname;
      } else {$name=$vmnme;}

      if ($powerstate =~ m/poweredOn/) {$vmtype=1;} elsif (($template eq "1")||($vmnme =~ m/^@/)||($vmnme =~ m/replica$/)){$vmtype=3;} elsif ($powerstate =~ m/poweredOff/){$vmtype=2;} else {}
      
# Print in to file, Hostname o Vmname, vcpu, memory, Capacity Disk.

	      print DATOS  $name . ";" . $vcpu . ";" . $memoria . ";"  . $totaldisk . ";" . $vmtype . ";" . $so . ";" . "standalone" .  "\n";
              ;
              # @datos="";
              $totaldisk="";  
             };

};
Util::disconnect();

close (DATOS);


                                
