#!/usr/bin/perl

# Copyright 2006 VMware, Inc.  All rights reserved.
#

use strict;
use encoding "ISO-8859-1";
use VMware::VIRuntime;

$ENV{VI_SERVER}="s8kvcent.cm.es";
$ENV{VI_URL}="https://s8kvcent.cm.es/sdk/webService";

print scalar localtime;

my $so;
my $vcpu;
my $memoria;
my $totaldisk;
my @vmname;
my $hostname;
# my @datos;
my $vmname;
my $vmtype;
my $powerstate;
my $devices;
my $vmnme;
my $toolstatus;
my $name;
my $esxname;
my $cluster_views;

Opts::parse();
Opts::validate();
Util::connect();

# Open file,

open (DATOS,">>datos.txt");

$cluster_views = Vim::find_entity_views(view_type => 'ClusterComputeResource');
unless (defined $cluster_views){
        die "No clusters found.\n";
}

my $host_views = Vim::find_entity_views(view_type => 'HostSystem');

foreach my $host (@$host_views) {

$esxname= $host->summary->config->name;

#####################################################################################################################################################xname= $_->summary->config->

#$cluster_views = Vim::find_entity_views(view_type => 'ClusterComputeResource');

my $found = 0;
my $foundCluster;
foreach(@$cluster_views) {
        my $clustername = $_->name;
        if($found eq 0) {
                my $hosts = Vim::get_views(mo_ref_array => $_->host);
                foreach(@$hosts) {
                        if($_->name eq $esxname) {
                                $found = 1;
                                $foundCluster = $clustername;
                                last;
                        }
                }
        }
}

if($found) {
#       print "VM: \"$vmname\" is located on Cluster: \"$foundCluster\"\n";
} else {
       $foundCluster = "standalone";
#      print "Unable to locate the cluster VM: \"$vmname\" is in\n";

}


######################################################################################################################################################


# get views of all VM's.
my $vm_views = Vim::find_entity_views(view_type => 'VirtualMachine',
                                      begin_entity => $host);

foreach (@$vm_views) {

if (!defined ($_->config->name)) {next}
	
# get Name to Virtual Machine      
          
          $vmnme = $_->config->name;
         my $template= $_->summary->config->template;
          @vmname = split(/\s+/,$vmnme);
          $vmname= $vmname[0];
  
    
     
# get vcpu, memory, Disk Capacity
     
    $so= $_->config->guestFullName;
    $vcpu= $_->config->hardware->numCPU;
    $memoria= $_->config->hardware->memoryMB;
    $devices = $_->config->hardware->device;
    $powerstate= $_->runtime->powerState->val;
    
    if (defined ($_->summary->guest->toolsStatus)) { 
            $toolstatus= $_->summary->guest->toolsStatus->val;
                                                   }
    
    $hostname= $_->summary->guest->hostName;
    foreach my $device(@$devices) {
                if (($device->deviceInfo->label =~ m/Hard disk/)) {
                    my $capKB = $device->capacityInKB/1048576;
                    $totaldisk = ($totaldisk + $capKB);
                    $totaldisk = sprintf("%.2f",$totaldisk);
                 };
                                 
          };
    
     if (( $toolstatus =~ m/toolsOk/)&&( $so !~ /Other/)){
          
           $name=$hostname;
      } else {$name=$vmnme;}


      if ($powerstate =~ m/poweredOn/) {$vmtype=1;} elsif (($template eq "1")||($vmnme =~ m/^@/)||($vmnme =~ m/replica$/)){$vmtype=3;} elsif ($powerstate =~ m/poweredOff/){$vmtype=2;} else {}
      
	      print DATOS  $name . ";" . $vcpu . ";" . $memoria . ";"  . $totaldisk . ";" . $vmtype . ";" . $so . ";" . $foundCluster .  "\n";
              ;
              # @datos="";
              $totaldisk="";  
             };

};
Util::disconnect();

close (DATOS);

print scalar localtime;


                                
