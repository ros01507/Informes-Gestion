#!/usr/bin/perl -w
# Original Author: stumpr (http://communities.vmware.com/message/1265766#1265766)

use strict;
use warnings;

use VMware::VIRuntime;

$ENV{VI_SERVER}="s8kvcent.cm.es";
$ENV{VI_URL}="https://s8kvcent.cm.es/sdk/webService";

Opts::parse();
Opts::validate();

Util::connect();

my ($datacenter_views, $vmFolder_view, $indent);

$indent = 0;

$datacenter_views = Vim::find_entity_views(
        view_type => 'Datacenter',
        properties => ["name", "vmFolder"],
);

foreach ( @{$datacenter_views} )
{

   if ( $_->name eq 'Bankia-PPMM' ) {

#       print "Datacenter: " . $_->name . "\n";

        TraverseFolder($_->vmFolder, $indent);
                                    
                                    }
}

sub TraverseFolder
{
        my ($entity_moref, $index) = @_;

        my ($num_entities, $entity_view, $child_view, $i, $mo);

        $index += 4;


        $entity_view = Vim::get_view(
                mo_ref => $entity_moref, properties => ['name', 'childEntity']
        );


        $num_entities = defined($entity_view->childEntity) ? @{$entity_view->childEntity} : 0;
        if ( $num_entities > 0 )
        {

                foreach $mo ( @{$entity_view->childEntity} )
                {
                        $child_view = Vim::get_view(
                                mo_ref => $mo, properties => ['name']
                        );

                        if ( $child_view->isa("VirtualMachine") )
                        {

                        if (  $child_view->name eq 'converter') {
                                print " " x $index . "Virtual Machine: " . $child_view->name . "\n" ;
                                                               } 
                        }

                        if ( $child_view->isa("Folder") )
                        {

                                if ($child_view->name eq 'Burbuja'){
                                print " " x $index . "Folder: " . $child_view->name . "\n";
                                print " " x $index . "Virtual Machine: " . $child_view->name . "\n" ;

                                                                          }
                                $child_view = Vim::get_view(
                                        mo_ref => $mo, properties => ['name', 'childEntity']
                                );

                                TraverseFolder($mo, $index);
                        }

                }
        }

}

Util::disconnect();

