#!/usr/bin/perl

# Copyright 2006 VMware, Inc.  All rights reserved.
#

use strict;
use encoding "ISO-8859-1";

$ENV{VI_SERVER}="V12KVPPMM.grupo.cm.es";
$ENV{VI_URL}="https://V12KVPPMM.grupo.cm.es/sdk/webService";

Opts::parse();
Opts::validate();


use VMware::VIRuntime;

my $so;
my $vcpu;
my $npcore;
my $memoria;
my $totaldisk;
my @vmname;
my $hostname;
# my @datos;
my $vmname;
my $vmtype;
my $powerstate;
my $devices;
my $vmnme;
my $toolstatus;
my $name;

Util::connect();

# Open file,

open (DATOS,">>datos.txt");

my $cluster_views = Vim::find_entity_views(view_type => 'ClusterComputeResource');

foreach my $clus (@$cluster_views) {
    my $cluster_name=$clus->name;
    
my $host_views = Vim::find_entity_views(view_type => 'HostSystem',
                                        begin_entity => $clus);

foreach my $host (@$host_views) {

# get views of all VM's.
my $vm_views = Vim::find_entity_views(view_type => 'VirtualMachine',
                                      begin_entity => $host);

foreach (@$vm_views) {

if (!defined ($_->config->name)) {next}
	
# get Name to Virtual Machine      
          
          $vmnme = $_->config->name;
         my $template= $_->summary->config->template;
          @vmname = split(/\s+/,$vmnme);
          $vmname= $vmname[0];
  
    
     
# get vcpu, memory, Disk Capacity
     
    $so= $_->config->guestFullName;
    $vcpu= $_->config->hardware->numCPU;
    $memoria= $_->config->hardware->memoryMB;
    $devices = $_->config->hardware->device;
    $powerstate= $_->runtime->powerState->val;
    
    if (defined ($_->summary->guest->toolsStatus)) { 
            $toolstatus= $_->summary->guest->toolsStatus->val;
                                                   }
    
    $hostname= $_->summary->guest->hostName;
    foreach my $device(@$devices) {
                if (($device->deviceInfo->label =~ m/Hard disk/)) {
                    my $capKB = $device->capacityInKB/1048576;
                    $totaldisk = ($totaldisk + $capKB);
                    $totaldisk = sprintf("%.2f",$totaldisk);
                 };
                                 
          };
    
#     if (( $toolstatus =~ m/toolsOk/)&&( $so !~ /Other/)&&( $name ne "")){
#if (length($hostname) >= 8) { 
#           $name=$hostname;
#      } else {$name=$vmnme;}

      if ($powerstate =~ m/poweredOn/) {$vmtype=1;} elsif (($template eq "1")||($vmnme =~ m/^@/)||($vmnme =~ m/replica$/)){$vmtype=3;} elsif ($powerstate =~ m/poweredOff/){$vmtype=2;} else {}
      
# Print in to file, Hostname o Vmname, vcpu, memory, Capacity Disk.
              binmode(STDOUT, ":utf8");   
	      print DATOS  $vmnme . ";" . $hostname . ";" . $vcpu . ";" . $memoria . ";"  . $totaldisk . ";" . $vmtype . ";" . $so . ";" . $cluster_name . ";" . $npcore . "\n";

              $totaldisk="";  
             };

};
};
Util::disconnect();

close (DATOS);


                                
