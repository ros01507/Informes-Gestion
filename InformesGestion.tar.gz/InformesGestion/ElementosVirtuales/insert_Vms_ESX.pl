
#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="Virtuales_ESX";
my $infra;

# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table( idVirtualesESX, Nombre_VM, Path_VMX, PowerState, Cluster, ESX, Servicio, Responsable, Peticionario, Alta, Vcenter, Infraestructura, Template) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");

open (INSERT, "vms_Esx.txt");

my $datos=0;

while(<INSERT>) {

$datos++;

chomp;

my ($name,$path,$pws,$clus,$esx,$srv,$responsable,$pet,$alta,$vcenter,$template) = split /;/;

if ($vcenter eq "v12kvcent.cm.es") {$infra="FlexSystem";}

else {$infra="Previo";}

$sth->execute( $datos, $name, $path, $pws, $clus, $esx, $srv, $responsable, $pet, $alta, $vcenter, $infra, $template);
               };

close (INSERT);

$dbh->disconnect;

