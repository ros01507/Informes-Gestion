-- MySQL dump 10.11
--
-- Host: vlirompf.cm.es    Database: Informes_Gestion
-- ------------------------------------------------------
-- Server version	5.0.77

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Capacidad_crecimiento_Memoria`
--

DROP TABLE IF EXISTS `Capacidad_crecimiento_Memoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Capacidad_crecimiento_Memoria` (
  `idCAP_crecimiento` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Mes` varchar(45) character set latin1 default NULL,
  `Ano` varchar(45) collate latin1_spanish_ci default NULL,
  `numero_vm_crecimiento_Memoria_Centro_Respaldo` int(11) default '0',
  `numero_vm_crecimiento_Memoria_Escritorios` int(11) default '0',
  `numero_vm_crecimiento_Memoria_Produccion_1` int(11) default '0',
  `numero_vm_crecimiento_Memoria_Produccion_2` int(11) default '0',
  `numero_vm_crecimiento_Memoria_Produccion_3` int(11) default '0',
  `numero_vm_crecimiento_Memoria_Produccion_Backup` int(11) default '0',
  `numero_vm_crecimiento_Memoria_Test_y_Preproduccion` int(11) default '0',
  `numero_vm_crecimiento_Memoria_Integracion` int(11) default '0',
  `numero_vm_crecimiento_Memoria_Produccion_4` int(11) default '0',
  `numero_vm_crecimiento_Memoria_Centro_Respaldo_02` int(11) default '0',
  `numero_vm_crecimiento_Memoria_Preproduccion` int(11) default '0',
  `numero_vm_crecimiento_Memoria_Entorno_Test` int(11) default '0',
  `numero_vm_crecimiento_Memoria_Test_PF` int(11) default '0',
  `numero_vm_crecimiento_Memoria_Produccion1_PF` int(11) default '0',
  `numero_vm_crecimiento_Memoria_Produccion2_PF` int(11) default '0',
  `numero_vm_crecimiento_Memoria_Desarrollo_PF` int(11) default '0',
  `numero_vm_crecimiento_Memoria_Escritorios_PF` int(11) default '0',
  `numero_vm_crecimiento_Memoria_Preproduccion_PF` int(11) default '0',
  PRIMARY KEY  (`idCAP_crecimiento`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Capacidad_crecimiento_Memoria`
--

LOCK TABLES `Capacidad_crecimiento_Memoria` WRITE;
/*!40000 ALTER TABLE `Capacidad_crecimiento_Memoria` DISABLE KEYS */;
INSERT INTO `Capacidad_crecimiento_Memoria` VALUES ('2012-07-30 08:33:24','Julio','2012',59,282,335,10,126,62,112,48,100,0,0,0,0,0,0,0,0,0),('2012-08-03 09:30:01','Agosto','2012',56,218,277,4,93,69,87,45,96,0,0,0,0,0,0,0,0,0),('2012-09-25 20:56:30','septiembre','2012',54,226,276,2,70,72,80,57,77,0,0,0,0,0,0,0,0,0),('2012-10-27 09:11:00','octubre','2012',43,189,289,1,68,100,60,56,61,0,0,0,0,0,0,0,0,0),('2012-11-27 10:08:28','noviembre','2012',40,271,271,4,53,90,106,44,61,0,0,0,0,0,0,0,0,0),('2012-12-27 10:08:15','diciembre','2012',40,305,267,21,48,81,126,38,60,0,0,0,0,0,0,0,0,0),('2013-01-27 10:07:52','enero','2013',40,317,264,23,42,27,165,43,43,0,0,0,0,0,0,0,0,0),('2013-02-27 10:09:59','febrero','2013',37,312,263,3,36,28,0,30,48,282,109,576,0,0,0,0,0,0),('2013-03-28 12:15:45','marzo','2013',33,373,272,2,35,27,0,37,49,228,80,658,0,0,0,0,0,0),('2013-04-28 08:00:51','abril','2013',31,411,264,18,33,25,0,31,47,183,5,537,0,0,0,0,0,0),('2013-05-27 20:44:55','mayo','2013',29,365,249,10,28,27,0,16,38,190,-13,424,0,0,0,0,0,0),('2013-06-29 22:34:09','junio','2013',41,373,306,8,28,32,0,-8,44,185,6,182,0,0,0,0,0,0),('2013-07-27 19:16:31','julio','2013',38,385,314,8,28,33,0,-11,53,296,3,86,0,0,0,0,0,0),('2013-08-27 19:18:47','agosto','2013',35,389,252,4,26,40,0,4,27,77,5,56,0,0,0,0,0,0),('2013-09-27 19:21:51','septiembre','2013',33,391,264,3,25,74,0,17,20,77,-31,191,0,0,0,0,0,0),('2013-10-27 20:21:08','octubre','2013',33,367,267,3,24,69,0,4,15,77,-28,93,0,0,0,0,0,0),('2013-11-27 20:29:25','noviembre','2013',32,379,203,-2,23,69,0,-18,13,76,-24,48,0,0,0,0,0,0),('2014-06-17 11:13:37','marzo','2014',28,322,217,3,15,66,0,-15,16,77,-13,545,124,3,0,0,0,0),('2014-06-17 11:17:05','diciembre','2013',32,374,221,0,18,67,0,-19,17,77,-21,38,1020,552,1077,1077,1077,192),('2014-06-17 11:17:15','enero','2014',31,377,201,-1,17,67,0,-18,11,77,-22,53,276,23,360,370,365,367),('2014-06-17 11:17:33','febrero','2014',28,354,222,-1,16,66,0,-16,16,77,-18,116,167,26,0,0,0,0),('2014-07-11 11:16:38','julio','2014',34,361,212,6,93,64,NULL,2,17,0,171,261,4,-7,22,21,NULL,NULL),('2014-07-11 11:18:41','Junio','2012',46,108,442,10,166,97,100,138,100,2,0,0,0,0,0,0,0,0),('2014-07-11 11:21:45','junio','2014',30,300,219,14,18,66,0,3,16,70,19,224,7,-3,0,23,0,0);
/*!40000 ALTER TABLE `Capacidad_crecimiento_Memoria` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-11 13:32:08
