FILENAME=vms
count=0
IFS='
'
cat $FILENAME | while read LINE
do

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select VMname,Almacenamiento_instalado_GB from Elementos_virtuales where VMname= '$LINE'"



done

