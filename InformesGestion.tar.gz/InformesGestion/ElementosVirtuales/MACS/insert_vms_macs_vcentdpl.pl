#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="VM_Macs_vcentdpl";
my $infra;

# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table( idVM_Macs_vcentdpl, VM, MAC,IP) VALUES (?,?,?,?)");

open (INSERT, "vms_mac_vcentdpl.csv");

my $datos=0;

while(<INSERT>) {

$datos++;

chomp;

my ($name,$mac,$ip) = split /;/;


$sth->execute( $datos, $name, $mac, $ip);
               };

close (INSERT);

$dbh->disconnect;

