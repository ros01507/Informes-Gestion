DELETE FROM Virtuales_ESX_anterior;
