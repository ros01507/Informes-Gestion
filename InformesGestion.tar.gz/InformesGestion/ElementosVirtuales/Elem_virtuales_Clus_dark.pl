#!/usr/bin/perl

# Copyright 2006 VMware, Inc.  All rights reserved.
#

use strict;
use encoding "ISO-8859-1";

$ENV{VI_SERVER}="V12KVPPMM.grupo.cm.es";
$ENV{VI_URL}="https://V12KVPPMM.grupo.cm.es/sdk/webService";

Opts::parse();
Opts::validate();

use VMware::VIRuntime;

my $hostname;
my $name;

Util::connect();

# Open file,

open (DATOS,">>datos_ESX_Clus.txt");

my $cluster_views = Vim::find_entity_views(view_type => 'ClusterComputeResource');

foreach my $clus (@$cluster_views) {
    my $cluster_name=$clus->name;
    
my $host_views = Vim::find_entity_views(view_type => 'HostSystem',
                                        begin_entity => $clus);

foreach my $host (@$host_views) {

$name=$host->summary->config->name;

# get views of all VM's.
my $vm_views = Vim::find_entity_views(view_type => 'VirtualMachine',
                                      begin_entity => $host);
    
	      print DATOS  $name . ";" . $cluster_name . "\n";


                               };
};

close (DATOS);


                                
