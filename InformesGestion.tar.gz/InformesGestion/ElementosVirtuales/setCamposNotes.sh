FILENAME=vms
count=0
IFS='
'
cat $FILENAME | while read LINE
do
       let count++
       printf "#### $LINE #### \n"
#      perl chgNotes.pl --fieldname Aplicacion --fieldvalue "Validacion Aplicaciones" --vmname $LINE
#      perl chgNotes.pl --fieldname Caducidad --fieldvalue "" --vmname $LINE
#      perl chgNotes.pl --fieldname Entorno --fieldvalue "Test" --vmname $LINE
#      perl chgNotes.pl --fieldname Causa --fieldvalue "Baja por fin de uso. Cambio 60875" --vmname $LINE
       perl chgNotes.pl --fieldname "Responsable" --fieldvalue "Jose Miguel Lopez Tomas" --vmname $LINE       
#      perl chgNotes.pl --fieldname "Servicio" --fieldvalue "Puesto virtual pruebas COR" --vmname $LINE
       perl chgNotes.pl --fieldname "Equipo Peticionario" --fieldvalue "Proceso" --vmname $LINE
       perl chgNotes.pl --fieldname "UR" --fieldvalue "S" --vmname $LINE
       perl chgNotes.pl --fieldname "Appliance" --fieldvalue "N" --vmname $LINE
#      perl chgNotes.pl --fieldname "Fecha_Alta" --fieldvalue "2013/06/30" --vmname $LINE
#      perl chgNotes.pl --fieldname "Fecha_Baja" --fieldvalue "2014/04/08" --vmname $LINE
done
