###### GENERACION FICHEROS vms_Esx #########

cd /root/InformesGestion/ElementosVirtuales

#####  CARGA DE DATOS A TABLA ANTERIOR ############

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion < delVirtualesESX_anterior.sql
perl insert_Vms_ESX_anterior.pl

####################################################
rm -f /root/InformesGestion/ElementosVirtuales/locales/vms_Esx.txt
rm -f vms_Esx.txt

perl vms_Esx.pl
cp  vms_Esx.txt /root/InformesGestion/ElementosVirtuales/locales

cd darkside
perl vms_Esx_dark.pl
cd ..

cd PF
perl vms_Esx_PF.pl
cd ..

##### INTRODUCIMOS DATOS EN TABLA ####

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion < delVirtualesESX.sql
perl insert_Vms_ESX.pl

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion < /root/InformesGestion/sql/borra_Locales_PendientesMigrar.sql
cd /root/InformesGestion/ElementosVirtuales/locales
perl insert_table_locales_B.pl
