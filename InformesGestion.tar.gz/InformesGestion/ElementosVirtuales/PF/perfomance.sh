#!/bin/bash
date
IFS=';'

while read f1 f2 f3 f4 f5 f6

do
       printf " Obteniendo datos de rendimiento de la máquina virtual $f1 ..... \n"
perl perf.pl --countertype cpu --freq dayly --entity VirtualMachine --name $f1 >> perf_cpu
perl perf.pl --countertype mem --freq dayly --entity VirtualMachine --name $f1 >> perf_mem
perl perf_overhead.pl --countertype mem --freq dayly --entity VirtualMachine --name $f1 >> perf_overhead

done < datos.txt
date
