foreach my $host (@$host_views) {

$esxName=$host->summary->config->name;

# get views of all VM's.
my $vm_views = Vim::find_entity_views(view_type => 'VirtualMachine',
                                      begin_entity => $host);



foreach my $clus (@$cluster_views) {
    my $cluster_name=$clus->name;
    
my $host_views = Vim::find_entity_views(view_type => 'HostSystem',
                                        name => $esxName);
if ( $host_views eq 'undef' ) {

                           my $cluster_name='standalone';

                              }
					  
my $cluster_name=$clus->name;
