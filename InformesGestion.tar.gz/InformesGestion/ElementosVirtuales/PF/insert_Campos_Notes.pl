
#/usr/bin/perl
use DBI;
binmode(STDOUT, ":utf8");
# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="Campos_Notes";


# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table( idNotes, Nombre_VM, Aplicacion, Servicio, Entorno, Caducidad, Peticionario, Responsable, Anotacion) VALUES (?,?,?,?,?,?,?,?,?)");

open (INSERT, "annotations");

my $datos=0;

while(<INSERT>) {

$datos++;

chomp;

my ($name,$apl,$srv,$entorno, $caducidad, $peticionario, $responsable, $anotacion) = split /;/;


$sth->execute( $datos, $name, $apl, $srv, $entorno, $caducidad, $peticionario, $responsable, $anotacion);
               };

close (INSERT);

$dbh->disconnect;

