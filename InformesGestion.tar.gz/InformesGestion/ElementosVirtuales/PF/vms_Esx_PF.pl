#!/usr/bin/perl

# Copyright 2006 VMware, Inc.  All rights reserved.
#

use strict;

use encoding "ISO-8859-1";
#use encoding "utf-8";

$ENV{VI_SERVER}="v12kvcent.cm.es";
$ENV{VI_URL}="https://v12kvcent.cm.es/sdk/webService";

Opts::parse();
Opts::validate();

use DBI;
use POSIX qw(strftime);
# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="Nodos_Cluster";
my $user;
my $password;
my $sth;
my $clusName;
# PERL MYSQL CONNECT)

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

use VMware::VIRuntime;

my $so;
my $vcpu;
my $memoria;
my $totaldisk;
my @vmname;
my $hostname;
# my @datos;
my $vmname;
my $vmtype;
my $powerstate;
my $devices;
my $vmnme;
my $toolstatus;
my $name;
my $esxName;
my $key;
my $value;
my $pathvm;
my $key_entorno;
my $key_responsable;
my $key_aplicacion;
my $key_causa;
my $key_servicio;
my $key_caducidad;
my $key_peticionario;
my $key_alta;

Util::connect();

#############################################

##### Obtenemos keys Notes #########

my $CustomFieldsManager = Vim::get_view( mo_ref => Vim::get_service_content()->customFieldsManager );

### Entorno ###

my $field_name= "Entorno";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_entorno=$field_key;

print $field_name . "es: " . $field_key . "\n";

### Responsable ###

my $field_name= "Responsable";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_responsable=$field_key;

print $field_name . "es: " . $field_key . "\n";

### Aplicacion ###

my $field_name= "Aplicacion";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_aplicacion=$field_key;

print $field_name . "es: " . $field_key . "\n";

### Causa ###

my $field_name= "Causa";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_causa=$field_key;

print $field_name . "es: " . $field_key . "\n";

### Servicio ###

my $field_name= "Servicio";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_servicio=$field_key;

print $field_name . "es: " . $field_key . "\n";

### Caducidad ###

my $field_name= "Caducidad";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_caducidad=$field_key;

print $field_name . "es: " . $field_key . "\n";

### Peticionario ###

my $field_name= "Equipo Peticionario";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_peticionario=$field_key;

print $field_name . " es: " . $field_key . "\n";

### Alta ###

my $field_name= "Fecha_Alta";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_alta=$field_key;

print $field_name . " es: " . $field_key . "\n";


# Open file,

open (DATOS,">>/root/InformesGestion/ElementosVirtuales/vms_Esx.txt");

    
my $host_views = Vim::find_entity_views(view_type => 'HostSystem');

foreach my $host (@$host_views) {

$esxName=$host->summary->config->name;

# get views of all VM's.
my $vm_views = Vim::find_entity_views(view_type => 'VirtualMachine',
                                      begin_entity => $host);

foreach (@$vm_views) {


if (!defined ($_->config->name)) {next}
my $aplicacion=undef;
my $responsable=undef;
my $servicio=undef;
my $entorno=undef;
my $caducidad=undef;
my $peticionario=undef;
my $notes=undef;
my $alta=undef;
	
# get Name to Virtual Machine      
          
   
         $vmnme = $_->config->name;                      
         my $template= $_->summary->config->template;
          @vmname = split(/\s+/,$vmnme);
          $vmname= $vmname[0];
  
    
     
# get vcpu, memory, Disk Capacity
     
    $so= $_->config->guestFullName;
    $vcpu= $_->config->hardware->numCPU;
    $memoria= $_->config->hardware->memoryMB;
    $devices = $_->config->hardware->device;
    $powerstate= $_->runtime->powerState->val;      
    $hostname= $_->summary->guest->hostName;
    my $custom= $_->summary->customValue;
    $pathvm= $_->summary->config->vmPathName;



foreach my $customflds (@$custom) {
  
  $key = $customflds->key;
  $value = $customflds->value;

if ($key eq $key_responsable) {chomp($responsable=$value);}
elsif ($key eq $key_aplicacion) {chomp($aplicacion=$value);}
elsif ($key eq $key_servicio) {chomp($servicio=$value);}
elsif ($key eq $key_entorno) {chomp($entorno=$value);}
elsif ($key eq $key_caducidad) {chomp($caducidad=$value);}
elsif ($key eq $key_peticionario) {chomp($peticionario=$value);}
elsif ($key eq $key_alta) {chomp($alta=$value);}
else {}

 };
      
      
# Print in to file, Hostname o Vmname, vcpu, memory, Capacity Disk.
             # binmode(STDOUT, ":utf8");   

$sth = $dbh->prepare("SELECT * FROM Nodos_Cluster where ESX_Name LIKE '$esxName'");
$sth->execute( );

my @x_86;

@x_86 = $sth->fetchrow_array;

if (($x_86[2] eq "") || ($x_86[2] eq "Migracion_EVC_M2")) {$clusName="standalone";} else {$clusName=$x_86[2];}


  print DATOS  $vmnme . ";" . $pathvm . ";" . $powerstate . ";" . $clusName . ";" . $esxName . ";" . $servicio . ";" . $responsable . ";" . $peticionario . ";" . $alta . ";" . $ENV{VI_SERVER} . ";" . $template . "\n";


};
};
$sth->finish( );
$dbh->disconnect;
close (DATOS);

sub FindCustomFieldKey {
     
     my ($cfm, $field_name) = @_;
     my ($field_key, @custom_fields);
     if ($cfm->field) {
          @custom_fields = @{$cfm->field};
     }
     else {
          # No custom fields defined, return undef
          return undef;
     }
     
     foreach my $field ( @custom_fields ) {
          if ($field->name eq $field_name) {
               $field_key = $field->key;
               last;
          }
     }
     
     # will be undef if no matching field to $field_name is found
     return $field_key;
}
                          
