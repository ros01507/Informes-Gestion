#!/usr/bin/perl

# Copyright 2006 VMware, Inc.  All rights reserved.
#

use strict;
use VMware::VIRuntime;
use encoding "ISO-8859-1";

$ENV{VI_SERVER}="v12kvcent.cm.es";
$ENV{VI_URL}="https://v12kvcent.cm.es/sdk/webService";

Opts::parse();
Opts::validate();

my $vmnme;
my @vmname;
my $vmname;
my $name;
my $hostname;
my $toolstatus;
my $so;
my $key_aplicacion;
my $key_servicio;
my $key_entorno;
my $key_caducidad;
my $key_peticionario;
my $aplicacion;
my $servicio;
my $entorno;
my $caducidad;
my $peticionario;

Util::connect();

#############################################

##### Obtenemos keys Notes #########

my $CustomFieldsManager = Vim::get_view( mo_ref => Vim::get_service_content()->customFieldsManager );

### Aplicacion ###

my $field_name= "Aplicacion";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_aplicacion=$field_key;

### Servicio ###

my $field_name= "Servicio";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_servicio=$field_key;

### Entorno ###

my $field_name= "Entorno";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_entorno=$field_key;

### Caducidad ###

my $field_name= "Caducidad";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_caducidad=$field_key;

### Peticionario ###

my $field_name= "Peticionario";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_peticionario=$field_key;

#############################################

my $vm_views = Vim::find_entity_views(view_type => 'VirtualMachine');

foreach (@$vm_views) {

if (!defined ($_->config->name)) {next}

my $aplicacion=undef;
my $responsable=undef;
my $servicio=undef;
my $entorno=undef;
my $caducidad=undef;
my $peticionario=undef;
my $notes="";
	
my $notes=$_->config->annotation;
$notes=~ s/(\r?\n)+/ /g;

my ($value, $key);
my $custom= $_->summary->customValue;
$name=$_->config->name;
$hostname= $_->summary->guest->hostName;

$vmnme = $_->config->name;
@vmname = split(/\s+/,$vmnme);
$vmname= $vmname[0];





if (defined ($_->summary->guest->toolsStatus)) {
            $toolstatus= $_->summary->guest->toolsStatus->val;
                                                   }

#if (( $toolstatus =~ m/toolsOk/)&&( $so !~ /Other/)&&( $hostname ne "")){
           
#if (length($hostname) >= 8) {
#$name=$hostname;
#      } else {$name=$vmnme;}


 foreach my $customflds (@$custom) {
  
  $key = $customflds->key;
  $value = $customflds->value;


if ($key eq $key_aplicacion) {chomp($aplicacion=$value);}
elsif ($key eq $key_servicio) {chomp($servicio=$value);}
elsif ($key eq $key_entorno) {chomp($entorno=$value);}
elsif ($key eq $key_caducidad) {chomp($caducidad=$value);}
elsif ($key eq $key_peticionario) {chomp($peticionario=$value);}
else {}

 }

binmode(STDOUT, ":utf8");

print $vmnme . ";" . $hostname . ";" . $aplicacion . ";" . $servicio . ";" . $entorno . ";" . $caducidad . ";" . $peticionario . ";" . $responsable . ";" . $notes . "\n";

}
    
Util::disconnect();

sub FindCustomFieldKey {

     my ($cfm, $field_name) = @_;
     my ($field_key, @custom_fields);
     if ($cfm->field) {
          @custom_fields = @{$cfm->field};
     }
     else {
          # No custom fields defined, return undef
          return undef;
     }

     foreach my $field ( @custom_fields ) {
          if ($field->name eq $field_name) {
               $field_key = $field->key;
               last;
          }
     }

     # will be undef if no matching field to $field_name is found
     return $field_key;
}



