#!/usr/bin/perl

# Copyright 2006 VMware, Inc.  All rights reserved.
#

use strict;
use encoding "ISO-8859-1";

use VMware::VIRuntime;

$ENV{VI_SERVER}="v12kvcent.cm.es";
$ENV{VI_URL}="https://v12kvcent.cm.es/sdk/webService";

Opts::parse();
Opts::validate();

use DBI;
use POSIX qw(strftime);
# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="Nodos_Cluster";
my $user;
my $password;
my $sth;
my $clusName;
# PERL MYSQL CONNECT)

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

my $so;
my $vcpu;
my $npcorecpu;
my $memoria;
my $totaldisk;
my @vmname;
my $hostname;
# my @datos;
my $vmname;
my $vmtype;
my $powerstate;
my $devices;
my $vmnme;
my $toolstatus;
my $name;
my $esxName;

Util::connect();

# Open file,

open (DATOS,">>datos.txt");

    
my $host_views = Vim::find_entity_views(view_type => 'HostSystem');

foreach my $host (@$host_views) {
$esxName=$host->summary->config->name;
# get views of all VM's.
my $vm_views = Vim::find_entity_views(view_type => 'VirtualMachine',
                                      begin_entity => $host);

foreach (@$vm_views) {

if (!defined ($_->config->name)) {next}
	
# get Name to Virtual Machine      
          
          $vmnme = $_->config->name;
         my $template= $_->summary->config->template;
          @vmname = split(/\s+/,$vmnme);
          $vmname= $vmname[0];
  
    
     
# get vcpu, memory, Disk Capacity
     
    $so= $_->config->guestFullName;
    $vcpu= $_->config->hardware->numCPU;
    $npcorecpu= $_->config->hardware->numCoresPerSocket;
    $memoria= $_->config->hardware->memoryMB;
    $devices = $_->config->hardware->device;
    $powerstate= $_->runtime->powerState->val;
    
    if (defined ($_->summary->guest->toolsStatus)) { 
            $toolstatus= $_->summary->guest->toolsStatus->val;
                                                   }
    
    $hostname= $_->summary->guest->hostName;
    foreach my $device(@$devices) {
                if (($device->deviceInfo->label =~ m/Hard disk/)) {
                    my $capKB = $device->capacityInKB/1048576;
                    $totaldisk = ($totaldisk + $capKB);
                    $totaldisk = sprintf("%.2f",$totaldisk);
                 };
                                 
          };
    
#    if (( $toolstatus =~ m/toolsOk/)&&( $so !~ /Other/)&&( $name ne "")){
#        if (length($hostname) >= 8) {
#           $name=$hostname;
#      } else {$name=$vmnme;}

      if ($powerstate =~ m/poweredOn/) {$vmtype=1;} elsif (($template eq "1")||($vmnme =~ m/^@/)||($vmnme =~ m/replica$/)){$vmtype=3;} elsif ($powerstate =~ m/poweredOff/){$vmtype=2;} else {}
      
# Print in to file, Hostname o Vmname, vcpu, memory, Capacity Disk.
$sth = $dbh->prepare("SELECT * FROM Nodos_Cluster where ESX_Name LIKE '$esxName'");
$sth->execute( );

my @x_86;
@x_86 = $sth->fetchrow_array;

if (($x_86[2] eq "") || ($x_86[2] eq "Migracion_EVC_M2")) {$clusName="standalone";} else {$clusName=$x_86[2];}

              binmode(STDOUT, ":utf8");   
	      print DATOS  $vmnme . ";" . $hostname . ";" . $vcpu . ";" . $memoria . ";"  . $totaldisk . ";" . $vmtype . ";" . $so . ";" . $clusName . ";" . $npcorecpu . "\n";

              $totaldisk="";  
             };

};
Util::disconnect();

close (DATOS);


                                
