
#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="Elementos_virtuales";
my $clus;
my $cpu_consum;
my $mem_consum;


# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table( idVMs, Hostname, VCPUs_instaladas, Memoria_instalada_MB, Almacenamiento_instalado_GB, Tipo_elemento_virtual, SO, Cluster, CPU_Consumida_Mhz, Memoria_Consumida_MB, Memoria_Consumida_Overhead) VALUES (?,?,?,?,?,?,?,?,?,?,?)");

open (INSERT, "virtualesF");

my $datos=0;

while(<INSERT>) {

$datos++;

chomp;

my ($hostname,$vcpu,$memoria,$totaldisk, $tipo, $so, $cluster, $cpu_consum, $mem_consum, $mem_consum_overhead) = split /;/;

if ($cpu_consum == $mem_consum) {

$cpu_consum=0;
$mem_consum=0;
                                }


$mem_consum=$mem_consum/1024;
$mem_consum_overhead=$mem_consum_overhead/1024;

if ($mem_consum == 0) {$mem_consum_overhead=0;}

# Clasificacion ID Clusters 
if ( $cluster eq "CentroRespaldo_01" ){$clus=1;} 
elsif ( $cluster eq "Escritorios" ) {$clus=2;}
elsif ( $cluster eq "Produccion_01" ) {$clus=3;} 
elsif ( $cluster eq "Produccion_02" ) {$clus=4;}
elsif ( $cluster eq "Produccion_03" ) {$clus=5;}
elsif ( $cluster eq "Produccion_Backup" ) {$clus=6;}
elsif ( $cluster eq "Test_y_Preprod_01" ) {$clus=7;}
elsif ( $cluster eq "Aranea_01" ) {$clus=8;}
elsif ( $cluster eq "standalone" ) {$clus=9;}
elsif ( $cluster eq "Produccion_04" ) {$clus=11;}
elsif ( $cluster eq "CentroRespaldo_02"){$clus=12;}
elsif ( $cluster eq "Preproduccion" ){$clus=13;}
elsif ( $cluster eq "Entorno_Test" ){$clus=14;}
else {}

# Clasificacion S.O

if ( $so =~ m/Windows XP|Windows 7/){$so=1;}
elsif ( $so =~ m/Windows Server|Windows 2000|Microsoft Windows Server|Microsoft Windows Server|Vista/) {$so=2;}
elsif ( $so =~ m/Linux/ ) {$so=3;}
elsif ($so =~ m/Solaris/){$so=4;}
elsif ($so =~ m/Other/){$so=5;}
else {$so=6;}


$sth->execute( $datos, $hostname, $vcpu, $memoria, $totaldisk, $tipo, $so, $clus, $cpu_consum, $mem_consum, $mem_consum_overhead);
               };

close (INSERT);

$dbh->disconnect;

