cd /root/InformesGestion/ElementosVirtuales/
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion < truncate_nodosClus.sql
rm -f datos_ESX_Clus.txt
perl Elem_virtuales_Clus.pl
perl Elem_virtuales_Clus_dark.pl
perl insert_ESX_Clus.pl
