DELETE FROM Elementos_virtuales;
