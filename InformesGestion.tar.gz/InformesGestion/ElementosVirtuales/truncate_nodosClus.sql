TRUNCATE TABLE Nodos_Cluster;
