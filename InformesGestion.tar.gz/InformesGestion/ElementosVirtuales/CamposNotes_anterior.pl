#!/usr/bin/perl

# Copyright 2006 VMware, Inc.  All rights reserved.
#

use strict;
use VMware::VIRuntime;
use encoding "ISO-8859-1";
#use encoding "utf-8";


Opts::parse();
Opts::validate();

my $name;
my $hostname;
my $toolstatus;
my $so;

Util::connect();

my $vm_views = Vim::find_entity_views(view_type => 'VirtualMachine');

foreach (@$vm_views) {

if (!defined ($_->config->name)) {next}

my $aplicacion=undef;
my $responsable=undef;
my $servicio=undef;
my $entorno=undef;
my $caducidad=undef;
my $peticionario=undef;
my $notes="";
	
my $notes=$_->config->annotation;
$notes=~ s/(\r?\n)+/ /g;

my ($value, $key);
my $custom= $_->summary->customValue;
$name=$_->config->name;
$hostname= $_->summary->guest->hostName;

if (defined ($_->summary->guest->toolsStatus)) {
            $toolstatus= $_->summary->guest->toolsStatus->val;
                                                   }

if (( $toolstatus =~ m/toolsOk/)&&( $so !~ /Other/)){

           $name=$hostname;
      } else {$name=$name;}


 foreach my $customflds (@$custom) {
  
  $key = $customflds->key;
  $value = $customflds->value;

if ($key eq "1") {chomp($responsable=$value);}
elsif ($key eq "207") {chomp($aplicacion=$value);}
elsif ($key eq "102") {chomp($servicio=$value);}
elsif ($key eq "103") {chomp($entorno=$value);}
elsif ($key eq "205") {chomp($caducidad=$value);}
elsif ($key eq "105") {chomp($peticionario=$value);}
else {}

 }

# binmode(STDOUT, ":utf8");

print $name . ";" . $aplicacion . ";" . $servicio . ";" . $entorno . ";" . $caducidad . ";" . $peticionario . ";" . $responsable . ";" . $notes . "\n";

}
    
Util::disconnect();
