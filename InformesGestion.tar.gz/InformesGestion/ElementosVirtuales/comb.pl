my $virtual;
my $prf;
my $consumo;
my $hst;
my $prfcpu;
my $prfmem;
my $memname;
my $prfred;
my $clus;
my $netperf;
my $perfomanceoverhead;
my $perfomancecpu;
my $perfomancememoria;
my $clustername;

open(VIRT,"datos.txt");
open(PERFMEM, "perf_mem");
open(PERFCPU, "perf_cpu");
open(PERFMEMOVERHEAD, "perf_overhead");
open(HYP,">>virtualesF");

my @virt=<VIRT>;
my @perfcpu=<PERFCPU>;
my @perfmem=<PERFMEM>;
my @perfoverhead=<PERFMEMOVERHEAD>;

 foreach $virtual (@virt) {
   
   chomp $virtual;
my ($a,$b,$c,$d,$e,$f,$g)= split(/;/,$virtual);
 

 foreach $prfcpu (@perfcpu) {

   ($cpuname,$perfomancecpu) = split(/,/,$prfcpu);
   
   $cpunme= substr($cpuname,0,8);
  
   if ($a =~ m/$cpunme/)  {last;}

                            }
 chomp $perfomancecpu;
          
 foreach $prfmem (@perfmem) {

   ($memorianame,$perfomancememoria) = split(/,/,$prfmem);

   $memname=substr($memorianame,0,8);

   if ($a =~ m/$memname/) {last;}
                            
                            } 
 chomp $perfomancememoria;


foreach $prfover (@perfoverhead) {

   ($overname,$perfover) = split(/,/,$prfover);

   $overheadname=substr($overname,0,8);

   if ($a =~ m/$overheadname/) {last;}

                            }
 chomp $perfover;

print HYP $virtual . ";" . $perfomancecpu . ";" . $perfomancememoria . ";" . $perfover . "\n";
    
   
                         }

close(VIRT);
close(PERFCPU);
close (HYP);
close (PERFMEM);
