#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="Nodos_Cluster";

# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
my $dbi = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);


$sti= $dbi->prepare("TRUNCATE TABLE $table");
$sti->execute( );
$sti->finish( );

$sth = $dbh->prepare("INSERT INTO $table( ESX_Name, Cluster) VALUES (?,?)");

open (INSERT, "datos_ESX_Clus.txt");


while(<INSERT>) {


chomp;

my ($esxname,$clus_name) = split /;/;


$sth->execute( $esxname, $clus_name);
               };

close (INSERT);

$dbh->disconnect;
$dbi->disconnect;
