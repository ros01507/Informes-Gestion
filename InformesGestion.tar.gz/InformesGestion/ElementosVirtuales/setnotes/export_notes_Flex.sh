FILENAME=vms_flex
count=0
IFS='
'
cat $FILENAME | while read LINE
do
       printf "#### $LINE #### \n"
       perl Notes_list_flex.pl --vmname $LINE
done

