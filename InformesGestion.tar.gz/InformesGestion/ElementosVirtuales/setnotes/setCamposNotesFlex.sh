#!/bin/bash
IFS=';'
while read A B C D E F G H I J K L M N O P Q R S T U V W X Y Z AA AB AC AD AE AF AG AH AI AJ AK AL AM AN AO AP AQ AR AS AT AU AV AW AX AY AZ BA BB
do
       printf "#### '$B' #### \n"
      perl chgNotes_flex.pl --fieldname "Aplicacion" --fieldvalue "$AI" --vmname $B
      perl chgNotes_flex.pl --fieldname "Entorno" --fieldvalue "$AK" --vmname $B
      perl chgNotes_flex.pl --fieldname "Responsable" --fieldvalue "$AO" --vmname $B
      perl chgNotes_flex.pl --fieldname "Servicio" --fieldvalue "$AP" --vmname $B
      perl chgNotes_flex.pl --fieldname "Equipo Peticionario" --fieldvalue "$AT" --vmname $B
      perl chgNotes_flex.pl --fieldname "UR" --fieldvalue "$AR" --vmname $B
      perl chgNotes_flex.pl --fieldname "Appliance" --fieldvalue "$AS" --vmname $B
      perl chgNotes_flex.pl --fieldname "Fecha_Alta" --fieldvalue "$AL" --vmname $B
      perl chgNotes_flex.pl --fieldname "Ticket" --fieldvalue "$AQ" --vmname $B
      perl chgNotes_flex.pl --fieldname "Fecha_Baja" --fieldvalue "$AM" --vmname $B
      perl chgNotes_flex.pl --fieldname "Causa" --fieldvalue "$AJ" --vmname $B
      perl chgNotes_flex.pl --fieldname "Servicio_1" --fieldvalue "$AC" --vmname $B
      perl chgNotes_flex.pl --fieldname "Servicio_2" --fieldvalue "$AD" --vmname $B
      perl chgNotes_flex.pl --fieldname "Servicio_3" --fieldvalue "$AE" --vmname $B
      perl chgNotes_flex.pl --fieldname "Ubicacion" --fieldvalue "$AF" --vmname $B
      perl chgNotes_flex.pl --fieldname "DNS" --fieldvalue "$AG" --vmname $B
      perl chgNotes_flex.pl --fieldname "Caducidad" --fieldvalue "$AH" --vmname $B
      perl chgNotes_flex.pl --fieldname "Ubicacion" --fieldvalue "$AF" --vmname $B
      perl chgNotes_flex.pl --fieldname "Migrada" --fieldvalue "$AN" --vmname $B

done < vInfo_ALL.csv 
