echo ### INICIO ###
date
cd /root/InformesGestion/ElementosVirtuales/setnotes/
FILENAME=bender
IFS='
'
cat $FILENAME | while read LINE
do
       printf "#### $LINE #### \n"
      perl chgNotes.pl --fieldname Aplicacion --fieldvalue "Bender" --vmname $LINE
#      perl chgNotes.pl --fieldname Caducidad --fieldvalue "" --vmname $LINE
      perl chgNotes.pl --fieldname Entorno --fieldvalue "Produccion" --vmname $LINE
#      perl chgNotes.pl --fieldname Causa --fieldvalue "" --vmname $LINE
      perl chgNotes.pl --fieldname "Responsable" --fieldvalue "Jose Luis Potenciano" --vmname $LINE       
      perl chgNotes.pl --fieldname "Servicio" --fieldvalue "Puestos Windows 7 64 bits para Desarrollo (Bender)" --vmname $LINE
      perl chgNotes.pl --fieldname "Equipo Peticionario" --fieldvalue "Puesto de Trabajo" --vmname $LINE
      perl chgNotes.pl --fieldname "UR" --fieldvalue "S" --vmname $LINE
      perl chgNotes.pl --fieldname "Appliance" --fieldvalue "N" --vmname $LINE
#      perl chgNotes.pl --fieldname "Fecha_Alta" --fieldvalue "" --vmname $LINE
#      perl chgNotes.pl --fieldname "Fecha_Baja" --fieldvalue "" --vmname $LINE
#      perl chgNotes.pl --fieldname "Migrada" --fieldvalue "" --vmname $LINE
#       perl chgNotes.pl --fieldname "Ticket" --fieldvalue "" --vmname $LINE

done
date

echo ### FINAL ###

