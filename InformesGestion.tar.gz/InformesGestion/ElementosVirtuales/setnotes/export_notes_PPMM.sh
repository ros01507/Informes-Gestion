FILENAME=fichero
count=0
IFS='
'
cat $FILENAME | while read LINE
do
       let count++

cat list_notes_PPMM.txt | grep $LINE

done
