#!/bin/bash
IFS=";"
while read VM Servicio_2 Servicio_3 Servicio_1
do
echo $VM
#      perl chgNotes.pl --fieldname Aplicacion --fieldvalue "Validacion Aplicaciones" --vmname $LINE
#      perl chgNotes.pl --fieldname Caducidad --fieldvalue "" --vmname $LINE
#      perl chgNotes.pl --fieldname Entorno --fieldvalue "Test" --vmname $LINE
#      perl chgNotes.pl --fieldname Causa --fieldvalue "Baja por fin de uso. Cambio 60875" --vmname $LINE
#      perl chgNotes.pl --fieldname "Responsable" --fieldvalue "Antonio Lopez Sanchez-Avila" --vmname $LINE       
       perl chgNotes_flex.pl --fieldname "Servicio" --fieldvalue """$Servicio_1""" --vmname $VM
       perl chgNotes_flex.pl --fieldname "Servicio_2" --fieldvalue """$Servicio_2""" --vmname $VM
       perl chgNotes_flex.pl --fieldname "Servicio_3" --fieldvalue """$Servicio_3""" --vmname $VM
#      perl chgNotes.pl --fieldname "Equipo Peticionario" --fieldvalue "Herramientas Microinformaticas" --vmname $LINE
#      perl chgNotes.pl --fieldname "UR" --fieldvalue "S" --vmname $LINE
#      perl chgNotes.pl --fieldname "Appliance" --fieldvalue "N" --vmname $LINE
#      perl chgNotes.pl --fieldname "Fecha_Alta" --fieldvalue "2013/06/30" --vmname $LINE
#      perl chgNotes.pl --fieldname "Fecha_Baja" --fieldvalue "2014/04/08" --vmname $LINE
#      perl chgNotes.pl --fieldname "Migrada" --fieldvalue "S" --vmname $LINE
#       perl chgNotes.pl --fieldname "Ticket" --fieldvalue "102018" --vmname $LINE

VM=""

done < medias_2.csv
