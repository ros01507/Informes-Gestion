#!/usr/bin/perl

use strict;
use warnings;

use VMware::VIRuntime;


Opts::parse();
Opts::validate();

my $field_key;
my $field_name;
my $field_value;
my $lst;
Util::connect();

my $CustomFieldsManager = Vim::get_view( mo_ref => Vim::get_service_content()->customFieldsManager );

open(LIST,"list_notes.txt");
my @LIST=<LIST>;

 foreach $lst (@LIST) {
   
   chomp $lst;
my ($vm_name,$aplicacion,$caducidad,$entorno,$causa,$responsable,$servicio,$peticionario,$appliance,$UR,$alta,$baja)= split(/;/,$lst);

print "Estableciendo Campos Notes en Maquina Virtual: " . $vm_name . "....." . "\n";         
             
my $vm_view = Vim::find_entity_view(view_type => "VirtualMachine",
                                             filter => { 'name' => $vm_name});
                                             
unless ($vm_view) {
          Util::disconnect();
          die "Failed to find VM by name: $vm_name\n";
}


#### APLICACION ####

$field_key = FindCustomFieldKey($CustomFieldsManager, 'Aplicacion');
SetVMFieldValue($CustomFieldsManager, $vm_view, $field_key, $aplicacion);

#### CADUCIDAD ####

$field_key = FindCustomFieldKey($CustomFieldsManager, 'Caducidad');
SetVMFieldValue($CustomFieldsManager, $vm_view, $field_key, $caducidad);

#### ENTORNO ####

$field_key = FindCustomFieldKey($CustomFieldsManager, 'Entorno');
SetVMFieldValue($CustomFieldsManager, $vm_view, $field_key, $entorno);

#### CAUSA ####

$field_key = FindCustomFieldKey($CustomFieldsManager, 'Causa');
SetVMFieldValue($CustomFieldsManager, $vm_view, $field_key, $causa);

#### RESPONSABLE ####

$field_key = FindCustomFieldKey($CustomFieldsManager, 'Responsable');
SetVMFieldValue($CustomFieldsManager, $vm_view, $field_key, $responsable);

#### SERVICIO ####

$field_key = FindCustomFieldKey($CustomFieldsManager, 'Servicio');
SetVMFieldValue($CustomFieldsManager, $vm_view, $field_key, $servicio);

#### EQUIPO PETICIONARIO ####

$field_key = FindCustomFieldKey($CustomFieldsManager, 'Equipo Peticionario');
SetVMFieldValue($CustomFieldsManager, $vm_view, $field_key, $peticionario);

#### APPLIANCE ####

$field_key = FindCustomFieldKey($CustomFieldsManager, 'Appliance');
SetVMFieldValue($CustomFieldsManager, $vm_view, $field_key, $appliance);

#### UR ####

$field_key = FindCustomFieldKey($CustomFieldsManager, 'UR');
SetVMFieldValue($CustomFieldsManager, $vm_view, $field_key, $UR);

#### ALTA ####

$field_key = FindCustomFieldKey($CustomFieldsManager, 'Fecha_Alta');
SetVMFieldValue($CustomFieldsManager, $vm_view, $field_key, $alta);

#### BAJA ####

$field_key = FindCustomFieldKey($CustomFieldsManager, 'Fecha_Baja');
SetVMFieldValue($CustomFieldsManager, $vm_view, $field_key, $baja);
                  
}

close (LIST);
Util::disconnect();
     
sub FindCustomFieldKey {
     
     my ($cfm, $field_name) = @_;
     my ($field_key, @custom_fields);
     if ($cfm->field) {
          @custom_fields = @{$cfm->field};
     }
     else {
          # No custom fields defined, return undef
          return undef;
     }
     
     foreach my $field ( @custom_fields ) {
          if ($field->name eq $field_name) {
               $field_key = $field->key;
               last;
          }
     }
     
     # will be undef if no matching field to $field_name is found
     return $field_key;
}
     

sub SetVMFieldValue {
     
     my ($cfm, $entity, $field_key, $field_value) = @_;
     
     print "Setting Custom Field for Virtual Machine...\n";
     $cfm->SetField(
          entity => $entity,
          key => $field_key,
          value => $field_value );
          
     return;
}
