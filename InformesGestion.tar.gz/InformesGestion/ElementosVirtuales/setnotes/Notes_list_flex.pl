#!/usr/bin/perl

# Copyright 2006 VMware, Inc.  All rights reserved.
#

use strict;

$ENV{VI_SERVER}="s8kvcent.cm.es";
$ENV{VI_URL}="https://s8kvcent.cm.es/sdk/webService";


use encoding "ISO-8859-1";

my %opts = (
     vmname => {
     type => "=s",
     variable => "vmname",
     help => "Virtual Machine Name",
     required => 1,
     },
     
  );

Opts::add_options(%opts);
Opts::parse();
Opts::validate();

Opts::parse();
Opts::validate();


use VMware::VIRuntime;
my $key;
my $value;
my $aplicacion;
my $caducidad;
my $entorno;
my $causa;
my $responsable;
my $servicio;
my $peticionario;
my $key_aplicacion;
my $key_caducidad;
my $key_entorno;
my $key_causa;
my $key_responsable;
my $key_servicio;
my $key_peticionario;
my $key_ur;
my $key_appliance;
my $key_alta;
my $key_baja;
my $alta;
my $baja;
my $appliance;
my $ur;

Util::connect();

my $vm_name = Opts::get_option("vmname");

#############################################

##### Obtenemos keys Notes #########

my $CustomFieldsManager = Vim::get_view( mo_ref => Vim::get_service_content()->customFieldsManager );

### Aplicacion ###

my $field_name= "Aplicacion";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

 $key_aplicacion=$field_key;

### Caducidad ###

my $field_name= "Caducidad";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

 $key_caducidad=$field_key;

### Entorno ###

my $field_name= "Entorno";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

 
$key_entorno=$field_key;

### Causa ###

my $field_name= "Causa";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

 $key_causa=$field_key;


### Responsable ###

my $field_name= "Responsable";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_responsable=$field_key;

### Servicio ###

my $field_name= "Servicio";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

 $key_servicio=$field_key;

### Equipo Peticionario ###

my $field_name= "Equipo Peticionario";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_peticionario=$field_key;

### UR ###

my $field_name= "UR";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_ur=$field_key;

### Appliance ###

my $field_name= "Appliance";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_appliance=$field_key;

### Fecha_Alta ###

my $field_name= "Fecha_Alta";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_alta=$field_key;

### Fecha_Baja ###

my $field_name= "Fecha_Baja";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_baja=$field_key;



############################################
# Open file,

print "Exportando Campos Notes de Maquina Virtual: " . $vm_name . "....." . "\n";

open (DATOS,">>list_notes_flex.txt");

# get views of all VM's.

my $vm_views = Vim::find_entity_views(view_type => 'VirtualMachine', filter => { 'name' => $vm_name});

# filter => { 'name' => $vm_name}

foreach (@$vm_views) {

my $custom= $_->summary->customValue;

foreach my $customflds (@$custom) {
  
  $key = $customflds->key;
  $value = $customflds->value;


if ($key eq $key_aplicacion) {chomp($aplicacion=$value);}
elsif ($key eq $key_caducidad) {chomp($caducidad=$value);}
elsif ($key eq $key_entorno) {chomp($entorno=$value);}
elsif ($key eq $key_causa) {chomp($causa=$value);}
elsif ($key eq $key_responsable) {chomp($responsable=$value);}
elsif ($key eq $key_servicio) {chomp($servicio=$value);}
elsif ($key eq $key_peticionario) {chomp($peticionario=$value);}
elsif ($key eq $key_ur) {chomp($ur=$value);}
elsif ($key eq $key_appliance) {chomp($appliance=$value);}
elsif ($key eq $key_alta) {chomp($alta=$value);}
elsif ($key eq $key_baja) {chomp($baja=$value);}
else {}
 };

print DATOS $vm_name . ";" . $aplicacion . ";" . $caducidad . ";" . $entorno . ";" . $causa . ";" . $responsable . ";" . $servicio . ";" . $peticionario . ";" . $appliance . ";" . $ur . ";" . $alta . ";" . $baja . "\n";
                     
};


Util::disconnect();

close (DATOS);

sub FindCustomFieldKey {
     
     my ($cfm, $field_name) = @_;
     my ($field_key, @custom_fields);
     if ($cfm->field) {
          @custom_fields = @{$cfm->field};
     }
     else {
          # No custom fields defined, return undef
          return undef;
     }
     
     foreach my $field ( @custom_fields ) {
          if ($field->name eq $field_name) {
               $field_key = $field->key;
               last;
          }
     }
     
     # will be undef if no matching field to $field_name is found
     return $field_key;
}

