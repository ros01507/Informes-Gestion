FILENAME=migradas
count=0
IFS='
'
cat $FILENAME | while read LINE
do
       cat list_notes_flex.txt | grep $LINE >> notes_migrate
done

