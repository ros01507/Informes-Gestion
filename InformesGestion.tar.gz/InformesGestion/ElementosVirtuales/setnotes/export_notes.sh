FILENAME=vms
count=0
IFS='
'
cat $FILENAME | while read LINE
do
       let count++
       printf "#### $LINE #### \n"
       perl Notes_list.pl --vmname $LINE
       sleep 4
done

