FILENAME=vms
count=0
IFS='
'
cat $FILENAME | while read LINE
do
       printf "#### $LINE #### \n"
#      perl chgNotes.pl --fieldname Aplicacion --fieldvalue "Pruebas IPR escritorios 64 bits" --vmname $LINE
#      perl chgNotes.pl --fieldname Caducidad --fieldvalue "" --vmname $LINE
#      perl chgNotes.pl --fieldname Entorno --fieldvalue "Produccion" --vmname $LINE
#      perl chgNotes.pl --fieldname Causa --fieldvalue "Pendiente de asignacion" --vmname $LINE
#      perl chgNotes.pl --fieldname "Responsable" --fieldvalue "Pedro Gonzalez" --vmname $LINE       
#      perl chgNotes.pl --fieldname "Servicio" --fieldvalue "Pruebas IPR" --vmname $LINE
#      perl chgNotes.pl --fieldname "Equipo Peticionario" --fieldvalue "Puesto de Trabajo" --vmname $LINE
#      perl chgNotes.pl --fieldname "UR" --fieldvalue "S" --vmname $LINE
#      perl chgNotes.pl --fieldname "Appliance" --fieldvalue "N" --vmname $LINE
      perl chgNotes.pl --fieldname "Fecha_Alta" --fieldvalue "14/10/2015" --vmname $LINE
#      perl chgNotes.pl --fieldname "Fecha_Baja" --fieldvalue "" --vmname $LINE
#      perl chgNotes.pl --fieldname "Migrada" --fieldvalue "" --vmname $LINE
       perl chgNotes.pl --fieldname "Ticket" --fieldvalue "p1182" --vmname $LINE

done
