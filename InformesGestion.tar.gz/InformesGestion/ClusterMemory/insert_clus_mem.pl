
#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="Clusters_Memory";
my $clus;
my $cpu_consum;
my $mem_consum;;


# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table( idCluster, Nombre_Cluster, Memoria_Consumida, Memoria_Overhead, Memoria_Total, Memoria_Disponible,Memoria_Disponible_20Free, ClusterID) VALUES (?,?,?,?,?,?,?,?)");

open (INSERT, "clusmemF.txt");

my $datos=0;

while(<INSERT>) {

$datos++;

chomp;

my ($cluster,$memconsumida,$memoverhead,$totalmemory) = split /,/;

$memconsumida=$memconsumida/1024;
$memoverhead=$memoverhead/1024;
$memdisponible=$totalmemory-($memconsumida+$memoverhead);
$memdisponible20=($memdisponible-($totalmemory*20/100));

# Clasificacion ID Clusters

if ( $cluster eq "CentroRespaldo_01" ){$clus=1;}
elsif ( $cluster eq "Escritorios" ) {$clus=2;}
elsif ( $cluster eq "Produccion_01") {$clus=3;}
elsif ( $cluster eq "Produccion_02") {$clus=4;}
elsif ( $cluster eq "Produccion_03") {$clus=5;}
elsif ( $cluster eq "Produccion_Backup") {$clus=6;}
elsif ( $cluster eq "Test_y_Preprod_01" ) {$clus=7;}
elsif ( $cluster eq "Aranea_01" ) {$clus=8;}
elsif ( $cluster eq "Produccion_04" ) {$clus=11;}
elsif ( $cluster eq "CentroRespaldo_02"){$clus=12;}
elsif ( $cluster eq "Preproduccion" ){$clus=13;}
elsif ( $cluster eq "Entorno_Test" ){$clus=14;}
elsif ( $cluster eq "Test" ){$clus=15;}
elsif ( $cluster eq "Produccion1" ){$clus=16;}
elsif ( $cluster eq "Produccion2" ){$clus=17;}
elsif ( $cluster eq "Desarrollo" ){$clus=18;}
elsif ( $cluster eq "Escritorios01" ){$clus=20;}
elsif ( $cluster eq "Pre-Produccion" ){$clus=21;}
elsif ( $cluster eq "SQL_Produccion" ){$clus=22;}
elsif ( $cluster eq "Pre-Dimensionamiento" ){$clus=23;}
elsif ( $cluster eq "SQL_Previos" ){$clus=24}
elsif ( $cluster eq "Escritorios_1"){$clus=27;}
elsif ( $cluster eq "Escritorios_2"){$clus=28;}
elsif ( $cluster eq "CentroRespaldo_03"){$clus=26;}
elsif ( $cluster eq "CentroRespaldo_02"){$clus=12;}
else {$clus=9;}


$sth->execute( $datos, $cluster, $memconsumida, $memoverhead, $totalmemory,$memdisponible,$memdisponible20,$clus);
               };

close (INSERT);

$dbh->disconnect;

