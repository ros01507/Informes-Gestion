
my $memconsumed;
my $memoryoverhead;
my $memototal;
my $overhead;

open(MEMCONSUM,"perf_mem_consumed");
open(MEMOVERHEAD, "perf_mem_overhead");
open(MEMTOTAL, "perf_mem_total");
open(CLUSMEM,">>clusmemF.txt");

my @memconsum=<MEMCONSUM>;
my @memoverhead=<MEMOVERHEAD>;
my @memtotal=<MEMTOTAL>;


 foreach $memconsumed (@memconsum) {
   
   chomp $memconsumed;

my ($a,$b)= split(/,/,$memconsumed);

 foreach $memoryoverhead (@memoverhead) {

  ($overheadname,$overhead) = split(/,/,$memoryoverhead);
   
    if ($a =~ m/$overheadname/)  {last;}

                            }
 chomp $overhead;
          
 foreach $memTotal (@memtotal) {

   ($namememtotal,$memototal) = split(/,/,$memTotal);

   
   if ($a =~ m/$namememtotal/) {last;}
                            
                            } 
 chomp $memototal;

if ($a ne "") {

print CLUSMEM $memconsumed . "," . $overhead . "," . $memototal . "\n";
              }
    
                            }


close(MEMCONSUM);
close(MEMOVERHEAD);
close (MEMTOTAL);
close (CLUSMEM);
