#!/usr/bin/perl -w
#
# vi-get-snapshots.pl - written by Andrew Sullivan, 2008-12-31, http://www.get-admin.com
#
# Please report bugs and request improvements at http://get-admin.com/blog/?p=307
#
# This script simply connects to VC or an ESX host and queries each VM for any snapshots
# that have been created for it.  It then prints off the tree of snaps so you can view them.
#
# Example usage:
#   Show basic information
#   ./vi-get-snapshots.pl --server your.host 
#
#   Show additional info about the snapshot
#   ./vi-get-snapshots.pl --server your.host --expand
#
# Version 1.1, 2009-02-09
#   Changed the date printing to elminate my attempt to format the date using regex
#   Removed the curly braces from around the variables in the snapshot object
#
 
use strict;
use warnings;
 
use FindBin;
use lib "$FindBin::Bin/../";
 
use VMware::VIRuntime;
 
my %opts = (
	'expand' => {
		type => ":s",
		help => "If provided, will list additional information about the snapshots.",
		required => 0,
		default => "false"
	}
);
 
Opts::add_options(%opts);
Opts::parse();
Opts::validate();
 
Util::connect();
 
my $VMs = Vim::find_entity_views( view_type => 'VirtualMachine' );
 
# loop through each VM found, see if it has a snapshot
foreach my $vm (@$VMs) {
	if ($vm->snapshot) {
		print $vm->name . ":n";
 
 
		foreach (@{'$vm->snapshot->rootSnapshotList') {
			printSnaps($_, 2);
		}
 
		# and an empty line to separate the different hosts
		print "n";
 
	} else {
		# we don't really care if it has no snaps, but if you want to
		# see VMs without snaps, this line can be uncommented
		#print $vm->name . " has no snapshotsn";
	}
}
 
Util::disconnect();
 
sub printSnaps {
        
	my ($snapshotTree, $indent) = $_;
 
	if ($indent < 2) {
		$indent = 2;
	}
 
	# display some basic information
	print " " x $indent . "|n" 
		. " " x $indent . "|- " . "Name:        " . $snapshotTree->name
		. " " x ($indent + 3)   . "Created:     " . $snapshotTree->createTime . "n";
 
	# if requested, display some additional information
	if (Opts::get_option('expand') ne "false") {
		print " " x ($indent + 3)   . "Quiesced:  " . $snapshotTree->quiesced
		. " " x ($indent + 3)   . "State:       " . $snapshotTree->state->val
		. " " x ($indent + 3)   . "Description: " . $snapshotTree->description;
	}
 
	# recurse through the tree of snaps
	if ($snapshotTree->childSnapshotList) {
		# loop through any children that may exist
		foreach (@{$snapshotTree->childSnapshotList}) {
			printSnaps($_, $indent + 2);
		}
	}
}
