#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="RVTvDisk";
my $datos="";

# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

my $sth = $dbh->prepare("INSERT INTO $table(idRVTvDisk,VM,Disk,Capacity_MB,Raw,Disk_Mode,Thin,Eagerly_Scrub,Split,Write_Through,Level,Shares,Controller,Unit,Path,Raw_LUN_ID,Raw_Comp_Mode,Datacenter,Cluster,Host,OS,Vcenter) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

open (INSERT, "/root/InformesGestion/rvt/vDisk/RVTools_tabvDisk_VCENTDPL.csv");

while(<INSERT>) {

$datos++;

chomp;

my ($a,$b,$c,$d,$e,$f,$g,$h,$i,$j,$k,$l,$m,$n,$o,$p,$q,$r,$s,$t,$u,$v,$w,$x,$y,$z,$aa,$ab,$ac,$ad,$ae,$af,$ag,$ah,$ai,$aj,$ak,$al,$am,$an)= split /;/;

#print $q . "####" . $ak . "\n";


$sth->execute($datos,$a,$b,$c,$d,$e,$f,$g,$h,$i,$j,$k,$l,$m,$n,$o,$p,$aj,$ak,$al,$am,'vcentdpl');

               };

close (INSERT);

$dbh->disconnect;
