cd /root/InformesGestion/rvt/vMemory
#mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT VM FROM  RVTvMemory where Consumed > Size_MB and VM like 'PCS%' and Cluster like 'Escritorios_1' and VM not like 'PCS81382' and VM not like 'PCS81383' and VM not like 'PCS81384' and VM not like 'PCS82070' order by Consumed DESC limit 57" > highMemorPcs.log

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT VM FROM  RVTvMemory where Active > '1200' and VM like 'PCS%' and Cluster like 'Escritorios_1' and VM not like 'PCS81382' and VM not like 'PCS81383' and VM not like 'PCS81384' and VM not like 'PCS82070'" > highMemorPcs.log


cd /root/vmware-vsphere-cli-distrib/apps/vm/
FILENAME='/root/InformesGestion/rvt/vMemory/highMemorPcs.log'
count=0
IFS='
'
cat $FILENAME | while read LINE
do
       perl vmcontrol.pl --vmname $LINE --operation reboot

       if [ $? != "0" ]; then
       perl vmcontrol.pl --vmname $LINE --operation reset
       fi
done
