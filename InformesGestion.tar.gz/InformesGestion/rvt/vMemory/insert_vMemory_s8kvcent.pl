#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="RVTvMemory";

# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
my $dbi= DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

my $sth = $dbh->prepare("INSERT INTO $table(idRVTvMemory,VM,Size_MB,Overhead,Max,Consumed,Consumed_Overhead,Private,Shared,Swapped,Ballooned,Active,Entitlement,DRS_Entitlement,Level,Shares,Reservation,Limit_Memory,Datacenter,Cluster,Host,OS) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

my $sti = $dbi->prepare("select idRVTvMemory from RVTvMemory order by idRVTvMemory DESC limit 1");
$sti->execute( );

my $datos=$sti->fetchrow_array( );
$sti->finish( );

open (INSERT, "/root/InformesGestion/rvt/vMemory/RVTools_tabvMemory_S8KVCENT.csv");

while(<INSERT>) {

$datos++;

chomp;

my ($a,$b,$c,$d,$e,$f,$g,$h,$i,$j,$k,$l,$m,$n,$o,$p,$q,$r,$s,$t,$u,$v,$w,$x,$y,$z,$aa,$ab,$ac,$ad,$ae,$af,$ag,$ah,$ai,$aj,$ak,$al,$am,$an)= split /;/;

#print $q . "####" . $ak . "\n";


$sth->execute($datos,$a,$b,$c,$d,$e,$f,$g,$h,$i,$j,$k,$l,$m,$n,$o,$p,$q,$ak,$al,$am,$an);

               };

close (INSERT);

$dbh->disconnect;
$dbi->disconnect;
