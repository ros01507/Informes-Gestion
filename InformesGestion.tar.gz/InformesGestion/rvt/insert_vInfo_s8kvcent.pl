#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="RVTvInfo";


# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table(idRVTvInfo,VM,DNS_Name,Powerstate,Heartbeat,Consolidation_Needed,PowerOn,CPUs,Memory,NICs,Disks,Network_1,Network_2,Network_3,Network_4,Resource_pool,Folder,vApp,FT_State,FT_Latency,FT_Bandwidth,FT_Sec_Latency,Boot_Required,Provisioned_MB,In_Use_MB,Unshared_MB,Path,Annotation,Servicio_1,Servicio_2,Servicio_3,Ubicacion,DNS,Caducidad,Aplicacion,Causa,Entorno,Fecha_Alta,Fecha_Baja,Migrada,Responsable,Servicio,Ticket,UR,Appliance,Equipo_Peticionario,Datacenter,Cluster,Host,OS,VM_Version,UUID,Object_ID,Vcenter) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                                                                                                    


open (INSERT, "/root/InformesGestion/rvt/RVTools_tabvInfo_S8KVCENT.csv");

my $datos=0;

while(<INSERT>) {

$datos++;

chomp;

my ($VM,$DNS_Name,$Powerstate,$Heartbeat,$Consolidation_Needed,$PowerOn,$CPUs,$Memory,$NICs,$Disks,$Network_1,$Network_2,$Network_3,$Network_4,$Resource_pool,$Folder,$vApp,$FT_State,$FT_Latency,$FT_Bandwidth,$FT_Sec_Latency,$Boot_Required,$Provisioned_MB,$In_Use_MB,$Unshared_MB,$Path,$Annotation,$Equipo_Peticionario,$Aplicacion,$Caducidad,$Causa,$DNS,$Entorno,$Fecha_Alta,$Fecha_Baja,$Migrada,$Responsable,$Servicio,$Servicio_1,$Servicio_2,$Servicio_3,$UR,$Ubicacion,$Ticket,$Appliance,$Datacenter,$Cluster,$Host,$OS,$VM_Version,$UUID,$Object_ID) = split /;/;



$sth->execute( $datos,$VM,$DNS_Name,$Powerstate,$Heartbeat,$Consolidation_Needed,$PowerOn,$CPUs,$Memory,$NICs,$Disks,$Network_1,$Network_2,$Network_3,$Network_4,$Resource_pool,$Folder,$vApp,$FT_State,$FT_Latency,$FT_Bandwidth,$FT_Sec_Latency,$Boot_Required,$Provisioned_MB,$In_Use_MB,$Unshared_MB,$Path,$Annotation,$Servicio_1,$Servicio_2,$Servicio_3,$Ubicacion,$DNS,$Caducidad,$Aplicacion,$Causa,$Entorno,$Fecha_Alta,$Fecha_Baja,$Migrada,$Responsable,$Servicio,$Ticket,$UR,$Appliance,$Equipo_Peticionario,$Datacenter,$Cluster,$Host,$OS,$VM_Version,$UUID,$Object_ID,"v12kvcent");
               };

close (INSERT);

$dbh->disconnect;
