#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="Vtools";


# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table(idVtools,VM,VM_Version,Powerstate,Tools,Tools_Version,Required_Version,Upgradeable,Template,Upgrade_Policy,Sync_time,Datacenter,Cluster,Host,OS_according_to_the_configuration_file,OS_according_to_the_VMware_Tools,VMRef) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

my $datos="";

open (INSERT, "/root/InformesGestion/rvt/RVTools_tabvTools_VCENTDPL.csv");


while(<INSERT>) {

$datos++;

chomp;

my ($A,$B,$C,$D,$E,$F,$G,$H,$I,$J,$K,$L,$M,$N,$O,$P,$Q,$R,$S,$T,$U,$V,$W,$X,$Y,$Z,$AA,$AB,$AC,$AD,$AE,$AF,$AG,$AH,$AI,$AJ) = split /;/;

$sth->execute( $datos,$B,$C,$D,$E,$F,$G,$H,$I,$J,$K,$AE,$AF,$AG,$AH,$AI,$AJ);

               };

close (INSERT);

$dbh->disconnect;
