FILENAME=list
IFS='
'
cat $FILENAME | while read LINE

do
       
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion -e "select * from RVTvMemory where VM ='$LINE'"
       

done
