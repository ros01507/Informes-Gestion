my $hostname;
my $vrt;
my $namevcenter;
my $esx;
my $name;

open(VIRT,"RVTools_tabvInfo.csv");
open(VCENTER, "vcenter_ESX.csv");
open(HYP,">>RVTools_tabvInfo_vcenter.csv");

my @virt=<VIRT>;
my @vcenter=<VCENTER>;
my @virt_vcenter=<HYP>;


 foreach $virt (@virt) {

   chomp $virt;

   $vrt=substr($virt,0,8);
   $vrt=uc($vrt); 
 
 foreach $vcenter (@vcenter) {

   chomp $vcenter;
   
   ($name,$namevcenter,$esx) = split(/,/,$vcenter );
   
   $name= substr($name,0,8);
   $name=uc($name);

   if ($vrt =~ m/$name/) {last;} else {$namevcenter="";}

                          }
chomp $namevcenter;
print HYP $virt . ";" . $namevcenter . "\n";


                         }

close(VIRT);
close(VCENTER);
close (HYP);
