my $hostname;
my $vrt;
my $namevcenter;
my $esx;
my $name;

open(VIRT,"/root/InformesGestion/rvt/RVTools_tabvHost_serial.csv");
open(VCENTER, "/root/InformesGestion/rvt/vcenter_ESX.csv");
open(HYP,">>/root/InformesGestion/rvt/RVTools_tabvHost_vcenter.csv");

my @virt=<VIRT>;
my @vcenter=<VCENTER>;
my @virt_vcenter=<HYP>;


 foreach $virt (@virt) {

   chomp $virt;

   $vrt=substr($virt,0,8);
   $vrt=uc($vrt); 
 
 foreach $vcenter (@vcenter) {

   chomp $vcenter;
   
   ($name,$namevcenter,$esx) = split(/,/,$vcenter );
   
   $esx= substr($esx,0,8);
   $esx=uc($esx);

   if ($vrt =~ m/$esx/) {last;} else {$namevcenter="";}

                          }
chomp $namevcenter;
print HYP $virt . ";" . $namevcenter . "\n";


                         }

close(VIRT);
close(VCENTER);
close (HYP);
