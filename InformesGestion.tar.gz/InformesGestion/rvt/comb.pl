my $hostname;
my $hst;
my $serial;
my $serialnum;
my $name;

open(HOST,"RVTools_tabvHost.csv");
open(SERIAL, "serial_ktpmc.csv");
open(HYP,">>RVTools_tabvHost_serial.csv");

my @host=<HOST>;
my @serial=<SERIAL>;
my @host_serial=<HYP>;


 foreach $hostname (@host) {

   chomp $hostname;

   $hst=substr($hostname,0,8);
   $hst=uc($hst); 
 
 foreach $serial (@serial) {

   chomp $serial;
   
   ($name,$serialnum) = split(/,/,$serial );
   
   $name= substr($name,0,8);
   $name=uc($name);

   if ($hst =~ m/$name/) {last;} else {$serialnum="";}

                          }
chomp $serialnum;
print HYP $hostname . ";" . $serialnum . "\n";


                         }

close(HOST);
close(SERIAL);
close (HYP);
