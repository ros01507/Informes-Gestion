#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="RVT_ESXInfo";


# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table(idRVT_ESXInfo,Host,Datacenter,Cluster,CPU_Model,Speed,HT_Available,HT_Active,CPU,Cores_per_CPU,Cores,CPU_usage_percent,Memory,Memory_usage_percent,Console,NICs,HBAs,VMs,VMs_per_Core,vCPUs,vCPUs_per_Core,vRAM,VM_Used_memory,VM_Memory_Swapped,VM_Memory_Ballooned,Current_EVC,Max_EVC,ESX_Version,Boot_time,DNS_Servers,DHCP,Domain,DNS_Search_Order,NTP_Servers,Time_Zone,Time_Zone_Name,GMT_Offset,Vendor,Model,BIOS_Version,BIOS_Date,Object_ID,Serial,Vcenter) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
my $datos="";
                                                                        
open (INSERT, "/root/InformesGestion/rvt/RVTools_tabvHost_VCENTER.csv");


while(<INSERT>) {

$datos++;

chomp;

my ($Host,$Datacenter,$Cluster,$CPU_Model,$Speed,$HT_Available,$HT_Active,$CPU,$Cores_per_CPU,$Cores,$CPU_usage_percent,$Memory,$Memory_usage_percent,$Console,$NICs,$HBAs,$VMs,$VMs_per_Core,$vCPUs,$vCPUs_per_Core,$vRAM,$VM_Used_memory,$VM_Memory_Swapped,$VM_Memory_Ballooned,$Current_EVC,$Max_EVC,$ESX_Version,$Boot_time,$DNS_Servers,$DHCP,$Domain,$DNS_Search_Order,$NTP_Servers,$Time_Zone,$Time_Zone_Name,$GMT_Offset,$Vendor,$Model,$BIOS_Version,$BIOS_Date,$Object_ID,$Serial,$Vcenter) = split /;/;
      
$sth->execute($datos,$Host,$Datacenter,$Cluster,$CPU_Model,$Speed,$HT_Available,$HT_Active,$CPU,$Cores_per_CPU,$Cores,$CPU_usage_percent,$Memory,$Memory_usage_percent,$Console,$NICs,$HBAs,$VMs,$VMs_per_Core,$vCPUs,$vCPUs_per_Core,$vRAM,$VM_Used_memory,$VM_Memory_Swapped,$VM_Memory_Ballooned,$Current_EVC,$Max_EVC,$ESX_Version,$Boot_time,$DNS_Servers,$DHCP,$Domain,$DNS_Search_Order,$NTP_Servers,$Time_Zone,$Time_Zone_Name,$GMT_Offset,$Vendor,$Model,$BIOS_Version,$BIOS_Date,$Object_ID,$Serial,$Vcenter);

               };

close (INSERT);

$dbh->disconnect;
