#! /bin/bash
cp /root/InformesGestion/rvt/VC*.csv /root/InformesGestion/rvt/historico/
rm  -rf /root/InformesGestion/rvt/*.csv

################### VIRTUALES ############################

cp -rf /datos/usuarios/A163440/rvt/s8kvcent/RVTools_tabvInfo.csv /root/InformesGestion/rvt/RVTools_tabvInfo_s8kvcent.csv
cp -rf /datos/usuarios/A163440/rvt/vcentdpl/RVTools_tabvInfo.csv /root/InformesGestion/rvt/RVTools_tabvInfo_vcentdpl.csv
cp -rf /datos/usuarios/A163440/rvt/V12KVPPMM/RVTools_tabvInfo.csv /root/InformesGestion/rvt/RVTools_tabvInfo_v12kvppmm.csv
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion -e "delete from RVTvInfo"
sed '1d' /root/InformesGestion/rvt/RVTools_tabvInfo_s8kvcent.csv >  /root/InformesGestion/rvt/RVTools_tabvInfo_S8KVCENT.csv
sed '1d' /root/InformesGestion/rvt/RVTools_tabvInfo_vcentdpl.csv > /root/InformesGestion/rvt/RVTools_tabvInfo_VCENTDPL.csv
sed '1d' /root/InformesGestion/rvt/RVTools_tabvInfo_v12kvppmm.csv > /root/InformesGestion/rvt/RVTools_tabvInfo_V12KVPPMM.csv
perl /root/InformesGestion/rvt/insert_vInfo_s8kvcent.pl
perl /root/InformesGestion/rvt/insert_vInfo_vcentdpl.pl
perl /root/InformesGestion/rvt/insert_vInfo_v12kvppmm.pl
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select * from RVTvInfo" |sed "s/'/\'/;s/\t/\";\"/g;s/^/\"/;s/$/\"/;s/\n//g" | sed 's/"//g' > /root/InformesGestion/rvt/RVTools_tabvInfo_all.csv
cp -rf /root/InformesGestion/rvt/RVTools_tabvInfo_all.csv /root/InformesGestion/rvt/RVTools_tabvInfo_sincolumall.csv
perl -pi -e 'tr/\cM//d;' /root/InformesGestion/rvt/RVTools_tabvInfo_all.csv
sed '1d' /root/InformesGestion/rvt/RVTools_tabvInfo_all.csv > /root/InformesGestion/rvt/RVTools_tabvInfo_ALL.csv
cp -rf /root/InformesGestion/rvt/RVTools_tabvInfo_ALL.csv "/root/InformesGestion/rvt/VC_IMAGES_`date +%Y%m%d%H%M%S`.csv"
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion  -e "select * from RVTvInfo" |sed "s/'/\'/;s/\t/\";\"/g;s/^/\"/;s/$/\"/;s/\n//g" | sed 's/"//g' > /root/InformesGestion/rvt/vInfo_ALL.csv
perl -pi -e 'tr/\cM//d;' /root/InformesGestion/rvt/vInfo_ALL.csv
mutt -a "/root/InformesGestion/rvt/vInfo_ALL.csv" -s "RVTools_Virtuales" aalcalap@bankia.com < /dev/null

################### FISICAS ##############################

############  FORMATEO FICHERO FISICAS ###################

cp -rf /datos/usuarios/A163440/rvt/s8kvcent/RVTools_tabvHost.csv /datos/usuarios/A163440/rvt/RVTools_tabvHost.csv
sed '1d'  /datos/usuarios/A163440/rvt/vcentdpl/RVTools_tabvHost.csv  > /datos/usuarios/A163440/rvt/vcentdpl/vHost.csv
sed '1d'  /datos/usuarios/A163440/rvt/V12KVPPMM/RVTools_tabvHost.csv  > /datos/usuarios/A163440/rvt/V12KVPPMM/vHost.csv
cat /datos/usuarios/A163440/rvt/vcentdpl/vHost.csv >> /datos/usuarios/A163440/rvt/RVTools_tabvHost.csv
cat /datos/usuarios/A163440/rvt/V12KVPPMM/vHost.csv >> /datos/usuarios/A163440/rvt/RVTools_tabvHost.csv
cp -rf /datos/usuarios/A163440/rvt/RVTools_tabvHost.csv "/root/InformesGestion/rvt/RVTools_tabvHost.csv"

############### CAMPO SERIAL FISICAS ####################
rm -f /root/InformesGestion/rvt/serial_ktpmc.csv
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select  nombreDNS,serial from x86_ktpmc" |sed "s/'/\'/;s/\t/\",\"/g;s/^/\"/;s/$/\"/;s/\n//g" | sed 's/"//g' > /root/InformesGestion/rvt/serial_ktpmc.csv
echo "svmsh001,643908" >> /root/InformesGestion/rvt/serial_ktpmc.csv
perl /root/InformesGestion/rvt/comb_serial.pl
perl -pi -e 'tr/\cM//d;'  /root/InformesGestion/rvt/RVTools_tabvHost_serial.csv

############## CAMPO VCENTER FISICAS ####################

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select  Nombre_VM,vcenter,ESX from Virtuales_ESX" |sed "s/'/\'/;s/\t/\",\"/g;s/^/\"/;s/$/\"/;s/\n//g" | sed 's/"//g' > /root/InformesGestion/rvt/vcenter_ESX.csv
perl /root/InformesGestion/rvt/comb_vcenter_fisicas.pl
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion -e "delete from RVT_ESXInfo"
sed '1d' /root/InformesGestion/rvt/RVTools_tabvHost_vcenter.csv > /root/InformesGestion/rvt/RVTools_tabvHost_VCENTER.csv
perl /root/InformesGestion/rvt/insert_fisicas.pl
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion  -e "select * from RVT_ESXInfo" |sed "s/'/\'/;s/\t/\";\"/g;s/^/\"/;s/$/\"/;s/\n//g" | sed 's/"//g' > /root/InformesGestion/rvt/ESXInfo_ALL.csv
mutt -a "/root/InformesGestion/rvt/ESXInfo_ALL.csv" -s "RVTools_FISICAS" aalcalap@bankia.com < /dev/null
sed '1d' "/root/InformesGestion/rvt/ESXInfo_ALL.csv" > "/root/InformesGestion/rvt/VC_FISICAS_`date +%Y%m%d%H%M%S`.csv"

#################  Health DISK ###############################
cat /datos/usuarios/A163440/rvt/s8kvcent/RVTools_tabvHealth.csv | grep 'On C:\ is 0% disk space available' > /root/InformesGestion/rvt/out_size

################  Tabla Datos Memoria RVTvMemory #############

cd /root/InformesGestion/rvt/vMemory/

sed '1d' /datos/usuarios/A163440/rvt/vcentdpl/RVTools_tabvMemory.csv > /root/InformesGestion/rvt/vMemory/RVTools_tabvMemory_VCENTDPL.csv
sed '1d' /datos/usuarios/A163440/rvt/s8kvcent/RVTools_tabvMemory.csv > /root/InformesGestion/rvt/vMemory/RVTools_tabvMemory_S8KVCENT.csv
sed '1d' /datos/usuarios/A163440/rvt/V12KVPPMM/RVTools_tabvMemory.csv > /root/InformesGestion/rvt/vMemory/RVTools_tabvMemory_V12KVPPMM.csv

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion -e "delete from RVTvMemory"

perl insert_vMemory_vcentdpl.pl
perl insert_vMemory_s8kvcent.pl
perl insert_vMemory_v12kvppmm.pl

################  Tabla Datos Discos Virtuales RVTvDisk #############

cd /root/InformesGestion/rvt/vDisk/

sed '1d' /datos/usuarios/A163440/rvt/vcentdpl/RVTools_tabvDisk.csv > /root/InformesGestion/rvt/vDisk/RVTools_tabvDisk_VCENTDPL.csv
sed '1d' /datos/usuarios/A163440/rvt/s8kvcent/RVTools_tabvDisk.csv > /root/InformesGestion/rvt/vDisk/RVTools_tabvDisk_S8KVCENT.csv
sed '1d' /datos/usuarios/A163440/rvt/V12KVPPMM/RVTools_tabvDisk.csv > /root/InformesGestion/rvt/vDisk/RVTools_tabvDisk_V12KVPPMM.csv

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion -e "delete from RVTvDisk"

perl insert_vDisk_vcentdpl.pl
perl insert_vDisk_s8kvcent.pl
perl insert_vDisk_v12kvppmm.pl
################  Tabla VTools ######################################

'cp' -Rf /datos/usuarios/A163440/rvt/s8kvcent/RVTools_tabvTools.csv /root/InformesGestion/rvt/RVTools_tabvTools_s8kvcent.csv
'cp' -Rf /datos/usuarios/A163440/rvt/vcentdpl/RVTools_tabvTools.csv /root/InformesGestion/rvt/RVTools_tabvTools_vcentdpl.csv
'cp' -Rf /datos/usuarios/A163440/rvt/V12KVPPMM/RVTools_tabvTools.csv /root/InformesGestion/rvt/RVTools_tabvTools_v12kvppmm.csv

sed '1d' /root/InformesGestion/rvt/RVTools_tabvTools_s8kvcent.csv >  /root/InformesGestion/rvt/RVTools_tabvTools_S8KVCENT.csv
sed '1d' /root/InformesGestion/rvt/RVTools_tabvTools_vcentdpl.csv > /root/InformesGestion/rvt/RVTools_tabvTools_VCENTDPL.csv
sed '1d' /root/InformesGestion/rvt/RVTools_tabvTools_v12kvppmm.csv > /root/InformesGestion/rvt/RVTools_tabvTools_V12KVPPMM.csv

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion -e "delete from Vtools"

perl /root/InformesGestion/rvt/insert_VTools_vcentdpl.pl
perl /root/InformesGestion/rvt/insert_VTools_s8kvcent.pl
perl /root/InformesGestion/rvt/insert_VTools_v12kvppmm.pl

############# Tablas Recursos y Datastores #########################

cd /root/InformesGestion/CLOUD
sh rvtRP.sh > /var/log/InfoGest/rvtRP.log
sh rvtDT.sh > /var/log/InfoGest/rvtDT.log
sh genera_mail.sh > /var/log/InfoGest/genera_mail.log
mail "aalcalap@bankia.com,ivillanova@externos.bankia.com,jmatamoros@externos.bankia.com,jlopezt@externos.bankia.com,rarellano@externos.bankia.com,raguilera@externos.bankia.com,jduran@externos.bankia.com" -s "Cloud - Recursos Almacenamiento y Memoria" < Almacenamiento
