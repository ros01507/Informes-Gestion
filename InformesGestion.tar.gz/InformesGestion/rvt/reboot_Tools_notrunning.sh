mysql --host=VLIROMPF.cm.es --database=Informes_Gestion -e "delete from Vtools"

sed '1d' /datos/usuarios/A163440/rvt/vcentdpl/RVTools_tabvTools.csv > /root/InformesGestion/rvt/VTools_vcentdpl.csv

perl /root/InformesGestion/rvt/insert_VTools_vcentdpl.pl

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select VM from RVTvInfo where Heartbeat='red' and Cluster='Escritorios_1' and VM like 'PCS%' and Aplicacion not like '%IPR%' and VM not like 'PCS81382' and VM not like 'PCS81383' and VM not like 'PCS81384' and VM not like 'PCS82070'" > /root/vmware-vsphere-cli-distrib/apps/vm/PCS_not_Tools


mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select VM from Vtools where Tools='toolsNotRunning' and Cluster='Escritorios_1' and VM like 'PCS%' and VM not like 'PCS81382' and VM not like 'PCS81383' and VM not like 'PCS81384' and VM not like 'PCS82070' and powerstate='poweredOn'" >> /root/vmware-vsphere-cli-distrib/apps/vm/PCS_not_Tools

cd /root/vmware-vsphere-cli-distrib/apps/vm/
cat PCS_not_Tools | sort | uniq > PCS_not_Tools_notHearbeat
 
cd /root/vmware-vsphere-cli-distrib/apps/vm
sh ToolsESC1notRun.sh
