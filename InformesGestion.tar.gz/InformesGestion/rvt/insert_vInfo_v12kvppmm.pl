#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="RVTvInfo";


# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
my $dbi = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table(idRVTvInfo,VM,DNS_Name,Powerstate,Heartbeat,Consolidation_Needed,PowerOn,CPUs,Memory,NICs,Disks,Network_1,Network_2,Network_3,Network_4,Resource_pool,Folder,vApp,FT_State,FT_Latency,FT_Bandwidth,FT_Sec_Latency,Boot_Required,Provisioned_MB,In_Use_MB,Unshared_MB,Path,Annotation,Servicio_1,Servicio_2,Servicio_3,Ubicacion,DNS,Caducidad,Aplicacion,Causa,Entorno,Fecha_Alta,Fecha_Baja,Migrada,Responsable,Servicio,Ticket,UR,Appliance,Equipo_Peticionario,Datacenter,Cluster,Host,OS,VM_Version,UUID,Object_ID,Vcenter) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
$sti = $dbi->prepare("select idRVTvInfo from RVTvInfo order by idRVTvInfo DESC limit 1");
$sti->execute( );

my $datos=$sti->fetchrow_array( );

$sti->finish;
                                                                        
open (INSERT, "/root/InformesGestion/rvt/RVTools_tabvInfo_V12KVPPMM.csv");


while(<INSERT>) {

$datos++;

chomp;

my ($VM,$DNS_Name,$Powerstate,$Heartbeat,$Consolidation_Needed,$PowerOn,$CPUs,$Memory,$NICs,$Disks,$Network_1,$Network_2,$Network_3,$Network_4,$Resource_pool,$Folder,$vApp,$FT_State,$FT_Latency,$FT_Bandwidth,$FT_Sec_Latency,$Boot_Required,$Provisioned_MB,$In_Use_MB,$Unshared_MB,$Path,$Annotation,$Servicio_1,$Servicio_2,$Servicio_3,$DNS,$Migrada,$Ubicacion,$Ticket,$Aplicacion,$Causa,$Caducidad,$Appliance,$Entorno,$Fecha_Alta,$Fecha_Baja,$Responsable,$Servicio,$UR,$Equipo_Peticionario,$Datacenter,$Cluster,$Host,$OS,$VM_Version,$UUID,$Object_ID) = split /;/;
 
$sth->execute($datos,$VM,$DNS_Name,$Powerstate,$Heartbeat,$Consolidation_Needed,$PowerOn,$CPUs,$Memory,$NICs,$Disks,$Network_1,$Network_2,$Network_3,$Network_4,$Resource_pool,$Folder,$vApp,$FT_State,$FT_Latency,$FT_Bandwidth,$FT_Sec_Latency,$Boot_Required,$Provisioned_MB,$In_Use_MB,$Unshared_MB,$Path,$Annotation,$Servicio_1,$Servicio_2,$Servicio_3,$Ubicacion,$DNS,$Caducidad,$Aplicacion,$Causa,$Entorno,$Fecha_Alta,$Fecha_Baja,$Migrada,$Responsable,$Servicio,$Ticket,$UR,$Appliance,$Equipo_Peticionario,$Datacenter,$Cluster,$Host,$OS,$VM_Version,$UUID,$Object_ID,"V12KVPPMM");

               };

close (INSERT);

$dbh->disconnect;
$dbi->disconnect;
