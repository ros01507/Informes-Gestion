use strict;
use POSIX qw[strftime];
my $yesterday = strftime('%d-%m-%Y', localtime(time - 60 * 60 * 24));

print "Ayer: $yesterday\n";
