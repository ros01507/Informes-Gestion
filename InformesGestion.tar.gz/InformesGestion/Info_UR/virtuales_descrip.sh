echo "############# INICIO ##############"
date
cd /root/InformesGestion/Info_UR

rm -f URsa.txt

perl import_Virtuales_Descrip.pl

cd darkside

perl import_Virtuales_Descrip.pl

cd ..

cd PF

perl import_Virtuales_Descrip.pl
 
cd ..


mysql --host=VLIROMPF.cm.es --database=Informes_Gestion < delVirtDescrip.sql

perl insert_Virtuales_Descrip.pl

echo "############# FIN  ##############"
date
