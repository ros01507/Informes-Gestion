
#/usr/bin/perl
use DBI;
use POSIX qw(strftime);
# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="Virtuales_Descrip";
my ($server,$nssvr);

# PERL MYSQL CONNECT)

my $dbi = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
my $dbk = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

open (INSERT, "URsa.txt");

my $datos=0;

while(<INSERT>) {

$datos++;

chomp;

my ($vmname,$uuid,$servicio,$alta,$baja) = split /;/;
my $nme=substr($vmname,0,9);
$stk = $dbk->prepare("SELECT(ESX)FROM Virtuales_ESX where Nombre_VM like '$nme%'");
$stk->execute( );
$server=$stk->fetchrow_array;
$stk->finish;
$server=substr($server,0,8);
print $server . "\n";
$stk = $dbk->prepare("SELECT(serial) FROM x86_ktpmc where nombreDNS like '$server%'");
$stk->execute( );
$nssvr=$stk->fetchrow_array;
$stk->finish;
print $nssvr . "\n";

$sti = $dbi->prepare("INSERT INTO $table( id,Nombre,uuid,Descripcion,Fecha_Alta,Fecha_Baja,ESX,Serial_ESX) VALUES (?,?,?,?,?,?,?,?)");

$sti->execute( $datos,$vmname,$uuid,$servicio,$alta,$baja,$server,$nssvr);

}

$dbi->disconnect;

close (INSERT);

