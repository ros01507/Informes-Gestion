#/usr/bin/perl
use DBI;
use POSIX qw[strftime];
# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="V2V";
my $existe;
my $yesterday = strftime('%Y-%m-%d', localtime(time - 60 * 60 * 24));

# PERL MYSQL CONNECT)

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
my $dbi = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
my $dbj = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);


open (INSERT, "v2v.txt");

while(<INSERT>) {
chomp;
my ($vmname,$servicio,$aplicacion,$responsable,$ticket,$alta,$iporigen,$ipdestino) = split /;/;


$sth = $dbh->prepare("SELECT * FROM V2V");
$sth->execute( );


my @x_86;
$existe=0;

while (@x_86 = $sth->fetchrow_array) {



if ($x_86[2] eq $vmname) { 

$existe = "1"; 

 }      else {}                                                                                                                               }


if ($existe == '0') {

$stj = $dbh->prepare("SELECT max(id) FROM V2V");
$stj->execute( );
my $datos=$stj->fetchrow_array;
$stj->finish( );

$datos++;
$sti = $dbi->prepare("INSERT INTO $table( id,VM,Servicio,Descripcion,Fecha_Alta,Responsable,Cambio,IP_origen,IP_destino) VALUES (?,?,?,?,?,?,?,?,?)");
$sti->execute( $datos,$vmname,$servicio,$aplicacion,$yesterday,$responsable,$ticket,$iporigen,$ipdestino);
$sti->finish( );
  
                     
                } 
                   }
    $sth->finish( );             
close (INSERT);

$dbh->disconnect;
$dbi->disconnect;


