


my ($vmname,$hostname,$so,$entorno,$alta, $baja, $ticket, $causa, $serial, $soName, $soRelease);


open (INSERT, "UR.txt");


while(<INSERT>) {

chomp;

($vmname,$hostname,$so,$entorno,$alta, $baja, $ticket, $causa, $serial) = split /;/;

if ($so =~ m/Other/) {

open (SO, "so.txt");

while(<SO>) {

($soName, $soRelease) = split /;/;

if ($vmname eq $soName) {
   $so=$soRelease;
print $vmname . "#" .  $so . "\n";

                        } 

}

}
close (SO);
}

close (INSERT);



