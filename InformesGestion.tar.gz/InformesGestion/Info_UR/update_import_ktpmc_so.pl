#/usr/bin/perl
use DBI;
use POSIX qw(strftime);
# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="x86_ktpmc";


# PERL MYSQL CONNECT)

my $dbn = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
#my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);


open (INSERT, "ktpmc_so");

while(<INSERT>) {
chomp;
my ($vmname,$so) = split /;/;

my $stn = $dbn->prepare( "UPDATE $table SET so = '$so' WHERE nombreDNS LIKE '%$vmname%'");
print $vmname . "-->" . $so . "\n";
$stn->execute( );
$stn->finish( );


              }

$dbn->disconnect;
