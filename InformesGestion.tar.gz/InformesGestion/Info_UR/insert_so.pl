
#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="OtherLinux";


# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table( idOtherLinux, Name, so) VALUES (?,?,?)");

open (INSERT, "so.txt");

my $datos=0;

while(<INSERT>) {

$datos++;

chomp;

my ($name,$so) = split /;/;


$sth->execute( $datos, $name, $so);
               };

close (INSERT);

$dbh->disconnect;

