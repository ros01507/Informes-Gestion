
#/usr/bin/perl
use DBI;
use POSIX qw(strftime);
# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="x86_imagenes";

# PERL MYSQL CONNECT)

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
my $dbi = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

open (INSERT, "UR.txt");

my $datos=0;

while(<INSERT>) {

$datos++;

chomp;

my ($vmname,$hostname,$so,$entorno,$alta, $baja, $ticket, $causa, $esxName) = split /;/;

$sti = $dbi->prepare("INSERT INTO $table( id,hostname,Nombre_DNS,serial,so,entorno,fecha_alta,fecha_baja,ticket,causa) VALUES (?,?,?,?,?,?,?,?,?,?)");
$sth = $dbh->prepare("SELECT serial FROM esx WHERE hostname='$esxName'");
$sth->execute( );

my $serial;
$serial = $sth->fetchrow_array( );
$sth->finish( );

my $id= $year . $mes . $mday . $datos;
$sti->execute( $datos,$vmname,$hostname,$serial,$so,$entorno,$alta,$baja,$ticket,$causa );

}

$dbh->disconnect;
$dbi->disconnect;

close (INSERT);

