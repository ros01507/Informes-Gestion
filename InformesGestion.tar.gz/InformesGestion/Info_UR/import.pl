#!/usr/bin/perl

# Copyright 2006 VMware, Inc.  All rights reserved.
#

use strict;

use encoding "ISO-8859-1";


Opts::parse();
Opts::validate();


use VMware::VIRuntime;


my $uuid;
my $so;
my $entorno;
my $alta;
my $baja;
my $ticket;
my $causa;
my $appliance;
my $esxName;
my $key;
my $value;
my $vmnme;
my @vmname;
my $vmname;
my $hostname;
my $UR;
my $prt;
my $key_entorno;
my $key_alta;
my $key_baja;
my $key_ticket;
my $key_causa;
my $key_appliance;
my $key_UR;

Util::connect();

#############################################

##### Obtenemos keys Notes #########

my $CustomFieldsManager = Vim::get_view( mo_ref => Vim::get_service_content()->customFieldsManager );

### Appliance ###

my $field_name= "Appliance";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_appliance=$field_key;

### Causa ###

my $field_name= "Causa";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_causa=$field_key;

### Tiquet ###

# my $field_name= "Tiquet";

my $field_name= "Ticket";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_ticket=$field_key;

### Entorno ###

my $field_name= "Entorno";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_entorno=$field_key;


### UR ###

my $field_name= "UR";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_UR=$field_key;

### Alta ###

my $field_name= "Fecha_Alta";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_alta=$field_key;

### Baja ###

my $field_name= "Fecha_Baja";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_baja=$field_key;

############################################
# Open file,

open (DATOS,">>UR.txt");
   

# get views of all VM's.

my $vm_views = Vim::find_entity_views(view_type => 'VirtualMachine');

foreach (@$vm_views) {


if (!defined ($_->config->name)) {next}

my $so=undef;
my $serial=undef;
my $entorno=undef;
my $alta=undef;
my $baja=undef;
my $ticket=undef;
my $causa=undef;
my $UR=undef;
my $appliance=undef;
	
# get Name to Virtual Machine      
          
   
         $vmnme = $_->config->name;                      
         $uuid = $_->config->uuid;
         my $template= $_->summary->config->template;
          @vmname = split(/\s+/,$vmnme);
          $vmname= $vmname[0];
  
    
     
# get so, vcpu, memory, Disk Capacity
     
    $so= $_->config->guestFullName;
    $hostname= $_->summary->guest->hostName;
    my $custom= $_->summary->customValue;


foreach my $customflds (@$custom) {
  
  $key = $customflds->key;
  $value = $customflds->value;


if ($key eq $key_appliance) {chomp($appliance=$value);}
elsif ($key eq $key_causa) {chomp($causa=$value);}
elsif ($key eq $key_ticket) {chomp($ticket=$value);}
elsif ($key eq $key_entorno) {chomp($entorno=$value);}
elsif ($key eq $key_UR) {chomp($UR=$value);}
elsif ($key eq $key_alta) {chomp($alta=$value);}
elsif ($key eq $key_baja) {chomp($baja=$value);}
else {}
 };

# Print in to file.
if (($UR eq "S") && ($appliance eq "S")) {

# print $vmnme . "\n";
                     
  print DATOS  $vmnme . ";" . $hostname . ";" . $so . ";" . $entorno . ";" . $alta . ";" . $baja . ";" . $ticket . ";" . $causa . ";" . $uuid . "\n";

};

};

Util::disconnect();

close (DATOS);

sub FindCustomFieldKey {
     
     my ($cfm, $field_name) = @_;
     my ($field_key, @custom_fields);
     if ($cfm->field) {
          @custom_fields = @{$cfm->field};
     }
     else {
          # No custom fields defined, return undef
          return undef;
     }
     
     foreach my $field ( @custom_fields ) {
          if ($field->name eq $field_name) {
               $field_key = $field->key;
               last;
          }
     }
     
     # will be undef if no matching field to $field_name is found
     return $field_key;
}
