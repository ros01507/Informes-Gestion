#/usr/bin/perl
use DBI;
use POSIX qw(strftime);
# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="x86_imagenes";

my ($sql,$rs,$sql_update_result);
my $existe=0;




# PERL MYSQL CONNECT)

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
#my $dbj = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
my $dbn = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
my $dbi = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

# sth = $dbh->prepare("SELECT COUNT(*) FROM x86_imagenes");
$sth = $dbh->prepare("select id from x86_imagenes order by id DESC limit 1");
$sth->execute( );
my $datos=$sth->fetchrow_array( );
$sth->finish;

open (INSERT, "UR.txt");
    
while(<INSERT>) {

#$datos++;

chomp;

my ($vmname,$hostname,$so,$entorno,$alta, $baja, $ticket, $causa, $serial) = split /;/;

#$stj = $dbj->prepare("SELECT serial FROM esx WHERE hostname='$esxName'");
#$stj->execute( );

#my $serial;
#$serial = $stj->fetchrow_array( );
#$stj->finish( );



$sth = $dbh->prepare("SELECT * FROM x86_imagenes");
$sth->execute( );



my @x_86;
$existe=0;

while (@x_86 = $sth->fetchrow_array) {



if ($x_86[2] eq $vmname) { 

$existe = "1"; 

print "Al menos uno de los campos ha cambiado" . "\n";

print "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@" . "\n";
print $x_86[2] . "###" . $vmname . "\n";
print $x_86[8] .  "###" . $baja . "\n";
print $x_86[9] .  "###" . $ticket . "\n";
print $x_86[10] . "###" . $causa . "\n";
print $x_86[4] . "###" . $serial . "\n";
print "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@" . "\n";


my $stn = $dbn->prepare( "UPDATE $table SET entorno = '$entorno',fecha_alta = '$alta',fecha_baja = '$baja', serial = '$serial', ticket = '$ticket', causa = '$causa' WHERE hostname = '$vmname'");

$stn->execute( );
$stn->finish( );

 }      else {}                                                                                                                               }


if ($existe == '0') {

print "NO EXISTEEEEEEE" . "\n";
print "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@" . "\n";
print $x_86[2] . $vmname . "\n";
print $x_86[8] . $baja . $x_86[9] . $ticket . $x_86[10] . $causa . $x_86[4] . $serial . "\n";
print "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@" . "\n";


$datos++;
$sti = $dbi->prepare("INSERT INTO $table( id,hostname,Nombre_DNS,serial,so,entorno,fecha_alta,fecha_baja,ticket,causa) VALUES (?,?,?,?,?,?,?,?,?,?)");
$sti->execute( $datos,$vmname,$hostname,$serial,$so,$entorno,$alta,$baja,$ticket,$causa );
$sti->finish( );



               
                     
                } 
                   }
                 
close (INSERT);


$dbh->disconnect;
#$dbj->disconnect;
$dbi->disconnect;

