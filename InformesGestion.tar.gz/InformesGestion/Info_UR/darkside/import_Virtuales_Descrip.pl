#!/usr/bin/perl

# Copyright 2006 VMware, Inc.  All rights reserved.
#

use strict;

use encoding "ISO-8859-1";

$ENV{VI_SERVER}="V12KVPPMM.grupo.cm.es";
$ENV{VI_URL}="https://V12KVPPMM.grupo.cm.es/sdk/webService";


Opts::parse();
Opts::validate();


use VMware::VIRuntime;


my $uuid;
my $servicio;
my $servicio1;
my $servicio2;
my $servicio3;
my $key;
my $value;
my $vmnme;
my @vmname;
my $vmname;
my $UR;
my $alta;
my $baja;
my $caracter;


Util::connect();

# Open file,

open (DATOS,">>../URsa.txt");
   


# get views of all VM's.
my $vm_views = Vim::find_entity_views(view_type => 'VirtualMachine');

foreach (@$vm_views) {


if (!defined ($_->config->name)) {next}

$UR=undef;
$uuid=undef;
$servicio=undef;
$servicio1=undef;
$servicio2=undef;

	
# get Name to Virtual Machine      
          
   
         $vmnme = $_->config->name;
         $uuid =  $_->config->uuid;                      
         my $template= $_->summary->config->template;
          @vmname = split(/\s+/,$vmnme);
          $vmname= $vmname[0];
  
    
     
# get so, vcpu, memory, Disk Capacity
     
    my $custom= $_->summary->customValue;


foreach my $customflds (@$custom) {
  
  $key = $customflds->key;
  $value = $customflds->value;


if ($key eq "13") {chomp($servicio1=$value);}
elsif ($key eq "17") {chomp($UR=$value);}
elsif ($key eq "14") {chomp($servicio2=$value);}
elsif ($key eq "15") {chomp($servicio3=$value);}
elsif ($key eq "8") {chomp($alta=$value);}
elsif ($key eq "9") {chomp($baja=$value);}

else {}
};


$servicio=$servicio1 . "." . $servicio2 . "." . $servicio3;

$caracter=substr($vmnme, 0, 1);

if (($UR eq "S") && ($caracter ne "@") && ($template != '1')) {
                     
  print DATOS  $vmnme . ";" . $uuid . ";" . $servicio . ";" . $alta . ";" . $baja . "\n";

$servicio="";
$servicio1="";
$servicio2="";
$servicio3="";
                                                                };
                   };

close (DATOS);
Util::disconnect();
