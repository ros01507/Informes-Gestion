
echo "############# INICIO ##############"
date

### Script de importacion datos a tabla x86_imagenes ###

cd /root/InformesGestion/Info_UR

### Borramos fichero de datos

rm -f UR.txt

### Importamos a fichero informacion maquinas virtuales VCENTDPL ###

perl import.pl

### Importamos a fichero informacion maquinas virtuales PPMM ###

cd darkside

perl import.pl

cd ..

### Importamos a fichero informacion maquinas virtuales VCENTER Pure Flex ###

cd PF

perl import.pl

cd ..

### Importamos a fichero informacion ESX ###

perl import_ESX86.pl

### Por ultimos insertamos datos en tabla x86_imagenes, actualizando aquellos que existan en la tabla y anadiendo aquellos que no existan ###

perl update_import_UR.pl

echo "############# FIN  ##############"
date


