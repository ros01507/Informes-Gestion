#!/usr/bin/perl

# Copyright 2006 VMware, Inc.  All rights reserved.
#
use DBI;
use POSIX qw(strftime);
# MYSQL CONFIG VARIABLES

use strict;

use encoding "ISO-8859-1";

Opts::parse();
Opts::validate();

use VMware::VIRuntime;

my $alta;
my $ticket;
my $key;
my $value;
my $vmnme;
my $UR;
my $appliance;
my $key_servicio;
my $key_responsable;
my $key_ticket;
my $key_alta;
my $key_aplicacion;
my $key_migrada;
my $key_UR;
my $key_appliance;
my $caracter;
my $caracter1;
my $caracter2;

my $template;

Util::connect();

#############################################

##### Obtenemos keys Notes #########

my $CustomFieldsManager = Vim::get_view( mo_ref => Vim::get_service_content()->customFieldsManager );

### Appliance ###

my $field_name= "Appliance";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_appliance=$field_key;

### UR ###

my $field_name= "UR";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_UR=$field_key;

### Ticket ###

my $field_name= "Ticket";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_ticket=$field_key;

### Servicio ###

my $field_name= "Servicio";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_servicio=$field_key;

### Alta ###

my $field_name= "Fecha_Alta";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_alta=$field_key;

### Responsable ###

my $field_name= "Responsable";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_responsable=$field_key;

### Aplicacion ###

my $field_name= "Aplicacion";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_aplicacion=$field_key;

### Migrada ###

my $field_name= "Migrada";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_migrada=$field_key;

############################################

# Open file,

open (DATOS,">>pendientes_v2v.txt");
   

# get views of all VM's.

my $vm_views = Vim::find_entity_views(view_type => 'VirtualMachine');

foreach (@$vm_views) {

if (!defined ($_->config->name)) {next}

my $alta=undef;
my $ticket=undef;
my $servicio=undef;
my $aplicacion=undef;
my $responsable=undef;
my $migrada=undef;
my $servicio=undef;
my $ipOrigen=undef;
my $ipDestino=undef;	

# get Name to Virtual Machine      
          
   
         $vmnme = $_->config->name;
         my $template= $_->summary->config->template;

     
    
     
# get so, vcpu, memory, Disk Capacity
     
    my $custom= $_->summary->customValue;

foreach my $customflds (@$custom) {
  
  $key = $customflds->key;
  $value = $customflds->value;


if ($key eq $key_aplicacion) {chomp($aplicacion=$value);}
elsif ($key eq $key_servicio) {chomp($servicio=$value);}
elsif ($key eq $key_ticket) {chomp($ticket=$value);}
elsif ($key eq $key_responsable) {chomp($responsable=$value);}
elsif ($key eq $key_migrada) {chomp($migrada=$value);}
elsif ($key eq $key_alta) {chomp($alta=$value);}
elsif ($key eq $key_migrada) {chomp($migrada=$value);}
elsif ($key eq $key_UR) {chomp($UR=$value);}
elsif ($key eq $key_appliance) {chomp($appliance=$value);}
else {}
 };

# Print in to file.


if (($UR eq "S") && ($vmnme !~ m/PCS|VID/) && ($template != '1') && ($vmnme !~ m/Template/) && ($vmnme !~ m/^F|^SOA|^f|^P|^p/)){
  print $vmnme . "\n";                   
  print DATOS  $vmnme . ";" . $servicio . ";" . $aplicacion . ";" . $responsable . ";" . $ticket . ";" . $alta . ";" . $ipOrigen . ";" . $ipDestino . "\n";

};

};


Util::disconnect();

close (DATOS);

sub FindCustomFieldKey {
     
     my ($cfm, $field_name) = @_;
     my ($field_key, @custom_fields);
     if ($cfm->field) {
          @custom_fields = @{$cfm->field};
     }
     else {
          # No custom fields defined, return undef
          return undef;
     }
     
     foreach my $field ( @custom_fields ) {
          if ($field->name eq $field_name) {
               $field_key = $field->key;
               last;
          }
     }
     
     # will be undef if no matching field to $field_name is found
     return $field_key;
}
