### Script de importacion v2p ###

cd /root/InformesGestion/Info_UR
rm -f v2v.txt
perl import_v2v.pl
perl update_import_migrate.pl




