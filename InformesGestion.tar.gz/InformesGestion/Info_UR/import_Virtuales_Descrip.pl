#!/usr/bin/perl

# Copyright 2006 VMware, Inc.  All rights reserved.
#

use strict;

Opts::parse();
Opts::validate();

use VMware::VIRuntime;
use encoding "ISO-8859-1";

my $uuid;
my $servicio;
my $entorno;
my $alta;
my $baja;
my $ticket;
my $causa;
my $appliance;
my $esxName;
my $key;
my $value;
my $vmnme;
my @vmname;
my $vmname;
my $hostname;
my $UR;
my $prt;
my $caracter;
my $powerstate;
my $key_servicio;
my $key_alta;
my $key_baja;
my $key_UR;

Util::connect();

#############################################

##### Obtenemos keys Notes #########

my $CustomFieldsManager = Vim::get_view( mo_ref => Vim::get_service_content()->customFieldsManager );

### Servicio ###

my $field_name= "Servicio";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_servicio=$field_key;

### Alta ###

my $field_name= "Fecha_Alta";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_alta=$field_key;

### Baja ###

my $field_name= "Fecha_Baja";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_baja=$field_key;

### UR ###

my $field_name= "UR";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

$key_UR=$field_key;  	

############################################

# Open file,

open (DATOS,">>URsa.txt");
   


# get views of all VM's.
my $vm_views = Vim::find_entity_views(view_type => 'VirtualMachine');

foreach (@$vm_views) {


if (!defined ($_->config->name)) {next}

my $UR=undef;
	
# get Name to Virtual Machine      
          
   
         $vmnme = $_->config->name;
         $uuid =  $_->config->uuid;                      
         my $template= $_->summary->config->template;
          @vmname = split(/\s+/,$vmnme);
          $vmname= $vmname[0];
          $powerstate= $_->runtime->powerState->val;
     
# get so, vcpu, memory, Disk Capacity
     
    my $custom= $_->summary->customValue;


foreach my $customflds (@$custom) {
  
  $key = $customflds->key;
  $value = $customflds->value;


if ($key eq $key_servicio) {chomp($servicio=$value);}
elsif ($key eq $key_UR) {chomp($UR=$value);}
elsif ($key eq $key_alta) {chomp($alta=$value);}
elsif ($key eq $key_baja) {chomp($baja=$value);}
else {}
};

$caracter=substr($vmnme, 0, 1);

if (($UR eq "S") && ($caracter ne "@") && ($template != '1') && ($powerstate eq "poweredOn")) {
                     
  print DATOS  $vmnme . ";" . $uuid . ";" . $servicio . ";" . $alta . ";" . $baja . "\n";

                                                                };
                   };

close (DATOS);
Util::disconnect();


sub FindCustomFieldKey {
     
     my ($cfm, $field_name) = @_;
     my ($field_key, @custom_fields);
     if ($cfm->field) {
          @custom_fields = @{$cfm->field};
     }
     else {
          # No custom fields defined, return undef
          return undef;
     }
     
     foreach my $field ( @custom_fields ) {
          if ($field->name eq $field_name) {
               $field_key = $field->key;
               last;
          }
     }
     
     # will be undef if no matching field to $field_name is found
     return $field_key;
}
