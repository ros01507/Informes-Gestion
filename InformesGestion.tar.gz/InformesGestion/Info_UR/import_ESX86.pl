#/usr/bin/perl
use DBI;
use POSIX qw(strftime);
# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";

my @row;


# PERL MYSQL CONNECT)

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
#my $dbj = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

open (DATOS,">>UR.txt");


$sth = $dbh->prepare( "select * from x86_ktpmc where so like '%ESX%'");
$sth->execute( );


my $datos=0;


my @row;
while ( @row = $sth->fetchrow_array( ) ) {

#$stj = $dbj->prepare("SELECT serial FROM esx WHERE hostname='$row[9]'");
#$stj->execute( );
#my $serial;
#$serial = $stj->fetchrow_array( );
#$stj->finish( );


$datos++;
# row[0] =~ s/\r//g;


print DATOS  $row[10] . ";" . $row[10] . ".cm.es" .  ";" . $row[14] . ";" . $row[13] . ";" . $row[15] . ";" . $row[16] . ";" . $row[17] . ";" . $row[18] . ";" . $row[9] . "\n";


}

$dbh->disconnect;
#$dbj->disconnect;


