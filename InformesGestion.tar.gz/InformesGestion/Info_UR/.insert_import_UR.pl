
#/usr/bin/perl
use DBI;
use POSIX qw(strftime);
# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="VDIs";
my $table1="Num_sesiones_Pools";
my @row;
my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);

#my $fecha = strftime "%Y-%m %H:%M:%S", localtime;

my $fecha;
my $mes=$mon+1;


if($mon == 0 ) {$mess="Enero";$mes="01";}
elsif($mon == 1) {$mess="Febrero";$mes="02";}
elsif($mon == 2) {$mess="Marzo";$mes="03";}
elsif($mon == 3) {$mess="Abril";$mes="04";}
elsif($mon == 4) {$mess="Mayo";$mes="05";}
elsif($mon == 5) {$mess="Junio";$mes="06";}
elsif($mon == 6) {$mess="Julio";$mes="07";}
elsif($mon == 7) {$mess="Agosto";$mes="08";}
elsif($mon == 8) {$mess="Septiembre";$mes="09";}
elsif($mon == 9) {$mess="Octubre";}
elsif($mon == 10) {$mess="Noviembre";}
elsif ($mon == 11) {$mess="Diciembre";}
print $mes . "\n";
$year= $year + 1900;

if($mday == 1 ) {$mday="01";}
elsif($mday == 2) {$mday="02";}
elsif($mday == 3) {$mday="03";}
elsif($mday == 4) {$mday="04";}
elsif($mday == 5) {$mday="05";}
elsif($mday == 6) {$mday="06";}
elsif($mday == 7) {$mday="07";}
elsif($mday == 8) {$mday="08";}
elsif($mday == 9) {$mday="09";}



# PERL MYSQL CONNECT)

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
my $dbi = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);


$sti = $dbi->prepare("INSERT INTO $table1( idNum_sesiones_Pool, Dia, Mes, Ano, Sesiones, PoolName) VALUES (?,?,?,?,?,?)");

$sth = $dbh->prepare( "select PoolName, count(*) from VDIs group by PoolName");
$sth->execute( );

my $datos=0;
#$fecha=$mday . $mes . $year;

my @row;
while ( @row = $sth->fetchrow_array( ) ) {

$datos++;
$row[0] =~ s/\r//g;

#my $id= $mday . $mes . $year . $datos;
my $id= $year . $mes . $mday . $datos;
$sti->execute( $id,$mday,$mess,$year,$row[1],$row[0]);
#print $mday . $mes . $year . $datos . ";" . $mday . ";" . $mess . ";" . $year . ";" . $row[1] . ";" . $row[0] . "\n"; 

}

$dbh->disconnect;
$dbi->disconnect;
