#!/usr/bin/perl

# Copyright 2006 VMware, Inc.  All rights reserved.
#
use DBI;
use POSIX qw(strftime);
# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="Direcciones_IP";
my $user;
my $password;
my $sth;
use strict;

use encoding "ISO-8859-1";

$ENV{VI_SERVER}="s8kvcent.cm.es";
$ENV{VI_URL}="https://s8kvcent.cm.es/sdk/webService";

Opts::parse();
Opts::validate();

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

use VMware::VIRuntime;

my $alta;
my $ticket;
my $key;
my $value;
my $vmnme;
my $key_servicio;
my $key_responsable;
my $key_ticket;
my $key_alta;
my $key_aplicacion;
my $key_migrada;

Util::connect();

#############################################

##### Obtenemos keys Notes #########

my $CustomFieldsManager = Vim::get_view( mo_ref => Vim::get_service_content()->customFieldsManager );


### Ticket ###

my $field_name= "Ticket";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_ticket=$field_key;

### Servicio ###

my $field_name= "Servicio";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_servicio=$field_key;

### Alta ###

my $field_name= "Fecha_Alta";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_alta=$field_key;

### Responsable ###

my $field_name= "Responsable";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_responsable=$field_key;

### Aplicacion ###

my $field_name= "Aplicacion";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_aplicacion=$field_key;

### Migrada ###

my $field_name= "Migrada";

my $field_key = FindCustomFieldKey($CustomFieldsManager, $field_name);

# print $field_name . " es: " . $field_key . "\n";

$key_migrada=$field_key;

############################################

# Open file,

open (DATOS,">>v2v.txt");
   

# get views of all VM's.

my $vm_views = Vim::find_entity_views(view_type => 'VirtualMachine');

foreach (@$vm_views) {

if (!defined ($_->config->name)) {next}

my $alta=undef;
my $ticket=undef;
my $servicio=undef;
my $aplicacion=undef;
my $responsable=undef;
my $migrada=undef;
my $servicio=undef;
my $ipOrigen=undef;
my $ipDestino=undef;	

# get Name to Virtual Machine      
          
   
         $vmnme = $_->config->name;
     my $ipDestino = $_->guest->ipAddress;
    

# get IP address

# PERL MYSQL CONNECT)

$sth = $dbh->prepare("select (Direccion_IP) from Direcciones_IP where VM='$vmnme' order by VM DESC limit 1");
$sth->execute( );
$ipOrigen=$sth->fetchrow_array( );
$sth->finish;                  
    
     
# get so, vcpu, memory, Disk Capacity
     
    my $custom= $_->summary->customValue;

foreach my $customflds (@$custom) {
  
  $key = $customflds->key;
  $value = $customflds->value;


if ($key eq $key_aplicacion) {chomp($aplicacion=$value);}
elsif ($key eq $key_servicio) {chomp($servicio=$value);}
elsif ($key eq $key_ticket) {chomp($ticket=$value);}
elsif ($key eq $key_responsable) {chomp($responsable=$value);}
elsif ($key eq $key_migrada) {chomp($migrada=$value);}
elsif ($key eq $key_alta) {chomp($alta=$value);}
elsif ($key eq $key_migrada) {chomp($migrada=$value);}
else {}
 };

# Print in to file.


if ($migrada eq "S") {

  print $vmnme . ":" . $migrada . "\n";                   
  print DATOS  $vmnme . ";" . $servicio . ";" . $aplicacion . ";" . $responsable . ";" . $ticket . ";" . $alta . ";" . $ipOrigen . ";" . $ipDestino . "\n";

};

};

$dbh->disconnect;
Util::disconnect();

close (DATOS);

sub FindCustomFieldKey {
     
     my ($cfm, $field_name) = @_;
     my ($field_key, @custom_fields);
     if ($cfm->field) {
          @custom_fields = @{$cfm->field};
     }
     else {
          # No custom fields defined, return undef
          return undef;
     }
     
     foreach my $field ( @custom_fields ) {
          if ($field->name eq $field_name) {
               $field_key = $field->key;
               last;
          }
     }
     
     # will be undef if no matching field to $field_name is found
     return $field_key;
}
