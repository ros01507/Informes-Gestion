
#/usr/bin/perl
use DBI;
use POSIX qw(strftime);
# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="Virtuales_Descrip";

# PERL MYSQL CONNECT)

my $dbi = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

open (INSERT, "URsa.txt");

my $datos=0;

while(<INSERT>) {

$datos++;

chomp;

my ($vmname,$uuid,$servicio,$alta,$baja) = split /;/;

$sti = $dbi->prepare("INSERT INTO $table( id,Nombre,uuid,Descripcion,Fecha_Alta,Fecha_Baja) VALUES (?,?,?,?,?,?)");

$sti->execute( $datos,$vmname,$uuid,$servicio,$alta,$baja);

}

$dbi->disconnect;

close (INSERT);

