perl clus.pl 
perl dts.pl 
