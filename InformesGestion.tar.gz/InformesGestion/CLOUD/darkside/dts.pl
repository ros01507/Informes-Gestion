#!/usr/bin/perl -w
#use locale;
use strict;
use warnings;
use Getopt::Long;
use VMware::VIRuntime;
use VMware::VILib;


		 
# validate options, and connect to the server

$ENV{VI_SERVER}="V12KVPPMM.grupo.cm.es";
$ENV{VI_URL}="https://V12KVPPMM.grupo.cm.es/sdk/webService";

Opts::parse();
Opts::validate();
Util::connect();

my $capacity;
my $free;
my $ocupado;
my $capacidad;
my $esp_ocupado;
my $datacenter ;
my $datastores;

# Open file,

open (DATOS,">>/root/InformesGestion/Datastore/datosDatacenter.txt");

 my $datacenters = Vim::find_entity_views (view_type => 'Datacenter');

foreach $_ (@$datacenters) {

    my $dataStores = Vim::get_views (mo_ref_array => $_->datastore);
    foreach my $datastore (@$dataStores) {
    
    if ($datastore->info->name !~ /^Interno/ && $datastore->info->name !~ /^CUARENTENA/ &&  $datastore->info->name !~ /^VMFS_NFS_c-/) {

    $capacity=$datastore->summary->capacity;
    $free=$datastore->info->freeSpace;
    if ($free eq 0 ) {$ocupado = 100} else {
   
    $esp_ocupado=($capacity-$free);
    $ocupado=$esp_ocupado;
    $ocupado=($ocupado*100)/$capacity;
    $ocupado=sprintf("%.2f",$ocupado);
                                     }
     $capacidad=($capacity/1073741824);
     $esp_ocupado=($esp_ocupado/1073741824);
     $free=($free/1073741824);
     $free=sprintf("%.2f",$free);
     $esp_ocupado=sprintf("%.2f",$esp_ocupado);

     print DATOS $_->name . "," . $datastore->info->name . "," . $ocupado . ","  . $capacidad . "," . $esp_ocupado . "," . $free . "\n";

                                           }
            }
            }
        print "\n";
close (DATOS);
Util::disconnect();

sub Fail {
    my ($msg) = @_;
    Util::disconnect();
    die ($msg);
    exit ();
}

