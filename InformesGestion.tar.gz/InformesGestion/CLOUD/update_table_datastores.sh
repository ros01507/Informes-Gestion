cd /root/InformesGestion/Datastore

rm -f datos.txt
rm -f datosDatacenter.txt

perl clus.pl
perl dts.pl

cd /root/InformesGestion/Datastore/PF

perl clus.pl
perl dts.pl

cd /root/InformesGestion/Datastore

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "DELETE FROM Datastores;" 
mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "DELETE FROM Datastores_por_Datacenter;"

perl insert_datastore.pl
perl insert_datastore_datacenter.pl
