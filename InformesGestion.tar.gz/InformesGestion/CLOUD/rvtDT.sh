################  Tabla Datos Datastore #############

cd /root/InformesGestion/CLOUD
rm -f *.csv
sed '1d' /datos/usuarios/A163440/rvt/vcentdpl/RVTools_tabvDatastore.csv > /root/InformesGestion/CLOUD/RVTools_tabvDatastore_VCENTDPL.csv
sed '1d' /datos/usuarios/A163440/rvt/s8kvcent/RVTools_tabvDatastore.csv > /root/InformesGestion/CLOUD/RVTools_tabvDatastore_S8KVCENT.csv
sed '1d' /datos/usuarios/A163440/rvt/V12KVPPMM/RVTools_tabvDatastore.csv > /root/InformesGestion/CLOUD/RVTools_tabvDatastore_V12KVPPMM.csv

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion -e "delete from RVT_Datastore"

perl insert_Datastore_vcentdpl.pl
perl insert_Datastore_s8kvcent.pl
perl insert_Datastore_v12kvppmm.pl


#mysql --host=VLIROMPF.cm.es --database=Informes_Gestion -e "select Free_MB from RVT_Datastore;"
