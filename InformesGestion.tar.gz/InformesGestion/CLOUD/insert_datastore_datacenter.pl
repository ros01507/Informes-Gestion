#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES
my $database = "Informes_Gestion";
my $table="Datastores_por_Datacenter";
my $clus;
my $cluster;

# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
$sth = $dbh->prepare("INSERT INTO $table( idDatastores_por_Datacenter, Nombre_Datacenter, Nombre_Datastore, Ocupacion_Percent, Capacidad_Datastore, Ocupado_Datastore, Libre_Datastore, Grupo_Almacenamiento) VALUES (?,?,?,?,?,?,?,?)");

open (INSERT, "datosDatacenter.txt");

 my $datos=0;

while(<INSERT>) {

 $datos++;

chomp;

my ($namedatacenter, $namedatastore, $ocup, $capacidad , $usado,$free) = split /,/;

# Clasificacion Grupos de Almacenamiento 

if ( $namedatastore=~ /^pro/ && $namedatastore=~ /clro01$/ ){$grupo=1;}  
elsif ($namedatastore=~ /^pro/ && $namedatastore=~ /clro02$/) {$grupo=2;}
elsif ( $namedatastore=~ /^pro/ && $namedatastore=~ /clro03$/) {$grupo=3;}
elsif ($namedatastore=~ /^cor/ && $namedatastore=~ /clcr01$/ ) {$grupo=4;}
elsif ($namedatastore =~ /^extfc/ && $namedatastore=~ /naro01$/ ) {$grupo=5;}
elsif ($namedatastore =~ /^prosa/ && $namedatastore=~ /naro01$/ ) {$grupo=6;}
elsif ($namedatastore =~ /^prosa/ && $namedatastore=~ /naro01-lab$/ ) {$grupo=7;}
elsif ( $namedatastore =~ /^tstsa/ && $namedatastore=~ /naro01$/) {$grupo=8;}
elsif ( $namedatastore =~ /^tst/ && $namedatastore=~ /clro02$/) {$grupo=9;}
elsif ( $namedatastore =~ /^tst/ && $namedatastore=~ /clro03$/) {$grupo=10;}
elsif ( $namedatastore =~ /^NFS/ && $namedatastore=~ /SATA$/) {$grupo=12;}
elsif ( $namedatastore =~ /^NFS/) {$grupo=11;}
elsif ( $namedatastore  =~ /DMX3/ || $namedatastore=~ /Desarrollo_Pool_b/ || $namedatastore=~ /Desarrollo_Test/) {$grupo=15;}
elsif ( $namedatastore =~ /^DMX800/) {$grupo=16;}
elsif ( $namedatastore =~ /^Produccion_COR_DMX4/ ) {$grupo=17;}
elsif ( $namedatastore =~ /DMX800/ ) {$grupo=18;}
elsif ( $namedatastore =~ /DS8100/ ) {$grupo=19;}
elsif ( $namedatastore =~ /DS8300/ ) {$grupo=22;}
elsif ( $namedatastore =~ /DMX2000/) {$grupo=20;}
elsif ( $namedatastore =~ /VMFS_NFS_HDS/) {$grupo=21;}
elsif ( $namedatastore =~ /^Desarrollo_Clariion_/ ){$grupo=14;}
elsif ( $namedatastore =~ /datastore/ ){$grupo=23;}
elsif ( $namedatastore =~ /isos/ || $namedatastore =~ /templates/) {$grupo=24;}
elsif ( $namedatastore =~ /^pross/ && $namedatastore =~ /naro01$/ ) {$grupo=25;}
elsif ( $namedatastore =~ /TST_ROZ_VMAX3_SATA/ ) {$grupo=26;}
elsif ( $namedatastore =~ /TST_COR_VMAX2_SATA/ ) {$grupo=27;}
elsif ( $namedatastore =~ /Produccion_DS8300_Rozas/ ) {$grupo=28;}
elsif ( $namedatastore =~ /Produccion_DS8100_COR/ ) {$grupo=29;}
elsif ( $namedatastore =~ /PRO_ROZ_VMAX3_FC6/ ) {$grupo=30;}
elsif ( $namedatastore =~ /PRO_COR_VMAX2_FC6/ ) {$grupo=31;}
elsif ( $namedatastore =~ /DES_ROZ_VMAX3_SATA/ ) {$grupo=32;}
elsif ( $namedatastore =~ /^pro/ && $name=~ /svcro$/) {$grupo=33;}
elsif ( $name =~ /^cor/ && $name=~ /svc$/) {$grupo=34;}
else {$grupo=13;}



$sth->execute( $datos, $namedatacenter, $namedatastore, $ocup, $capacidad , $usado, $free, $grupo);
               };

close (INSERT);

$dbh->disconnect;

# idDatastore
