#!/usr/bin/perl -w
#use locale;
use strict;
use warnings;
use Getopt::Long;
use VMware::VIRuntime;
use VMware::VILib;


		 
# validate options, and connect to the server
Opts::parse();
Opts::validate();
Util::connect();

my $effectiveMemory;
my $totalMemory;

# Open file,

open (DATOS,">>datos.txt");

 my $clusters = Vim::find_entity_views (view_type => 'ClusterComputeResource');

foreach my $cluster (@$clusters) {
    
   $effectiveMemory= $cluster->summary->effectiveMemory;
   $totalMemory=$cluster->summary->totalMemory;
   print $cluster->name . ":" . "Memoria_Efectiva:" . $effectiveMemory . " Memoria_Total:" . $totalMemory . "\n";
   print "\n";
            }
close (DATOS);
Util::disconnect();

sub Fail {
    my ($msg) = @_;
    Util::disconnect();
    die ($msg);
    exit ();
}

