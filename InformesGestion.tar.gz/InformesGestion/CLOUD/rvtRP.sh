################  Tabla Datos Resources #############

cd /root/InformesGestion/CLOUD
rm -f *.csv
sed '1d' /datos/usuarios/A163440/rvt/vcentdpl/RVTools_tabvRP.csv > /root/InformesGestion/CLOUD/RVTools_tabvRP_VCENTDPL.csv
sed '1d' /datos/usuarios/A163440/rvt/s8kvcent/RVTools_tabvRP.csv > /root/InformesGestion/CLOUD/RVTools_tabvRP_S8KVCENT.csv
sed '1d' /datos/usuarios/A163440/rvt/V12KVPPMM/RVTools_tabvRP.csv > /root/InformesGestion/CLOUD/RVTools_tabvRP_V12KVPPMM.csv

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion -e "delete from RVT_RP"

perl insert_RP_vcentdpl.pl
perl insert_RP_s8kvcent.pl
perl insert_RP_v12kvppmm.pl


mysql --host=VLIROMPF.cm.es --database=Informes_Gestion -e "select Resource_pool, Mem_imit - Mem_Configured as Memoria_Disponible from RVT_RP where  Resource_pool LIKE '%Cloud_ROZ%';"
