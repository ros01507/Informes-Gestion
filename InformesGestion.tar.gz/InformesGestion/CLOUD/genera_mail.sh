
echo "Buenos dias," > Almacenamiento

echo "  " >> Almacenamiento

echo "ALMACENAMIENTO:" >> Almacenamiento

echo "  " >> Almacenamiento

echo "A continuacion se muestran las LUNs cuyo espacio libre es mayor o igual a 600 GB, se ha definido un umbral de 10 LUNs como correcto." >> Almacenamiento

echo "  " >> Almacenamiento

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion -e "SELECT Name,round(Free_MB/1024,2) as Free_GB from Informes_Gestion.RVT_Datastore where Name LIKE 'CLOU%' and Free_MB > 614400;" >> Almacenamiento

echo "  " >> Almacenamiento

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "SELECT count(*) FROM Informes_Gestion.RVT_Datastore where Name LIKE 'CLOU%' and Free_MB > 614400;" | awk '{if ($1 <= 8){print "El numero total de LUNs con 600G de espacio libre es de " $1 ", WARNING !!! NO ES CORRECTO, considere ampliar el almacenamiento en el cluster de CLOUD para evitar incidencias en el despliegue de maquinas virtuales."}else {print "El numero total de LUNs con 500G de espacio libre es de " $1 ", en estos momentos el valor es CORRECTO."}}' >> Almacenamiento 

echo "  " >> Almacenamiento

echo "MEMORIA:" >> Almacenamiento

echo "  " >> Almacenamiento

mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-name -e "select round((Mem_imit - Mem_Configured)/1024,0) as Memoria_GB_Disponible from RVT_RP where Resource_pool LIKE '%Cloud_ROZ%';" | awk '{{ print "La memoria disponible en GB en el cluster de CLOUD es de " $1 "."}}' >> Almacenamiento

echo "  "  >> Almacenamiento


mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select round((Mem_imit - Mem_Configured)/1024/16,0) as Virtuales_por_Memoria_Disponible from RVT_RP where  Resource_pool LIKE '%Cloud_ROZ%';" | awk '{{print "El total de maquinas virtuales con 16 GB de RAM que se podrian desplegar en el entorno es de "$1 "."}}' >> Almacenamiento

echo "  " >> Almacenamiento


mysql --host=VLIROMPF.cm.es --database=Informes_Gestion --skip-column-names -e "select COUNT(*) From RVTvInfo where Cluster='Cloud_ROZ';" | awk '{print "El total de maquinas virtuales desplegadas en el cluster es de " $1 "."}' >> Almacenamiento

echo "  " >> Almacenamiento

echo "Un saludo" >> Almacenamiento
