#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="RVT_RP";


# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
#my $dbi = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table(idRVT_RP,Resource_pool,Status,VMs,vCPUs,CPU_limit,CPU_overheadLimit,CPU_reservation,CPU_level,CPU_shares,CPU_expandableReservation,CPU_maxUsage,CPU_overallUsage,CPU_reservationUsed,CPU_reservationUsedForVm,CPU_unreservedForPool,CPU_unreservedForVm,Mem_Configured,Mem_imit,Mem_overheadLimit,Mem_reservation,Mem_level,Mem_shares,Mem_expandableReservation,Mem_maxUsage,Mem_overallUsage,Mem_reservationUsed,Mem_reservationUsedForVm,Mem_unreservedForPool,Mem_unreservedForVm,QS_overallCpuDemand,QS_overallCpuUsage,QS_staticCpuEntitlement,QS_distributedCpuEntitlement,QS_balloonedMemory,QS_compressedMemory,QS_consumedOverheadMemory,QS_distributedMemoryEntitlement,QS_guestMemoryUsage,QS_hostMemoryUsage,QS_overheadMemory,QS_privateMemory,QS_sharedMemory,QS_staticMemoryEntitlement,QS_swappedMemory) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

#$sti = $dbi->prepare("select idRVT_RP from RVT_RP order by idRVT_RP DESC limit 1");
#$sti->execute( );

#my $datos=$sti->fetchrow_array( );
my $datos=0;

#$sti->finish;
                                                                        
open (INSERT, "RVTools_tabvRP_VCENTDPL.csv");


while(<INSERT>) {

$datos++;

chomp;

my ($A,$B,$C,$D,$E,$F,$G,$H,$I,$J,$K,$L,$M,$N,$NN,$O,$P,$Q,$R,$S,$T,$U,$V,$W,$X,$Y,$Z,$AA,$AB,$AC,$AD,$AE,$AF,$AG,$AH,$AI,$AJ,$AK,$AL,$AM,$AN,$ANN,$AO,$AP,$AQ) = split /;/;


$sth->execute($datos,$A,$B,$C,$D,$E,$F,$G,$H,$I,$J,$K,$L,$M,$N,$NN,$O,$P,$Q,$R,$S,$T,$U,$V,$W,$X,$Y,$Z,$AA,$AB,$AC,$AD,$AE,$AF,$AG,$AH,$AI,$AJ,$AK,$AL,$AM,$AN,$ANN,$AO,$AP);

               };

close (INSERT);

$dbh->disconnect;
#$dbi->disconnect;
