#/usr/bin/perl
use DBI;

# MYSQL CONFIG VARIABLES

my $database = "Informes_Gestion";
my $table="RVT_Datastore";


# PERL MYSQL CONNECT()

my $dbh = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);
#my $dbi = DBI->connect("DBI:mysql:$database" . ";mysql_read_default_file=$ENV{HOME}/.my.cnf" . ";mysql_read_default_group=perl", $user, $password);

$sth = $dbh->prepare("INSERT INTO $table(idRVT_Datastore,Name,Address,Accessible,Type,VMs,Capacity_MB,Provisioned_MB,In_Use_MB,Free_MB,Free_porciento,SIOC_enabled,SIOC_Threshold,P_Hosts,Hosts,Block_size,Max_Blocks,Extents,Major_Version,Version,VMFS_Upgradeable,MHA,URL
) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

#$sti = $dbi->prepare("select idRVT_RP from RVT_RP order by idRVT_RP DESC limit 1");
#$sti->execute( );

#my $datos=$sti->fetchrow_array( );
my $datos=0;

#$sti->finish;
                                                                        
open (INSERT, "RVTools_tabvDatastore_VCENTDPL.csv");


while(<INSERT>) {

$datos++;

chomp;

my ($A,$B,$C,$D,$E,$F,$G,$H,$I,$J,$K,$L,$M,$N,$NN,$O,$P,$Q,$R,$S,$T,$U) = split /;/;


$sth->execute($datos,$A,$B,$C,$D,$E,$F,$G,$H,$I,$J,$K,$L,$M,$N,$NN,$O,$P,$Q,$R,$S,$T,$U);

               };

close (INSERT);

$dbh->disconnect;
#$dbi->disconnect;
